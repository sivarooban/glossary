$(document).ready(function () {

	
    /* Sticky Menu */
    $(window).scroll(function () {
        if ($(document).scrollTop() > 50) {
            $(".menubar").addClass("sticky");
        } else {
            $(".menubar").removeClass("sticky");
        }
    });

    //    Sticky Drpdown
    $(window).scroll(function () {
        if ($(document).scrollTop() > 200) {
            $(".dropdown").addClass("dropdown-sticky");
        } else {
            $(".dropdown").removeClass("dropdown-sticky");
        }
    });


    // Owl Carousel

    var $homeSlider = $('.home-slider');

    if ($homeSlider.length && $.fn.owlCarousel) {
        $homeSlider.owlCarousel({
            loop: true,
            autoplay: false,
            autoplayTimeout: 3000,
            autoHeight: true,
            skip_invisible: false,
            lazyLoad: 'ondemand',
            items: 1,
            navText: [
                "<img src=\"images/arrow-left.svg\">",
                "<img src=\"images/arrow-right.svg\">"
            ],
            responsive: {
                0: {
                    dots: false,
                    nav: true,
                }
            }
        }); 
           $(window).trigger('scroll');
    }
    $('#livesearch_result').on('wheel DOMMouseScroll mousewheel', function (e) {
        e.stopPropagation();
    });

    $('.dropdown-toggle').on('click', function (e) {
        e.stopPropagation();
    });

    
 


    var $productSlider = $('.product-slider');

    if ($productSlider.length && $.fn.slick) {
        $productSlider.slick({
            infinite: true,
            slidesToShow: 6,
            slidesToScroll: 6,
            autoplay: false,
            skip_invisible: false,
            autoplaySpeed: 3000,
            variableWidth: false,
            lazyLoad: 'progressive',
            arrows: true,
            prevArrow: "<div class=\"slick-prev\"><img src='layout/images/arrow-left.svg'></div>",
            nextArrow: "<div class=\"slick-next\"><img src='layout/images/arrow-right.svg'></div>",
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                }
            ]
        });
    }

    $('.product-slider').on('beforeChange', function(event, slick, currentSlide, nextSlide){

      
      $("html, body").animate({scrollTop: ($(window).scrollTop() + 1)});

    });
       $(window).trigger('scroll');

});






