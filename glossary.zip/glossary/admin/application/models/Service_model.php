<?php
/* 
 * Product Enquiry V1.0
 * www.bigeyeglobal.com
 */
 
class Service_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get service by service_id
     */
    function get_service($service_id)
    {
        return $this->db->get_where('service',array('service_id'=>$service_id))->row_array();
    }
    
    /*
     * Get all service count
     */
    function get_all_service_count()
    {
        $this->db->from('service');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all service
     */
    function get_all_service($params = array())
    {
        $this->db->order_by('service_id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('service')->result_array();
    }
        
    /*
     * function to add new service
     */
    function add_service($params)
    {
        $this->db->insert('service',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update service
     */
    function update_service($service_id,$params)
    {
        $this->db->where('service_id',$service_id);
        return $this->db->update('service',$params);
    }
    
    /*
     * function to delete service
     */
    function delete_service($service_id)
    {
        return $this->db->delete('service',array('service_id'=>$service_id));
    }
}
