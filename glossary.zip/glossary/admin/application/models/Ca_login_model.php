<?php
class Ca_login_model extends CI_Model{
    function __construct(){
        parent::__construct();
    }
    
    /*
     * Get ca_customer by company_id
     */
    function login_details($a,$b){			
        $query = $this->db->query('SELECT * FROM product_admin WHERE  admin_username = "'.$a.'" and admin_password = "'.$b.'"  ');
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return FALSE ;
        }       
    }
}
