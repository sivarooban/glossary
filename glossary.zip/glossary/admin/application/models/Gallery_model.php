<?php
/* 
 * Product Enquiry V1.0
 * www.bigeyeglobal.com
 */
 
class Gallery_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get gallery by gallery_id
     */
    function get_gallery($gallery_id)
    {
        return $this->db->get_where('gallery',array('gallery_id'=>$gallery_id))->row_array();
    }
    
    /*
     * Get all gallery count
     */
    function get_all_gallery_count()
    {
        $this->db->from('gallery');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all gallery
     */
    function get_all_gallery($params = array())
    {
        $this->db->order_by('gallery_id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('gallery')->result_array();
    }
        
    /*
     * function to add new gallery
     */
    function add_gallery($params)
    {
        $this->db->insert('gallery',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update gallery
     */
    function update_gallery($gallery_id,$params)
    {
        $this->db->where('gallery_id',$gallery_id);
        return $this->db->update('gallery',$params);
    }
    
    /*
     * function to delete gallery
     */
    function delete_gallery($gallery_id)
    {
        return $this->db->delete('gallery',array('gallery_id'=>$gallery_id));
    }
}
