<?php
/* 
 * Product Enquiry V1.0
 * www.bigeyeglobal.com
 */
 
class Slider_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get slider by slider_id
     */
    function get_slider($slider_id)
    {
        return $this->db->get_where('slider',array('slider_id'=>$slider_id))->row_array();
    }
    
    /*
     * Get all slider count
     */
    function get_all_slider_count()
    {
        $this->db->from('slider');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all slider
     */
    function get_all_slider($params = array())
    {
        $this->db->order_by('slider_id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('slider')->result_array();
    }
        
    /*
     * function to add new slider
     */
    function add_slider($params)
    {
        $this->db->insert('slider',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update slider
     */
    function update_slider($slider_id,$params)
    {
        $this->db->where('slider_id',$slider_id);
        return $this->db->update('slider',$params);
    }
    
    /*
     * function to delete slider
     */
    function delete_slider($slider_id)
    {
        return $this->db->delete('slider',array('slider_id'=>$slider_id));
    }
}
