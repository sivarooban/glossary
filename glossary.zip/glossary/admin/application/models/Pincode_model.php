<?php
/* 
 * Product Enquiry V1.0
 * www.bigeyeglobal.com
 */
 
class Pincode_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get product by product_id
     */
    function get_pincode($pincode_id)
    {
		//echo $pincode_id;
        return $this->db->get_where('pincode',array('pincode_id'=>$pincode_id))->row_array();
		//return $this->db->last_query();
		//die();
    }
    
    /*
     * Get all products count
     */
    function get_all_pincode_count()
    {
        $this->db->from('pincode');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all products
     */
    function get_all_pincode($params = array())
    {
        $this->db->order_by('pincode_id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('pincode')->result_array();
    }
        
    /*
     * function to add new product
     */
    function add_pincode($params)
    {
        $this->db->insert('pincode',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update product
     */
    function update_pincode($pincode_id,$params){
        $this->db->where('pincode_id',$pincode_id);
        return $this->db->update('pincode',$params);
    }
    
    /*
     * function to delete product
     */
    function delete_pincode($pincode_id)
    {
        return $this->db->delete('pincode',array('pincode_id'=>$pincode_id));
    }

}
