<?php
/* 
 * Product Enquiry V1.0
 * www.bigeyeglobal.com
 */
 
class Order_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get product by product_id
     */
    function order_get(){		
        return $this->db->get_where('order_primarys',array('delivery_status'=>1))->result_array();		
    }    
	function order_single_update(){		
        return $this->db->get_where('order_primarys',array('delivery_status'=>1))->result_array();		
    }
	public function order_single($id){
		$this->db->select('*');
		$this->db->from('order_primarys p'); 
		$this->db->join('order_address oa', 'p.order_p=oa.order_p_id', 'left');
		$this->db->join('orders or', 'or.primary_ids=p.order_p', 'left');
		$this->db->where('p.order_p',$id);		    
		$query = $this->db->get(); 
		if($query->num_rows() != 0)
		{
			return $query->result_array();
		}
		else
		{
			return false;
		}
	}
	
	function delete_order($order_id){
		$this->db->where('order_id',$order_id);		
		$this->db->from('orders');		
		$query = $this->db->get();
		$cat =  $query->result();
		$primary_ids = $cat[0]->primary_ids;
		
		
        $this->db->delete('orders',array('order_id'=>$order_id));		
		
		
		$query = $this->db->query('SELECT * FROM orders WHERE    primary_ids = "'.$primary_ids.'"  ');
		$query->num_rows();
        if($query->num_rows() == 0){
            $this->db->delete('order_primarys',array('order_p'=>$primary_ids));
        } 
    }
	function update_total_order($primary_ids){
		$this->db->where('primary_ids',$primary_ids);
		$this->db->select_sum('single_total');
		$this->db->from('orders');				
		$query = $this->db->get();
		$m = $query->result();
		$single_total = $m[0]->single_total;

		$params = array(					
					'order_total' => $single_total,					
				);
		$this->db->where('order_p',$primary_ids);
        return $this->db->update('order_primarys',$params);
	}
	
	function update_deliver($order_p,$params){
		//echo $order_p;
		//echo "<pre>";
		//print_r($params);
		//echo "fff";
        $this->db->where('order_p',$order_p);
        $this->db->update('order_primarys',$params);				
    }
	
	function update_single($order_id,$params){
		//echo $order_p;
		//echo "<pre>";
		//print_r($params);
		//echo "fff";
        $this->db->where('order_id',$order_id);
        $this->db->update('orders',$params);				
    }
}
