<?php
/* 
 * Product Enquiry V1.0
 * www.bigeyeglobal.com
 */
 
class Product_image_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get product_image by product_images_id
     */
    function get_product_image($product_images_id)
    {
        return $this->db->get_where('product_images',array('product_images_id'=>$product_images_id))->row_array();
    }
    
    /*
     * Get all product_images count
     */
    function get_all_product_images_count()
    {
        $this->db->from('product_images');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all product_images
     */
    function get_all_product_images($params = array())
    {
        $this->db->order_by('product_images_id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('product_images')->result_array();
    }
        
    /*
     * function to add new product_image
     */
    function add_product_image($params)
    {
        $this->db->insert('product_images',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update product_image
     */
    function update_product_image($product_images_id,$params)
    {
        $this->db->where('product_images_id',$product_images_id);
        return $this->db->update('product_images',$params);
    }
    
    /*
     * function to delete product_image
     */
    function delete_product_image($product_images_id)
    {
        return $this->db->delete('product_images',array('product_images_id'=>$product_images_id));
    }
}
