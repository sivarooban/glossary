<?php
/* 
 * Product Enquiry V1.0
 * www.bigeyeglobal.com
 */
 
class Cm_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get cm by cms_id
     */
    function get_cm($cms_id)
    {
        return $this->db->get_where('cms',array('cms_id'=>$cms_id))->row_array();
    }
    
    /*
     * Get all cms count
     */
    function get_all_cms_count()
    {
        $this->db->from('cms');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all cms
     */
    function get_all_cms($params = array())
    {
        $this->db->order_by('cms_id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('cms')->result_array();
    }
        
    /*
     * function to add new cm
     */
    function add_cm($params)
    {
        $this->db->insert('cms',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update cm
     */
    function update_cm($cms_id,$params)
    {
        $this->db->where('cms_id',$cms_id);
        return $this->db->update('cms',$params);
    }
    
    /*
     * function to delete cm
     */
    function delete_cm($cms_id)
    {
        return $this->db->delete('cms',array('cms_id'=>$cms_id));
    }
}
