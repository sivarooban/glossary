<?php
/* 
 * Product Enquiry V1.0
 * www.bigeyeglobal.com
 */
 
class Contact_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get contact by id
     */
    function get_contact($id)
    {
        return $this->db->get_where('contact',array('id'=>$id))->row_array();
    }
    
    /*
     * Get all contact count
     */
    function get_all_contact_count()
    {
        $this->db->from('contact');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all contact
     */
    function get_all_contact($params = array())
    {
        $this->db->order_by('id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('contact')->result_array();
    }
        
    /*
     * function to add new contact
     */
    function add_contact($params)
    {
        $this->db->insert('contact',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update contact
     */
    function update_contact($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('contact',$params);
    }
    
    /*
     * function to delete contact
     */
    function delete_contact($id)
    {
        return $this->db->delete('contact',array('id'=>$id));
    }
}
