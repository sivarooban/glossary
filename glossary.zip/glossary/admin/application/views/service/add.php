
<style>
.edit_div {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

.edit_div:hover {
  border: 1px solid #777;
}

.edit_div img {
  width: 100%;
  height: auto;
}

.edit_div {
  padding: 15px;
  text-align: center;
}
</style>
<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Service Add</h3>
            </div>
            <?php echo form_open_multipart('service/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="service_status" class="control-label"><span class="text-danger">*</span>Service Status</label>
						<div class="form-group">
							<select name="service_status" class="form-control">
								<option value="">select</option>
								<?php 
								$service_status_values = array(
									'active'=>'Active',
									'inactive'=>'Inactive',
								);

								foreach($service_status_values as $value => $display_text)
								{
									$selected = ($value == $this->input->post('service_status')) ? ' selected="selected"' : "";

									echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('service_status');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="service_title" class="control-label"><span class="text-danger">*</span>Service Title</label>
						<div class="form-group">
							<input type="text" name="service_title" value="<?php echo $this->input->post('service_title'); ?>" class="form-control" id="service_title" />
							<span class="text-danger"><?php echo form_error('service_title');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="service_description" class="control-label"><span class="text-danger">*</span>Service Description</label>
						<div class="form-group">
							<input type="text" name="service_description" value="<?php echo $this->input->post('service_description'); ?>" class="form-control" id="service_description" />
							<span class="text-danger"><?php echo form_error('service_description');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="service_image" class="control-label"><span class="text-danger">*</span>Service Image</label>
						<div class="form-group">
							<input type="file" name="service_image" value="<?php echo $this->input->post('service_image'); ?>" class="form-control" id="service_image"  onchange="readURL(this);"/>
							<span class="text-danger"><?php echo form_error('service_image');?></span>
						</div>
                          <div class="edit_div">
                        <img id="blah" src="#" alt="" />
                        </div>
					</div>
					<div class="col-md-6">
						<label for="service_order_by" class="control-label"><span class="text-danger">*</span>Service Order By</label>
						<div class="form-group">
							<input type="text" name="service_order_by" value="<?php echo $this->input->post('service_order_by'); ?>" class="form-control" id="service_order_by" />
							<span class="text-danger"><?php echo form_error('service_order_by');?></span>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>
<script>
function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result)
                    .width(150)
                    .height(200);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>