
<style>
.edit_div {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

.edit_div:hover {
  border: 1px solid #777;
}

.edit_div img {
  width: 100%;
  height: auto;
}

.edit_div {
  padding: 15px;
  text-align: center;
}
</style>

<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Pincode Add</h3>
            </div>
            <?php echo form_open_multipart('pincode/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="category_id" class="control-label"><span class="text-danger">*</span>Days</label>
						<div class="form-group">
							<select name="days" class="form-control">
								<option value="">Select Days</option>
								<option value="monday">Monday</option>
								<option value="tuesday">TUESDAY</option>
								<option value="wednesday">WEDNESDAY</option>
								<option value="thursday">THURSDAY</option>
								<option value="friday">FRIDAY</option>
								<option value="saturday">SATURDAY</option>
								<option value="sunday">SUNDAY</option>
							</select>
							<span class="text-danger"><?php echo form_error('days');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="pincode" class="control-label"><span class="text-danger">*</span>Pincode</label>
						<div class="form-group">
							<input type="text" name="pincode" value="<?php echo $this->input->post('pincode'); ?>" class="form-control" id="pincode" />
							<span class="text-danger"><?php echo form_error('pincode');?></span>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>
