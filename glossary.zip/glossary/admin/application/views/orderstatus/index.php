<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Order Status</h3>            	
            </div>
            <div class="box-body">
				<table border=1>
<thead>
<tr>
<th>Order Id</th>
<th>Total</th>
<th>Date</th>
<th>Deliver Order</th>
</tr>
</thead>
<tr ng-repeat="item in filteredItems">
<td> {{item.order_p}} </td>
<td> {{item.order_total}} </td>
<td> {{item.order_date}} </td>
<td>  <a href="<?php base_url()?>cart_update?id={{item.order_p}}">Deliver Order</a> </td>
</tr>
</table>
<div data-pagination="" data-num-pages="numOfPages()"
data-current-page="curPage" data-max-size="maxSize"
data-boundary-links="true"></div>
            </div>
        </div>
    </div>
</div>
