<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Order Status</h3>            	
            </div>
            <div class="box-body">
				<table border=1>
					<thead>
					<tr>
					<th>Order Id</th>
					<th>Total</th>
					
					<th>Line Total</th>
					<th>Update</th>
					</tr>
					</thead>
					<tr ng-repeat="item in cart_update_val">
						<td> Quantity <input type="text" id="qua{{item.order_id}}" value="{{item.quantity}}"> </td>
						<td> Single Total<input type="text" id="sing{{item.order_id}}" value="{{item.single_price}}"> </td>						
						<td> Line Total<input type="text" id="total{{item.order_id}}" value="{{item.single_total}}"> </td>
						<td>  <i class="fa fa-close closes{{item.order_id}}" ng-click="close_orders(item.order_id,item.order_p)"></i>
							  <i ng-click="single_update(item.order_id)" class="fa fa-edit"></i> 
						</td>
					</tr>
					<tr>
												
						<td>Deliver Date <input id="deliver_date" type="text" value="{{cart_update_val[0].order_date}}"> </td>
						<td>Total</td>
						<td> {{cart_update_val[0].order_total}}
						</td>
						<td> 
							  <i class="fa fa-edit" ng-click="date_update(cart_update_val[0].order_p)"></i> 
						</td>
					</tr>
				</table>
            </div>
        </div>
    </div>
</div>
