<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Cms Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('cm/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>Cms Id</th>
						<th>Cms Model</th>
						<th>Cms Title</th>
						<th>Cms Image</th>
						<th>Cms Seo Title</th>
						<th>Cms Seo Description</th>
						<th>Cms Seo Keyword</th>
						<th>Cms Description</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($cms as $c){ ?>
                    <tr>
						<td><?php echo $c['cms_id']; ?></td>
						<td><?php echo $c['cms_model']; ?></td>
						<td><?php echo $c['cms_title']; ?></td>
						<td><?php echo $c['cms_image']; ?></td>
						<td><?php echo $c['cms_seo_title']; ?></td>
						<td><?php echo $c['cms_seo_description']; ?></td>
						<td><?php echo $c['cms_seo_keyword']; ?></td>
						<td><?php echo $c['cms_description']; ?></td>
						<td>
                            <a href="<?php echo site_url('cm/edit/'.$c['cms_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('cm/remove/'.$c['cms_id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
        </div>
    </div>
</div>
