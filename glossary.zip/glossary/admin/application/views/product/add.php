
<style>
.edit_div {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

.edit_div:hover {
  border: 1px solid #777;
}

.edit_div img {
  width: 100%;
  height: auto;
}

.edit_div {
  padding: 15px;
  text-align: center;
}
</style>

<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Product Add</h3>
            </div>
            <?php echo form_open_multipart('product/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="category_id" class="control-label"><span class="text-danger">*</span>Category</label>
						<div class="form-group">
							<select name="category_id" class="form-control">
								<option value="">select category</option>
								<?php 
								foreach($all_category as $category)
								{
									$selected = ($category['category_id'] == $this->input->post('category_id')) ? ' selected="selected"' : "";

									echo '<option value="'.$category['category_id'].'" '.$selected.'>'.$category['category_name'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('category_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="sub_category_id" class="control-label">Sub Category</label>
						<div class="form-group">
							<select name="sub_category_id" class="form-control">
								<option value="">select sub_category</option>
								<?php 
								foreach($all_sub_category as $sub_category)
								{
									$selected = ($sub_category['sub_category_id'] == $this->input->post('sub_category_id')) ? ' selected="selected"' : "";

									echo '<option value="'.$sub_category['sub_category_id'].'" '.$selected.'>'.$sub_category['subcategory_name'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="product_name" class="control-label"><span class="text-danger">*</span>Product Name</label>
						<div class="form-group">
							<input type="text" name="product_name" value="<?php echo $this->input->post('product_name'); ?>" class="form-control" id="product_name" />
							<span class="text-danger"><?php echo form_error('product_name');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="product_code" class="control-label"><span class="text-danger">*</span>Product Code</label>
						<div class="form-group">
							<input type="text" name="product_code" value="<?php echo $this->input->post('product_code'); ?>" class="form-control" id="product_code" />
							<span class="text-danger"><?php echo form_error('product_code');?></span>
						</div>
					</div>
				
					<div class="col-md-6">
						<label for="price" class="control-label">Price</label>
						<div class="form-group">
							<input type="text" name="price" value="<?php echo $this->input->post('price'); ?>" class="form-control" id="price" />
						</div>
					</div>
				
					<div class="col-md-6">
						<label for="product_status" class="control-label">Product Status</label>
						<div class="form-group">
                        <select name="product_status" class="form-control">
								<option value="">select</option>
                        
                        	<?php 
								$gallery_status_values = array(
									'1'=>'Active',
									'2'=>'Inactive',
								);

								foreach($gallery_status_values as $value => $display_text)
								{
									$selected = ($value == $this->input->post('product_status')) ? ' selected="selected"' : "";

									echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
								} 
								?>
                        </select>
                        
							<!--<input type="text" name="product_status" value="<?php echo $this->input->post('product_status'); ?>" class="form-control" id="product_status" />-->
						</div>
					</div>
					<div class="col-md-6">
						<label for="description" class="control-label">Description</label>
						<div class="form-group">
							<textarea name="description" class="form-control" id="description"><?php echo $this->input->post('description'); ?></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<label for="availability" class="control-label">Availability</label>
						<div class="form-group">
							<textarea name="availability" class="form-control" id="availability"><?php echo $this->input->post('availability'); ?></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<label for="feature" class="control-label">Feature</label>
						<div class="form-group">
							<select name="featured" class="form-control">
								<option value="">select</option>
								<option value="1">Featured</option>
								<option value="0">Non Featured</option>
							</select>
						</div>
					</div>
                    <div class="col-md-6">
						<label for="feature" class="control-label">Features</label>
						<textarea id="summernote" name="editordata">features</textarea>
					</div>
                    <div class="col-md-6">
						<label for="product_img" class="control-label">Product Img</label>
						<div class="form-group">
							<input type="file" name="product_img" value="<?php echo $this->input->post('product_img'); ?>" class="form-control" id="product_img"  onchange="readURL(this);"  required/>
						</div>
                        
                            <div class="edit_div">
                        <img id="blah" src="#" alt="" />
                        </div>
                        
                        
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>


<script>	
	function readURL(input) {
		if(input.files && input.files[0]) {
			var reader = new FileReader();
			reader.onload = function (e) {
				$('#blah')
					.attr('src', e.target.result)
					.width(150)
					.height(200);
			};
			reader.readAsDataURL(input.files[0]);
		}	
	}
</script>