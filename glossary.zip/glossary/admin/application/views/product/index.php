<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Products Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('product/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>SNo</th>
						<th>Category Id</th>
						<th>Sub Category Id</th>
						<th>Product Name</th>
						<th>Product Code</th>
					<!--	<th>Product Img</th>-->
						<th>Price</th>
						<th>Created</th>
						<th>Modified</th>
						
						<th>Description</th>
						<th>Availability</th>
						<th>Feature</th>
                        <th>Product Status</th>
						<th>Actions</th>
                    </tr>
                    <?php
					$s=1;
					  $this->load->model('Product_model');
					 foreach($products as $p){
					  $cat_name=$this->Product_model->cat_name($p['category_id']);					  
					  $sub_cat_name=$this->Product_model->sub_cat_name($p['sub_category_id']);
					 	
					if($p['product_status']==1)
					{
					$catstatus="Active";
					}
					else
					{
					$catstatus="InActive";
					}
					 
					  ?>
                    <tr>
						<td><?php echo $s;?> </td>
						<td><?php echo $cat_name; ?></td>
						<td><?php echo $sub_cat_name; ?></td>
						<td><?php echo $p['product_name']; ?></td>
						<td><?php echo $p['product_code']; ?></td>
						<!--<td><?php echo $p['product_img']; ?></td>-->
						<td><?php echo $p['price']; ?></td>
						<td><?php echo date('d-m-Y',strtotime($p['created'])); ?></td>
						<td><?php echo date('d-m-Y',strtotime($p['modified'])); ?></td>
					
						<td><?php echo $p['description']; ?></td>
						<td><?php echo $p['availability']; ?></td>
						<td><?php echo $p['feature']; ?></td>
                        	<td><?php echo $catstatus; ?></td>
						<td>
                            <a href="<?php echo site_url('product/edit/'.$p['product_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('product/remove/'.$p['product_id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php
						$s++;
						 } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
        </div>
    </div>
</div>
