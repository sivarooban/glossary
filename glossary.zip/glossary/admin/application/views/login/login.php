
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Glossary Items</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php  echo base_url();?>resources/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php  echo base_url();?>resources/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
</head>
<body class="hold-transition sidebar-mini" ng-app="myApp" ng-controller="myCtrl">

  



  <!-- Content Wrapper. Contains page content -->
  <div class="">
  

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
        <div class="col-md-12">
        
          <div class="col-md-9" style="padding-left:22%; padding-top:8%">
            <!-- Horizontal Form -->
          
            
            <div class="card card-info" >
              <div class="card-header">
                <h3 class="card-title">Login</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form  class="form-horizontal" method='post' name="login_form"  autocomplete="off">
                <div class="card-body">
                  <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">User ID</label>

                    <div class="col-sm-10">
                      <input type="text" ng-model="user_loginid" class="form-control" id="user_loginid" name="user_loginid" placeholder="User ID">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputPassword3"  class="col-sm-2 control-label">Password</label>

                    <div class="col-sm-10">
                      <input type="password" ng-model="user_password" class="form-control"  name="user_pwd" id="user_pwd" placeholder="Password">
                    </div>
                  </div>
                 
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
					<input type="button" ng-click="clicked()" id="user_submitdetails" name="user_submitdetails" class="btn btn-info"  value="Sign in">
					<button type="reset" class="btn btn-default float-right">Cancel</button>
                </div>
                <!-- /.card-footer -->
              </form>
            </div>
            <!-- /.card -->
            <!-- general form elements disabled -->
           
          <!--/.col (right) -->
        </div>
          
         </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
      
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    
    <strong>Copyright &copy; <?php
$copyYear = 2008; // Set your website start date
$curYear = date('Y'); // Keeps the second year updated
echo $copyYear . (($copyYear != $curYear) ? '-' . $curYear : '');
?><!--  <a href="http://remote.caprowin.com">caprowin.com</a>.</strong> All rights
    reserved. -->
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

<!-- ./wrapper -->

<!-- jQuery -->
<script src="https://adminlte.io/themes/dev/AdminLTE/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="https://adminlte.io/themes/dev/AdminLTE/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- FastClick -->
<script src="https://adminlte.io/themes/dev/AdminLTE/plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="https://adminlte.io/themes/dev/AdminLTE/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="https://adminlte.io/themes/dev/AdminLTE/dist/js/demo.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

 <!-- <script>
   $(document).ready(function(){
  

$('#user_submitdetails').on('click',function(e){
	
       e.preventDefault();
       
var a = document.forms["login_form"]["user_loginid"].value;
     if (a == null || a == "") 
        {
           alert("Please Enter User Id");	
           $("#user_loginid").css("border", " 2px solid red");		
           $("#user_loginid").focus();
           return false;
        }
        
          var b = document.forms["login_form"]["user_pwd"].value;
	  if (b == null || b == "") 
        {
           alert("Please Enter Password");	
           $("#user_pwd").css("border", " 2px solid red");		
           $("#user_pwd").focus();
           return false;
        }

  
   

        var inVal = $("#login_form").serialize();
        $.ajax({
            type: "POST", 
             url: "<?php echo WEB_URL?>Login/login_details",  
             dataType:"json",
            data: inVal,
            success: function(data){
           
          if (data == 1){
            		  window.location.href= "<?php echo WEB_URL;?>Dashboard";            		  
            	}
            

              else{
            		alert("Please Enter Valid Userid & Password");
                $("#user_loginid").val('');
                $("#user_pwd").val('');
            	}
                
            }

            
        });     
    

 });
    
  });   
    </script>-->
	<script>
			var app = angular.module("myApp", []);
			app.controller("myCtrl", ['$scope', '$http', function($scope, $http) {
				$scope.myTxt = "You have not yet clicked submit";				
				$scope.clicked = function () {
					$scope.myTxt = "You clicked submit!";
					console.log('rest')
					$status_username = $status_password = 0;
					if ($scope.user_loginid == null || $scope.user_loginid == "") 
					{
					   
					   $("#user_loginid").css("border", " 2px solid red");		
					   $("#user_loginid").focus();
					   $status_username = 1;
					}										  
				    if ($scope.user_password == null || $scope.user_password == "") 
					{
					   
					   $("#user_pwd").css("border", " 2px solid red");		
					   $("#user_pwd").focus();
					   $status_password = 1;
					}
					if($status_username == 0 && $status_password == 0 ){						
						var dataObj = {
										user_loginid : $scope.user_loginid,
										user_pwd : $scope.user_password										
								};							
						$http({
							method: "POST",
							url: '<?php echo WEB_URL?>Login/login_details',
							data: dataObj,          // You don't need to stringify it and no need to set any headers
						}).then(function (response) {
							// Success callback
							console.log(response);
							if (response.data == 1) {
								window.location.href= "<?php echo WEB_URL;?>Dashboard";
							} else if (response.data == 0) {
								alert("Please Enter Valid Userid & Password");
									$("#user_loginid").val('');
									$("#user_pwd").val('');
							}
						}, function() {
							// Error callback
						});						
					}
				}
			}]);
	</script>
</body>
</html>
