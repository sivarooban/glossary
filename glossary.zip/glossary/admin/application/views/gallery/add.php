
<style>
.edit_div {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

.edit_div:hover {
  border: 1px solid #777;
}

.edit_div img {
  width: 100%;
  height: auto;
}

.edit_div {
  padding: 15px;
  text-align: center;
}
</style>
<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Gallery Add</h3>
            </div>
           
			<?php echo form_open_multipart('gallery/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					
					<div class="col-md-6">
						<label for="gallery_title" class="control-label"><span class="text-danger">*</span>Gallery Title</label>
						<div class="form-group">
							<input type="text" name="gallery_title" value="<?php echo $this->input->post('gallery_title'); ?>" class="form-control" id="gallery_title" />
							<span class="text-danger"><?php echo form_error('gallery_title');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="gallery_image" class="control-label"><span class="text-danger">*</span>Gallery Image</label>
						<div class="form-group">
							<input type="file" name="gallery_image" value="<?php echo $this->input->post('gallery_image'); ?>" class="form-control" id="gallery_image" onchange="readURL(this);" />
							<span class="text-danger"><?php echo form_error('gallery_image');?></span>
						</div>
                         <div class="edit_div">
                        <img id="blah" src="#" alt="" />
                        </div>
                        
					</div>
					<div class="col-md-6">
						<label for="gallery_order_by" class="control-label"><span class="text-danger">*</span>Gallery Order By</label>
						<div class="form-group">
							<input type="text" name="gallery_order_by" value="<?php echo $this->input->post('gallery_order_by'); ?>" class="form-control" id="gallery_order_by" />
							<span class="text-danger"><?php echo form_error('gallery_order_by');?></span>
						</div>
						
						
					</div>
					<div class="col-md-6">
						<label for="gallery_status" class="control-label"><span class="text-danger">*</span>Gallery Status</label>
						<div class="form-group">
							<select name="gallery_status" class="form-control">
								<option value="">select</option>
								<?php 
								$gallery_status_values = array(
									'1'=>'Active',
									'2'=>'Inactive',
								);

								foreach($gallery_status_values as $value => $display_text)
								{
									$selected = ($value == $this->input->post('gallery_status')) ? ' selected="selected"' : "";

									echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('gallery_status');?></span>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>

<script>
function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result)
                    .width(150)
                    .height(200);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>