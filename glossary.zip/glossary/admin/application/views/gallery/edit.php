<style>
.edit_div {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

.edit_div:hover {
  border: 1px solid #777;
}

.edit_div img {
  width: 100%;
  height: auto;
}

.edit_div {
  padding: 15px;
  text-align: center;
}
</style>

<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Gallery Edit</h3>
            </div>
			
			<?php echo form_open_multipart('gallery/edit/'.$gallery['gallery_id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					
					<div class="col-md-6">
						<label for="gallery_title" class="control-label"><span class="text-danger">*</span>Gallery Title</label>
						<div class="form-group">
							<input type="text" name="gallery_title" value="<?php echo ($this->input->post('gallery_title') ? $this->input->post('gallery_title') : $gallery['gallery_title']); ?>" class="form-control" id="gallery_title" />
							<span class="text-danger"><?php echo form_error('gallery_title');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="gallery_image" class="control-label"><span class="text-danger">*</span>Gallery Image</label>
						<div class="form-group">
							<input type="file" name="gallery_image" value="<?php echo ($this->input->post('gallery_image') ? $this->input->post('gallery_image') : $gallery['gallery_image']); ?>" class="form-control" id="gallery_image" onchange="readURL(this);" />
                            
                            <div class="edit_div">

    
                            <img id="blah" src="<?php echo DIR_URL ;?>uploads/<?php echo $gallery['gallery_image'];?>" width="600" height="400"/>
                            
  
</div>
                          
                            
							<span class="text-danger"><?php echo form_error('gallery_image');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="gallery_order_by" class="control-label"><span class="text-danger">*</span>Gallery Order By</label>
						<div class="form-group">
							<input type="text" name="gallery_order_by" value="<?php echo ($this->input->post('gallery_order_by') ? $this->input->post('gallery_order_by') : $gallery['gallery_order_by']); ?>" class="form-control" id="gallery_order_by" />
							<span class="text-danger"><?php echo form_error('gallery_order_by');?></span>
						</div>
					</div>
					
					<div class="col-md-6">
						<label for="gallery_status" class="control-label"><span class="text-danger">*</span>Gallery Status</label>
						<div class="form-group">
							<select name="gallery_status" class="form-control">
								<option value="">select</option>
								<?php 
								$gallery_status_values = array(
									'1'=>'Active',
									'2'=>'Inactive',
								);

								foreach($gallery_status_values as $value => $display_text)
								{
									$selected = ($value == $gallery['gallery_status']) ? ' selected="selected"' : "";

									echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('gallery_status');?></span>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>

<script>
function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result)
                    .width(150)
                    .height(200);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>