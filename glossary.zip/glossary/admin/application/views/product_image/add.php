
<style>
.edit_div {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

.edit_div:hover {
  border: 1px solid #777;
}

.edit_div img {
  width: 100%;
  height: auto;
}

.edit_div {
  padding: 15px;
  text-align: center;
}
</style>
<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Product Image Add</h3>
            </div>
            <?php echo form_open_multipart('product_image/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="product_id" class="control-label">Product</label>
						<div class="form-group">
							<select name="product_id" class="form-control">
								<option value="">select product</option>
								<?php 
								foreach($all_products as $product)
								{
									$selected = ($product['product_id'] == $this->input->post('product_id')) ? ' selected="selected"' : "";

									echo '<option value="'.$product['product_id'].'" '.$selected.'>'.$product['product_name'].'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="product_rel_name" class="control-label">Product Rel Name</label>
						<div class="form-group">
							<input type="text" name="product_rel_name" value="<?php echo $this->input->post('product_rel_name'); ?>" class="form-control" id="product_rel_name" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="product_rel_img" class="control-label">Product Rel Img</label>
						<div class="form-group">
							<input type="file" name="product_rel_img" value="<?php echo $this->input->post('product_rel_img'); ?>" class="form-control" id="product_rel_img"  onchange="readURL(this);"/>
						</div>
                          <div class="edit_div">
                        <img id="blah" src="#" alt="" />
                        </div>
					</div>
					<div class="col-md-6">
						<label for="created" class="control-label">Created</label>
						<div class="form-group">
							<input type="text" name="created" value="<?php echo $this->input->post('created'); ?>" class="has-datetimepicker form-control" id="created" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="modified" class="control-label">Modified</label>
						<div class="form-group">
							<input type="text" name="modified" value="<?php echo $this->input->post('modified'); ?>" class="form-control" id="modified" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="category_id" class="control-label">Category Id</label>
						<div class="form-group">
							<input type="text" name="category_id" value="<?php echo $this->input->post('category_id'); ?>" class="form-control" id="category_id" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="sub_category_id" class="control-label">Sub Category Id</label>
						<div class="form-group">
							<input type="text" name="sub_category_id" value="<?php echo $this->input->post('sub_category_id'); ?>" class="form-control" id="sub_category_id" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="product_images_status" class="control-label">Product Images Status</label>
						<div class="form-group">
							<input type="text" name="product_images_status" value="<?php echo $this->input->post('product_images_status'); ?>" class="form-control" id="product_images_status" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>
<script>
function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result)
                    .width(150)
                    .height(200);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>