<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Slider extends CI_Controller{
    function __construct()
    {
        parent::__construct();
			error_reporting(0);
        
			if ($this->session->userdata['get_loginuserdetails']['role'] != 1){
		redirect('Login/user_logout', 'refresh');
		}
		
		if (!$this->user_logged()) {
          redirect('Login/user_logout', 'refresh');
       }
        $this->load->model('Slider_model');
    } 

		public function user_logged() {
     // if (isset($this->session->userdata('user_role')) && $this->session->userdata('user_role') != "")
      if ($this->session->userdata['get_loginuserdetails']['role'] != ""){
            return true;
        } else {
            return false;
        }
    }
    /*
     * Listing of slider
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('slider/index?');
        $config['total_rows'] = $this->Slider_model->get_all_slider_count();
        $this->pagination->initialize($config);

        $data['slider'] = $this->Slider_model->get_all_slider($params);
        
        $data['_view'] = 'slider/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new slider
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('slider_title','Slider Title','required');
	//	$this->form_validation->set_rules('slider_image','Slider Image','required');
		$this->form_validation->set_rules('slider_order_by','Slider Order By','required');
		$this->form_validation->set_rules('slider_status','Slider Status','required');
		
		if($this->form_validation->run())     
        {   
		
				$source_path  = './slider/gallery/'; 
		$target_path  = './uploads/slider/thumbnail/'; 
	  
         $config['upload_path']   = './uploads/slider/'; 
		 $config['allowed_types'] = 'gif|jpg|png'; 
		//  $config['max_width']     = 720; 
      //   $config['max_height']    = 440;
        // $config['max_size']      = 100; 
        // $config['max_width']     = 1024; 
        // $config['max_height']    = 768;  
		
		
           $this->load->library('upload', $config);
		  if ( ! $this->upload->do_upload('slider_image')) {
          $error = array('error' => $this->upload->display_errors()); 
          
         }
			
         else { 
            $data = array('upload_data' => $this->upload->data());
			  
		  $this->resizeImage($data['upload_data']['file_name']);
		  		
              } 
			$name=$this->upload->data('file_name');   
		$name1="slider/".$name;
		
            $params = array(
				'slider_status' => $this->input->post('slider_status'),
				'slider_title' => $this->input->post('slider_title'),
				'slider_content' => $this->input->post('slider_content'),
				'slider_image' => $name1,
				'slider_order_by' => $this->input->post('slider_order_by'),
            );
            
            $slider_id = $this->Slider_model->add_slider($params);
            redirect('slider/index');
        }
        else
        {            
            $data['_view'] = 'slider/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a slider
     */
    function edit($slider_id)
    {   
        // check if the slider exists before trying to edit it
        $data['slider'] = $this->Slider_model->get_slider($slider_id);
        
        if(isset($data['slider']['slider_id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('slider_title','Slider Title','required');
		//	$this->form_validation->set_rules('slider_image','Slider Image','required');
			$this->form_validation->set_rules('slider_order_by','Slider Order By','required');
			$this->form_validation->set_rules('slider_status','Slider Status','required');
		
			if($this->form_validation->run())     
            {   
			
			
				if($_FILES['slider_image']['name']!=''){
	//print_r($_FILES['gallery_image']['name']);die;
		$source_path  = './uploads/slider/'; 
		$target_path  = './uploads/slider/thumbnail/'; 
	  
         $config['upload_path']   = './uploads/slider/'; 
		 $config['allowed_types'] = 'gif|jpg|png'; 
        // $config['max_size']      = 100; 
		
         $config['max_width']     = 720; 
         $config['max_height']    = 440;  
		
		
           $this->load->library('upload', $config);
		  if ( ! $this->upload->do_upload('slider_image')) {
          $error = array('error' => $this->upload->display_errors()); 
          
         }
			
         else { 
            $data = array('upload_data' => $this->upload->data()); 		
			 $this->resizeImage($data['upload_data']['file_name']);
			
           } 
			$name=$this->upload->data('file_name');   			
			$name1="slider/".$name;
			$params['slider_image'] =  $name1;
			}
			
			
		
			
			
			
              
					 $params['slider_status']= $this->input->post('slider_status');
					 $params['slider_title']=  $this->input->post('slider_title');
					 $params['slider_content']=  $this->input->post('slider_content');
					// $params['slider_image']=  $$name1;
					 $params['slider_order_by']=  $this->input->post('slider_order_by');
              

                $this->Slider_model->update_slider($slider_id,$params);            
                redirect('slider/index');
            }
            else
            {
                $data['_view'] = 'slider/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The slider you are trying to edit does not exist.');
    } 

    /*
     * Deleting slider
     */
    function remove($slider_id)
    {
        $slider = $this->Slider_model->get_slider($slider_id);

        // check if the slider exists before trying to delete it
        if(isset($slider['slider_id']))
        {
            $this->Slider_model->delete_slider($slider_id);
            redirect('slider/index');
        }
        else
            show_error('The slider you are trying to delete does not exist.');
    }
    
	
	
	
	   
   public function resizeImage($filename)
   {

     
	  
       	$source_path  = './uploads/slider/'.$filename; 
		$target_path  = './uploads/slider/thumbnail/'.$filename; 

	  $config_manip['image_library'] = 'gd2';
      $config_manip = array(
          'image_library' => 'gd2',
          'source_image' => $source_path,
          'new_image' => $target_path,
          'maintain_ratio' => TRUE,
          'create_thumb' => TRUE,
          'thumb_marker' => '_thumb',
          'width' => 360,
          'height' => 220
      );

//print_r($config_manip);

      $this->load->library('image_lib', $config_manip);
      if (!$this->image_lib->resize()) {
         echo  $this->image_lib->display_errors();
      exit;
      }
	  
	  $this->image_lib->clear();
   }
	
	
	
	
}
