<?php
/* 
 * Product Enquiry V1.0
 * www.bigeyeglobal.com
 */
 
class Contact extends CI_Controller{
    function __construct()
    {
        parent::__construct();
				error_reporting(0);
        
			if ($this->session->userdata['get_loginuserdetails']['role'] != 1){
		redirect('Login/user_logout', 'refresh');
		}
		
		if (!$this->user_logged()) {
          redirect('Login/user_logout', 'refresh');
       }
        $this->load->model('Contact_model');
    } 

    /*
     * Listing of contact
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('contact/index?');
        $config['total_rows'] = $this->Contact_model->get_all_contact_count();
        $this->pagination->initialize($config);

        $data['contact'] = $this->Contact_model->get_all_contact($params);
        
        $data['_view'] = 'contact/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new contact
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('name','Name','required');
		$this->form_validation->set_rules('email','Email','valid_email');
		$this->form_validation->set_rules('mobilenumber','Mobilenumber','numeric');
		$this->form_validation->set_rules('enquiry','Enquiry','required');
		
		if($this->form_validation->run())     
        {   
            $params = array(
				'name' => $this->input->post('name'),
				'email' => $this->input->post('email'),
				'mobilenumber' => $this->input->post('mobilenumber'),
				'entry-date&time' => $this->input->post('entry-date&time'),
				'enquiry' => $this->input->post('enquiry'),
            );
            
            $contact_id = $this->Contact_model->add_contact($params);
            redirect('contact/index');
        }
        else
        {            
            $data['_view'] = 'contact/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a contact
     */
    function edit($id)
    {   
        // check if the contact exists before trying to edit it
        $data['contact'] = $this->Contact_model->get_contact($id);
        
        if(isset($data['contact']['id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('name','Name','required');
			$this->form_validation->set_rules('email','Email','valid_email');
			$this->form_validation->set_rules('mobilenumber','Mobilenumber','numeric');
			$this->form_validation->set_rules('enquiry','Enquiry','required');
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'name' => $this->input->post('name'),
					'email' => $this->input->post('email'),
					'mobilenumber' => $this->input->post('mobilenumber'),
					'entry-date&time' => $this->input->post('entry-date&time'),
					'enquiry' => $this->input->post('enquiry'),
                );

                $this->Contact_model->update_contact($id,$params);            
                redirect('contact/index');
            }
            else
            {
                $data['_view'] = 'contact/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The contact you are trying to edit does not exist.');
    } 

    /*
     * Deleting contact
     */
    function remove($id)
    {
        $contact = $this->Contact_model->get_contact($id);

        // check if the contact exists before trying to delete it
        if(isset($contact['id']))
        {
            $this->Contact_model->delete_contact($id);
            redirect('contact/index');
        }
        else
            show_error('The contact you are trying to delete does not exist.');
    }
    
			public function user_logged() {
     // if (isset($this->session->userdata('user_role')) && $this->session->userdata('user_role') != "")
      if ($this->session->userdata['get_loginuserdetails']['role'] != ""){
            return true;
        } else {
            return false;
        }
    }
}
