<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Cart_update extends CI_Controller{
    function __construct(){
        parent::__construct();
		error_reporting(0);        
		if ($this->session->userdata['get_loginuserdetails']['role'] != 1){
			redirect('Login/user_logout', 'refresh');
		}		
		if (!$this->user_logged()) {
          redirect('Login/user_logout', 'refresh');
		}
        $this->load->model('Order_model');
    } 
		
	public function user_logged() {
     // if (isset($this->session->userdata('user_role')) && $this->session->userdata('user_role') != "")
      if ($this->session->userdata['get_loginuserdetails']['role'] != ""){
            return true;
        } else {
            return false;
        }
    }


    /*
     * Listing of products
     */
    function index(){
        $data['order_status_data'] = $this->Order_model->order_get();        
        $data['_view'] = 'orderstatus/index';
        $this->load->view('layouts/main',$data);
    }
	
	function retrive_data(){
		$data = $this->Order_model->order_get();
		echo json_encode($data);
	}
    
}
