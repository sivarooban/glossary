<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Testimonal extends CI_Controller{
    function __construct()
    {
        parent::__construct();
			error_reporting(0);
        
			if ($this->session->userdata['get_loginuserdetails']['role'] != 1){
		redirect('Login/user_logout', 'refresh');
		}
		
		if (!$this->user_logged()) {
          redirect('Login/user_logout', 'refresh');
       }
        $this->load->model('Testimonal_model');
    } 

    /*
     * Listing of testimonals
     */
	 		public function user_logged() {
     // if (isset($this->session->userdata('user_role')) && $this->session->userdata('user_role') != "")
      if ($this->session->userdata['get_loginuserdetails']['role'] != ""){
            return true;
        } else {
            return false;
        }
    }
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('testimonal/index?');
        $config['total_rows'] = $this->Testimonal_model->get_all_testimonals_count();
        $this->pagination->initialize($config);

        $data['testimonals'] = $this->Testimonal_model->get_all_testimonals($params);
        
        $data['_view'] = 'testimonal/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new testimonal
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('testimonals_title','Testimonals Title','required');
		$this->form_validation->set_rules('testimonals_description','Testimonals Description','required');
		//$this->form_validation->set_rules('testimonals_image','Testimonals Image','required');
		$this->form_validation->set_rules('testimonals_order_by','Testimonals Order By','required');
		$this->form_validation->set_rules('testimonals_status','Testimonals Status','required');
		
		if($this->form_validation->run())     
        {   
		
		
		
		     
		$source_path  = './uploads/testimonal/'; 
		$target_path  = './uploads/testimonal/thumbnail/'; 
	  
         $config['upload_path']   = './uploads/testimonal/'; 
		 $config['allowed_types'] = 'gif|jpg|png'; 
		 // $config['max_width']     = 720; 
        // $config['max_height']    = 440;
        // $config['max_size']      = 100; 
        // $config['max_width']     = 1024; 
        // $config['max_height']    = 768;  
		
		
           $this->load->library('upload', $config);
		  if ( ! $this->upload->do_upload('testimonals_image')) {
          $error = array('error' => $this->upload->display_errors()); 
          
         }
			
         else { 
            $data = array('upload_data' => $this->upload->data());
			  
		  $this->resizeImage($data['upload_data']['file_name']);
		  		
              } 
			$name=$this->upload->data('file_name');   
		$name1="testimonal/".$name;
		
		
            $params = array(
				'testimonals_status' => $this->input->post('testimonals_status'),
				'testimonals_title' => $this->input->post('testimonals_title'),
				'testimonals_image' => $name1,
				'testimonals_order_by' => $this->input->post('testimonals_order_by'),
				'testimonals_description' => $this->input->post('testimonals_description'),
            );
            
            $testimonal_id = $this->Testimonal_model->add_testimonal($params);
            redirect('testimonal/index');
        }
        else
        {            
            $data['_view'] = 'testimonal/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a testimonal
     */
    function edit($testimonals_id)
    {   
        // check if the testimonal exists before trying to edit it
        $data['testimonal'] = $this->Testimonal_model->get_testimonal($testimonals_id);
        
        if(isset($data['testimonal']['testimonals_id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('testimonals_title','Testimonals Title','required');
			$this->form_validation->set_rules('testimonals_description','Testimonals Description','required');
			//$this->form_validation->set_rules('testimonals_image','Testimonals Image','required');
			$this->form_validation->set_rules('testimonals_order_by','Testimonals Order By','required');
			$this->form_validation->set_rules('testimonals_status','Testimonals Status','required');
		
			if($this->form_validation->run())     
            {  
			
				if($_FILES['testimonals_image']['name']!=''){
	//print_r($_FILES['gallery_image']['name']);die;
		$source_path  = './uploads/testimonal/'; 
		$target_path  = './uploads/testimonal/thumbnail/'; 
	  
         $config['upload_path']   = './uploads/testimonal/'; 
		 $config['allowed_types'] = 'gif|jpg|png'; 
        // $config['max_size']      = 100; 
        // $config['max_width']     = 64; 
        // $config['max_height']    = 64;  
		
		
           $this->load->library('upload', $config);
		  if ( ! $this->upload->do_upload('testimonals_image')) {
          $error = array('error' => $this->upload->display_errors()); 
          
         }
			
         else { 
            $data = array('upload_data' => $this->upload->data()); 		
			 $this->resizeImage($data['upload_data']['file_name']);
			
           } 
			$name=$this->upload->data('file_name');   			
			$name1="testimonal/".$name;
			$params['testimonals_image'] =  $name1;
			}
			
			 
                $params['testimonals_status']= $this->input->post('testimonals_status');
					$params['testimonals_title']=  $this->input->post('testimonals_title');
					//$params['testimonals_image']= $this->input->post('testimonals_image');
					$params['testimonals_order_by']=  $this->input->post('testimonals_order_by');
					$params['testimonals_description']=  $this->input->post('testimonals_description');
              
                $this->Testimonal_model->update_testimonal($testimonals_id,$params);            
                redirect('testimonal/index');
            }
            else
            {
                $data['_view'] = 'testimonal/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The testimonal you are trying to edit does not exist.');
    } 

    /*
     * Deleting testimonal
     */
    function remove($testimonals_id)
    {
        $testimonal = $this->Testimonal_model->get_testimonal($testimonals_id);

        // check if the testimonal exists before trying to delete it
        if(isset($testimonal['testimonals_id']))
        {
            $this->Testimonal_model->delete_testimonal($testimonals_id);
            redirect('testimonal/index');
        }
        else
            show_error('The testimonal you are trying to delete does not exist.');
    }
    
	
	
	   
   
   public function resizeImage($filename)
   {

     
	  
       	$source_path  = './uploads/testimonal/'.$filename; 
		$target_path  = './uploads/testimonal/thumbnail/'.$filename; 

	  $config_manip['image_library'] = 'gd2';
      $config_manip = array(
          'image_library' => 'gd2',
          'source_image' => $source_path,
          'new_image' => $target_path,
          'maintain_ratio' => TRUE,
          'create_thumb' => TRUE,
          'thumb_marker' => '_thumb',
          'width' => 64,
          'height' => 64
      );

//print_r($config_manip);

      $this->load->library('image_lib', $config_manip);
      if (!$this->image_lib->resize()) {
         echo  $this->image_lib->display_errors();
      exit;
      }
	  
	  $this->image_lib->clear();
   }
	
}
