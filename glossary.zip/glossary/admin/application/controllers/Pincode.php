<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Pincode extends CI_Controller{
    function __construct(){
        parent::__construct();
		error_reporting(0);        
		if ($this->session->userdata['get_loginuserdetails']['role'] != 1){
			redirect('Login/user_logout', 'refresh');
		}		
		if (!$this->user_logged()) {
          redirect('Login/user_logout', 'refresh');
		}
        $this->load->model('Pincode_model');
    } 
		
	public function user_logged() {
     // if (isset($this->session->userdata('user_role')) && $this->session->userdata('user_role') != "")
      if ($this->session->userdata['get_loginuserdetails']['role'] != ""){
            return true;
        } else {
            return false;
        }
    }


    /*
     * Listing of products
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('pincode/index?');
        $config['total_rows'] = $this->Pincode_model->get_all_pincode_count();
        $this->pagination->initialize($config);

        $data['products'] = $this->Pincode_model->get_all_pincode($params);
        
        $data['_view'] = 'pincode/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new product
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('pincode','pincode','required');
		$this->form_validation->set_rules('days','days','required');		
		if($this->form_validation->run())     
        {   
            $params = array(
				'pincode' => $this->input->post('pincode'),
				'days' => $this->input->post('days')
            );
            
            $product_id = $this->Pincode_model->add_pincode($params);
            redirect('pincode/add');
        }
        else
        {
		    $data['_view'] = 'pincode/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a product
     */
    function edit($pincode_id){   		
        $data['pincode'] = $this->Pincode_model->get_pincode($pincode_id);
        
        if(isset($data['pincode']['pincode_id'])){
            $this->load->library('form_validation');
			$this->form_validation->set_rules('pincode','pincode','required');
			$this->form_validation->set_rules('days','days','required');			
			if($this->form_validation->run()){				               
				$params['pincode'] = $this->input->post('pincode');
				$params['days'] =  $this->input->post('days');
				/*echo "<pre>";
				print_r($params);
				echo $pincode_id;
				die();				*/
                $this->Pincode_model->update_pincode($pincode_id,$params);            
                redirect('pincode/index');
            }else{
                $data['_view'] = 'pincode/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else{
			show_error('The product you are trying to edit does not exist.');
		}            
    } 
    /*
     * Deleting product
     */
    function remove($pincode_id)
    {
        $pincode = $this->Pincode_model->get_pincode($pincode_id);
		// check if the product exists before trying to delete it
        if(isset($pincode['pincode_id']))
        {
            $this->Pincode_model->delete_pincode($pincode_id);
            redirect('pincode/index');
        }
        else
            show_error('The product you are trying to delete does not exist.');
    }
}
