<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Product extends CI_Controller{
    function __construct(){
        parent::__construct();
		error_reporting(0);        
		if ($this->session->userdata['get_loginuserdetails']['role'] != 1){
			redirect('Login/user_logout', 'refresh');
		}		
		if (!$this->user_logged()) {
          redirect('Login/user_logout', 'refresh');
		}
        $this->load->model('Product_model');
    } 
			public function user_logged() {
     // if (isset($this->session->userdata('user_role')) && $this->session->userdata('user_role') != "")
      if ($this->session->userdata['get_loginuserdetails']['role'] != ""){
            return true;
        } else {
            return false;
        }
    }

    /*
     * Listing of products
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('product/index?');
        $config['total_rows'] = $this->Product_model->get_all_products_count();
        $this->pagination->initialize($config);

        $data['products'] = $this->Product_model->get_all_products($params);
        
        $data['_view'] = 'product/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new product
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('category_id','Category Id','required');
		$this->form_validation->set_rules('product_name','Product Name','required');
		$this->form_validation->set_rules('product_code','Product Code','required');
		$this->form_validation->set_rules('editordata','Features','required');
		if($this->form_validation->run())     
        {   
	
		//'product_img' => $this->input->post('product_img')
		
		$source_path  = './uploads/product/'; 
		$target_path  = './uploads/product/thumbnail/'; 
	  
         $config['upload_path']   = './uploads/product/'; 
		 $config['allowed_types'] = 'gif|jpg|png'; 
		
		
           $this->load->library('upload', $config);
		  if ( ! $this->upload->do_upload('product_img')) {
          $error = array('error' => $this->upload->display_errors()); 
          
         }
			
         else { 
            $data = array('upload_data' => $this->upload->data());
			  
		  $this->resizeImage($data['upload_data']['file_name']);
		  		
              }
		
		
		$name=$this->upload->data('file_name');   
		$name1="product/".$name;
		
		
            $params = array(
				'category_id' => $this->input->post('category_id'),
				'sub_category_id' => $this->input->post('sub_category_id'),
				'product_name' => $this->input->post('product_name'),
				'product_code' => $this->input->post('product_code'),				
				'price' => $this->input->post('price'),
				'created' => date('Y-m-d'),		
				'product_img' =>  $name1,		
				'product_status' => $this->input->post('product_status'),
				'description' => $this->input->post('description'),
				'availability' => $this->input->post('availability'),
				'featured' => $this->input->post('featured'),
				'text_area'=> $this->input->post('editordata')
            );
            
            $product_id = $this->Product_model->add_product($params);
            redirect('product/index');
        }
        else
        {
			$this->load->model('Category_model');
			$data['all_category'] = $this->Category_model->get_all_category();

			$this->load->model('Sub_category_model');
			$data['all_sub_category'] = $this->Sub_category_model->get_all_sub_category();
            
            $data['_view'] = 'product/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a product
     */
    function edit($product_id)
    {   
        // check if the product exists before trying to edit it
        $data['product'] = $this->Product_model->get_product($product_id);
        
        if(isset($data['product']['product_id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('category_id','Category Id','required');
			$this->form_validation->set_rules('product_name','Product Name','required');
			$this->form_validation->set_rules('product_code','Product Code','required');
			$this->form_validation->set_rules('editordata','Features','required');
			if($this->form_validation->run())     
            {  						
				if($_FILES['product_img']['name']!=''){					
					$source_path  = './uploads/product/'; 
					$target_path  = './uploads/product/thumbnail/'; 				  
					$config['upload_path']   = './uploads/product/'; 
					$config['allowed_types'] = 'gif|jpg|png'; 		
					$this->load->library('upload', $config);
					if( ! $this->upload->do_upload('product_img')) {
						$error = array('error' => $this->upload->display_errors()); 
				  
					}else{ 
						$data = array('upload_data' => $this->upload->data()); 		
						$this->resizeImage($data['upload_data']['file_name']);
			
					} 
						$name=$this->upload->data('file_name');   			
						$name1="product/".$name;
						$params['product_img'] =  $name1;										
				}                
					$params['category_id'] = $this->input->post('category_id');
					$params['sub_category_id'] =  $this->input->post('sub_category_id');
					$params['product_name'] =  $this->input->post('product_name');
					$params['product_code'] =  $this->input->post('product_code');
					
					$params['price'] = $this->input->post('price');
				
					$params['modified'] = date('Y-m-d');
					$params['product_status'] =  $this->input->post('product_status');
					$params['description'] =  $this->input->post('description');
					$params['availability'] =  $this->input->post('availability');
					$params['featured'] =  $this->input->post('featured');
					$params['text_area'] = $this->input->post('editordata');
              

                $this->Product_model->update_product($product_id,$params);            
                redirect('product/index');
            }
            else
            {
				$this->load->model('Category_model');
				$data['all_category'] = $this->Category_model->get_all_category();

				$this->load->model('Sub_category_model');
				$data['all_sub_category'] = $this->Sub_category_model->get_all_sub_category();

                $data['_view'] = 'product/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The product you are trying to edit does not exist.');
    } 

    /*
     * Deleting product
     */
    function remove($product_id)
    {
        $product = $this->Product_model->get_product($product_id);

        // check if the product exists before trying to delete it
        if(isset($product['product_id']))
        {
            $this->Product_model->delete_product($product_id);
            redirect('product/index');
        }
        else
            show_error('The product you are trying to delete does not exist.');
    }
    
	
	
	   
   public function resizeImage($filename)
   {

     
	  
       	$source_path  = './uploads/product/'.$filename; 
		$target_path  = './uploads/product/thumbnail/'.$filename; 

	  $config_manip['image_library'] = 'gd2';
      $config_manip = array(
          'image_library' => 'gd2',
          'source_image' => $source_path,
          'new_image' => $target_path,
          'maintain_ratio' => TRUE,
          'create_thumb' => TRUE,
          'thumb_marker' => '_thumb',
          'width' => 360,
          'height' => 220
      );

//print_r($config_manip);

      $this->load->library('image_lib', $config_manip);
      if (!$this->image_lib->resize()) {
         echo  $this->image_lib->display_errors();
      exit;
      }
	  
	  $this->image_lib->clear();
   }
	
	
	
}
