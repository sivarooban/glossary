<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Sub_category extends CI_Controller{
    function __construct()
    {
        parent::__construct();
			error_reporting(0);
        
			if ($this->session->userdata['get_loginuserdetails']['role'] != 1){
		redirect('Login/user_logout', 'refresh');
		}
		
		if (!$this->user_logged()) {
          redirect('Login/user_logout', 'refresh');
       }
        $this->load->model('Sub_category_model');
    } 

		public function user_logged() {
     // if (isset($this->session->userdata('user_role')) && $this->session->userdata('user_role') != "")
      if ($this->session->userdata['get_loginuserdetails']['role'] != ""){
            return true;
        } else {
            return false;
        }
    }
    /*
     * Listing of sub_category
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('sub_category/index?');
        $config['total_rows'] = $this->Sub_category_model->get_all_sub_category_count();
        $this->pagination->initialize($config);

        $data['sub_category'] = $this->Sub_category_model->get_all_sub_category($params);
        
        $data['_view'] = 'sub_category/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new sub_category
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('subcategory_name','Subcategory Name','required');
		$this->form_validation->set_rules('category_id','Category Id','required');
		
		if($this->form_validation->run())     
        {   
            $params = array(
				'category_id' => $this->input->post('category_id'),
				'sub_cat_status' => $this->input->post('sub_cat_status'),
				'subcategory_name' => $this->input->post('subcategory_name'),
				'subcategory_code' => $this->input->post('subcategory_code'),
				'created' => $this->input->post('created'),
				'modified' => $this->input->post('modified'),
            );
            
            $sub_category_id = $this->Sub_category_model->add_sub_category($params);
            redirect('sub_category/index');
        }
        else
        {
			$this->load->model('Category_model');
			$data['all_category'] = $this->Category_model->get_all_category();
            
            $data['_view'] = 'sub_category/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a sub_category
     */
    function edit($sub_category_id)
    {   
        // check if the sub_category exists before trying to edit it
        $data['sub_category'] = $this->Sub_category_model->get_sub_category($sub_category_id);
        
        if(isset($data['sub_category']['sub_category_id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('subcategory_name','Subcategory Name','required');
			$this->form_validation->set_rules('category_id','Category Id','required');
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'category_id' => $this->input->post('category_id'),
					'sub_cat_status' => $this->input->post('sub_cat_status'),
					'subcategory_name' => $this->input->post('subcategory_name'),
					'subcategory_code' => $this->input->post('subcategory_code'),
					'created' => $this->input->post('created'),
					'modified' => $this->input->post('modified'),
                );

                $this->Sub_category_model->update_sub_category($sub_category_id,$params);            
                redirect('sub_category/index');
            }
            else
            {
				$this->load->model('Category_model');
				$data['all_category'] = $this->Category_model->get_all_category();

                $data['_view'] = 'sub_category/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The sub_category you are trying to edit does not exist.');
    } 

    /*
     * Deleting sub_category
     */
    function remove($sub_category_id)
    {
        $sub_category = $this->Sub_category_model->get_sub_category($sub_category_id);

        // check if the sub_category exists before trying to delete it
        if(isset($sub_category['sub_category_id']))
        {
            $this->Sub_category_model->delete_sub_category($sub_category_id);
            redirect('sub_category/index');
        }
        else
            show_error('The sub_category you are trying to delete does not exist.');
    }

    
    
}
