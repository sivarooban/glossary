<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Product_image extends CI_Controller{
    function __construct()
    {
        parent::__construct();
				error_reporting(0);
        
			if ($this->session->userdata['get_loginuserdetails']['role'] != 1){
		redirect('Login/user_logout', 'refresh');
		}
		
		if (!$this->user_logged()) {
          redirect('Login/user_logout', 'refresh');
       }
        $this->load->model('Product_image_model');
    } 
	
			public function user_logged() {
     // if (isset($this->session->userdata('user_role')) && $this->session->userdata('user_role') != "")
      if ($this->session->userdata['get_loginuserdetails']['role'] != ""){
            return true;
        } else {
            return false;
        }
    }

    /*
     * Listing of product_images
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('product_image/index?');
        $config['total_rows'] = $this->Product_image_model->get_all_product_images_count();
        $this->pagination->initialize($config);

        $data['product_images'] = $this->Product_image_model->get_all_product_images($params);
        
        $data['_view'] = 'product_image/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new product_image
     */
    function add()
    {   
        if(isset($_POST) && count($_POST) > 0)     
        {   
		
		
				$source_path  = './uploads/product_related/'; 
		$target_path  = './uploads/product_related/thumbnail/'; 
	  
         $config['upload_path']   = './uploads/product_related/'; 
		 $config['allowed_types'] = 'gif|jpg|png'; 
		 // $config['max_width']     = 720; 
        // $config['max_height']    = 440;
        // $config['max_size']      = 100; 
        // $config['max_width']     = 1024; 
        // $config['max_height']    = 768;  
		
		
           $this->load->library('upload', $config);
		  if ( ! $this->upload->do_upload('product_rel_img')) {
          $error = array('error' => $this->upload->display_errors()); 
          
         }
			
         else { 
            $data = array('upload_data' => $this->upload->data());
			  
		  $this->resizeImage($data['upload_data']['file_name']);
		  		
              } 
			$name=$this->upload->data('file_name');   
		$name1="product_related/".$name;
		
		
		
            $params = array(
				'product_id' => $this->input->post('product_id'),
				'product_rel_name' => $this->input->post('product_rel_name'),
				'product_rel_img' => $name1,
				'created' => $this->input->post('created'),
				'modified' => $this->input->post('modified'),
				'category_id' => $this->input->post('category_id'),
				'sub_category_id' => $this->input->post('sub_category_id'),
				'product_images_status' => $this->input->post('product_images_status'),
            );
            
            $product_image_id = $this->Product_image_model->add_product_image($params);
            redirect('product_image/index');
        }
        else
        {
			$this->load->model('Product_model');
			$data['all_products'] = $this->Product_model->get_all_products();
            
            $data['_view'] = 'product_image/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a product_image
     */
    function edit($product_images_id)
    {   
        // check if the product_image exists before trying to edit it
        $data['product_image'] = $this->Product_image_model->get_product_image($product_images_id);
        
        if(isset($data['product_image']['product_images_id']))
        {
            if(isset($_POST) && count($_POST) > 0)     
            { 
			
			
				if($_FILES['product_rel_img']['name']!=''){
	//print_r($_FILES['gallery_image']['name']);die;
		$source_path  = './uploads/product_related/'; 
		$target_path  = './uploads/product_related/thumbnail/'; 
	  
         $config['upload_path']   = './uploads/product_related/'; 
		 $config['allowed_types'] = 'gif|jpg|png'; 
        // $config['max_size']      = 100; 
         $config['max_width']     = 720; 
         $config['max_height']    = 440;  
		
		
           $this->load->library('upload', $config);
		  if ( ! $this->upload->do_upload('product_rel_img')) {
          $error = array('error' => $this->upload->display_errors()); 
          
         }
			
         else { 
            $data = array('upload_data' => $this->upload->data()); 		
			 $this->resizeImage($data['upload_data']['file_name']);
			
           } 
			$name=$this->upload->data('file_name');   			
			$name1="product_related/".$name;
			$params['product_rel_img'] =  $name1;
			}
			
			  
                $params['product_id']= $this->input->post('product_id');
					$params['product_rel_name']= $this->input->post('product_rel_name');
					//'product_rel_img' => $this->input->post('product_rel_img'),
					$params['created']= $this->input->post('created');
					$params['modified']= $this->input->post('modified');
					$params['category_id']= $this->input->post('category_id');
					$params['sub_category_id']= $this->input->post('sub_category_id');
					$params['product_images_status']= $this->input->post('product_images_status');
             //   );

                $this->Product_image_model->update_product_image($product_images_id,$params);            
                redirect('product_image/index');
            }
            else
            {
				$this->load->model('Product_model');
				$data['all_products'] = $this->Product_model->get_all_products();

                $data['_view'] = 'product_image/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The product_image you are trying to edit does not exist.');
    } 

    /*
     * Deleting product_image
     */
    function remove($product_images_id)
    {
        $product_image = $this->Product_image_model->get_product_image($product_images_id);

        // check if the product_image exists before trying to delete it
        if(isset($product_image['product_images_id']))
        {
            $this->Product_image_model->delete_product_image($product_images_id);
            redirect('product_image/index');
        }
        else
            show_error('The product_image you are trying to delete does not exist.');
    }
	
	
	
	   public function resizeImage($filename)
   {

     
	  
       	$source_path  = './uploads/product_related/'.$filename; 
		$target_path  = './uploads/product_related/thumbnail/'.$filename; 

	  $config_manip['image_library'] = 'gd2';
      $config_manip = array(
          'image_library' => 'gd2',
          'source_image' => $source_path,
          'new_image' => $target_path,
          'maintain_ratio' => TRUE,
          'create_thumb' => TRUE,
          'thumb_marker' => '_thumb',
          'width' => 490,
          'height' => 540
      );

//print_r($config_manip);

      $this->load->library('image_lib', $config_manip);
      if (!$this->image_lib->resize()) {
         echo  $this->image_lib->display_errors();
      exit;
      }
	  
	  $this->image_lib->clear();
   }
    
}
