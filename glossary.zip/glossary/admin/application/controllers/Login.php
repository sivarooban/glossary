<?php

class Login extends CI_Controller{
    function __construct(){
        parent::__construct();
		error_reporting(0);
        $this->load->model('Ca_login_model');
    } 

    /*
     * Listing of ca_customer
     */
    function index(){        
        $this->load->view('login/login');
    }

    function login_details(){        
	    $json = file_get_contents('php://input');		
		$data = json_decode($json);
		
        $uid=$data->user_loginid;
		$pass=$data->user_pwd;
		$userdetails = $this->Ca_login_model->login_details($uid,$pass);
		if(!empty($userdetails)){
			$this->session->set_userdata('get_loginuserdetails', $userdetails);
			echo json_encode(1);
        }else{
			echo json_encode(0);
        }
    }	
		
	public function user_logout(){
	
	 header("Cache-Control: private, must-revalidate, max-age=0");
     header("Pragma: no-cache");
   
	
			$this->session->sess_destroy();
        @session_destroy();
		$this->db->close();
       redirect('Login', 'refresh');
		}
  
    
}
