<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Order_update extends CI_Controller{
    function __construct(){
        parent::__construct();
		error_reporting(0);        
		if ($this->session->userdata['get_loginuserdetails']['role'] != 1){
			redirect('Login/user_logout', 'refresh');
		}		
		if (!$this->user_logged()) {
          redirect('Login/user_logout', 'refresh');
		}
        $this->load->model('Order_model');
    } 
		
	public function user_logged() {
     // if (isset($this->session->userdata('user_role')) && $this->session->userdata('user_role') != "")
      if ($this->session->userdata['get_loginuserdetails']['role'] != ""){
            return true;
        } else {
            return false;
        }
    }


    /*
     * Listing of products
     */
    function index(){
        $data['order_status_data'] = $this->Order_model->order_get();        
        $data['_view'] = 'orderstatus/index';
        $this->load->view('layouts/main',$data);
    }		
	
	function retrive_data(){
		$data = $this->Order_model->order_get();
		echo json_encode($data);
	}
	
	function cart_update(){
		$id = $_GET['id'];
        $data['id'] = $id;
        $data['_view'] = 'orderstatus/cart_update';
        $this->load->view('layouts/main',$data);
    }
    
	function cart_retrive_data(){
		$json = file_get_contents('php://input');
		$data = json_decode($json);
		$id  = $data->id;
		$data = $this->Order_model->order_single($id);
		echo json_encode($data);
	}
	
	function cart_delete(){
		$json = file_get_contents('php://input');
		$data = json_decode($json);
		
		$id  = $data->id;
		$primary_ids  = $data->primary_ids;
		$data = $this->Order_model->delete_order($id);
		$this->Order_model->update_total_order($primary_ids);
		echo json_encode($data);
	}
	function date_update(){
		$json = file_get_contents('php://input');
		$data = json_decode($json);
		
		$order_p  = $data->id;
		$order_date  = $data->order_date;
		$params = array(				
				'order_date' => $order_date				
            );
		
		$dre = $this->Order_model->update_deliver($order_p,$params);
		echo json_encode($dre);
	}
	function single_update(){
		$json = file_get_contents('php://input');
		$data = json_decode($json);		
		$single_price  = $data->sprice;
		$quantity  = $data->quantitys;		
		$single_total  = $data->stot;
		$params = array(				
				'quantity' => $quantity,				
				'single_total' => $single_total,
				'single_price' => $single_price				
            );		
		$dre = $this->Order_model->update_single($data->o_id,$params);
	}
}
