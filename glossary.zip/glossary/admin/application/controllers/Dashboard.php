<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Dashboard extends CI_Controller{
 public  function __construct()
    {
        parent::__construct();
		error_reporting(0);
		//print_r($this->session->userdata['get_loginuserdetails']['role']);die;
		if ($this->session->userdata['get_loginuserdetails']['role'] != 1){
		redirect('Login/user_logout', 'refresh');
		}
		if (!$this->user_logged()) {
          redirect('Login/user_logout', 'refresh');
       }
        
    }

 public  function index()
    {
	if (!$this->user_logged()) {
          redirect('Login/user_logout', 'refresh');
       }

         //if ($this->session->userdata['get_loginuserdetails']['role'] == 1){
	
	
        
	 else{
         $data['_view'] = 'dashboard';
        $this->load->view('layouts/main',$data);
         }
    }
	
	
	
		public function user_logged() {
     // if (isset($this->session->userdata('user_role')) && $this->session->userdata('user_role') != "")
      if ($this->session->userdata['get_loginuserdetails']['role'] != ""){
            return true;
        } else {
            return false;
        }
    }
}
