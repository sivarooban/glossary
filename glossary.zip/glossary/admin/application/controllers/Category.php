<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Category extends CI_Controller{
    function __construct()
    {
        parent::__construct();
		error_reporting(0);
        
			if ($this->session->userdata['get_loginuserdetails']['role'] != 1){
		redirect('Login/user_logout', 'refresh');
		}
		
		if (!$this->user_logged()) {
          redirect('Login/user_logout', 'refresh');
       }
	   $this->load->model('Category_model');
        
    } 

    /*
     * Listing of category
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('category/index?');
        $config['total_rows'] = $this->Category_model->get_all_category_count();
        $this->pagination->initialize($config);

        $data['category'] = $this->Category_model->get_all_category($params);
        
        $data['_view'] = 'category/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new category
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('category_name','Category Name','required');
		$this->form_validation->set_rules('category_code','Category Code','required');
		$this->form_validation->set_rules('cat_status','Cat Status','required');
		
		if($this->form_validation->run()){
			$source_path  = './uploads/product/'; 
			$target_path  = './uploads/product/thumbnail/'; 	  
			$config['upload_path']   = './uploads/product/'; 
			$config['allowed_types'] = 'gif|jpg|png'; 					
			$this->load->library('upload', $config);
			if ( ! $this->upload->do_upload('category_image')) {
				$error = array('error' => $this->upload->display_errors());           
			}else { 
				$data = array('upload_data' => $this->upload->data());			  
				$this->resizeImage($data['upload_data']['file_name']);
		  		
            }			
				
			$name=$this->upload->data('file_name');   
			$name1="product/".$name;
		
            $params = array(
				'cat_status' => $this->input->post('cat_status'),
				'category_name' => $this->input->post('category_name'),
				'category_code' => $this->input->post('category_code'),
				'category_image' =>  $name1,
				'created' => date('Y-m-d')
				//'modified' => $this->input->post('modified'),
            );
            
            $category_id = $this->Category_model->add_category($params);
            redirect('category/index');
        }
        else
        {            
            $data['_view'] = 'category/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a category
     */
    function edit($category_id)
    {   
		
        // check if the category exists before trying to edit it
        $data['category'] = $this->Category_model->get_category($category_id);
        
		
        if(isset($data['category']['category_id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('category_name','Category Name','required');
			$this->form_validation->set_rules('category_code','Category Code','required');
			$this->form_validation->set_rules('cat_status','Cat Status','required');
			
			if($this->form_validation->run())     
            {   
				
				if($_FILES['category_img']['name']!=''){					
					$source_path  = './uploads/product/'; 
					$target_path  = './uploads/product/thumbnail/'; 				  
					$config['upload_path']   = './uploads/product/'; 
					$config['allowed_types'] = 'gif|jpg|png'; 		
					$this->load->library('upload', $config);
					if(!$this->upload->do_upload('category_img')) {
						$error = array('error' => $this->upload->display_errors()); 
				  
					}else{ 
						$data = array('upload_data' => $this->upload->data()); 		
						$this->resizeImage($data['upload_data']['file_name']);
			
					} 
						$name=$this->upload->data('file_name');   			
						$name1="product/".$name;
						//$params['category_image'] =  $name1;	
				}
                $params = array(
					'cat_status' => $this->input->post('cat_status'),
					'category_name' => $this->input->post('category_name'),
					'category_code' => $this->input->post('category_code'),
					//'created' => $this->input->post('created'),
					'modified' => date('Y-m-d'),
					'category_image'=>$name1
                );

                $this->Category_model->update_category($category_id,$params);            
                redirect('category/index');
            }
            else
            {
                $data['_view'] = 'category/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The category you are trying to edit does not exist.');
    } 

    /*
     * Deleting category
     */
    function remove($category_id){
        $category = $this->Category_model->get_category($category_id);

        // check if the category exists before trying to delete it
        if(isset($category['category_id']))
        {
            $this->Category_model->delete_category($category_id);
            redirect('category/index');
        }
        else
            show_error('The category you are trying to delete does not exist.');
    }
	
			public function user_logged() {
     // if (isset($this->session->userdata('user_role')) && $this->session->userdata('user_role') != "")
      if ($this->session->userdata['get_loginuserdetails']['role'] != ""){
            return true;
        } else {
            return false;
        }
    }
	
	public function resizeImage($filename){
       	$source_path  = './uploads/product/'.$filename; 
		$target_path  = './uploads/product/thumbnail/'.$filename; 

		$config_manip['image_library'] = 'gd2';
		$config_manip = array(
			  'image_library' => 'gd2',
			  'source_image' => $source_path,
			  'new_image' => $target_path,
			  'maintain_ratio' => TRUE,
			  'create_thumb' => TRUE,
			  'thumb_marker' => '_thumb',
			  'width' => 360,
			  'height' => 220
		);


		$this->load->library('image_lib', $config_manip);
		if (!$this->image_lib->resize()) {
			echo  $this->image_lib->display_errors();
			exit;
		}	  
		$this->image_lib->clear();
    }
	
		
}
