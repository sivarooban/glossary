-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2020 at 10:33 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `glossary_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_image` varchar(40) NOT NULL,
  `category_name` varchar(250) NOT NULL,
  `category_code` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cat_status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_image`, `category_name`, `category_code`, `created`, `modified`, `cat_status`) VALUES
(15, 'product/download.jpg', 'LENTILS AND BEANS', '100', '2020-02-19 20:44:28', '0000-00-00 00:00:00', 1),
(16, 'product/maharastra.jpg', 'SPICES & MASALAS', '200', '2020-02-19 20:44:39', '0000-00-00 00:00:00', 1),
(17, 'product/flour.jpg', 'FLOUR', '300', '2020-02-19 20:44:46', '0000-00-00 00:00:00', 1),
(18, 'product/nut.jpg', 'DRIED FRUITS & NUTS', '400', '2020-02-19 20:44:51', '0000-00-00 00:00:00', 1),
(19, 'product/canned-food.jpg', 'CANNED FOODS', '600', '2020-02-19 20:44:57', '0000-00-00 00:00:00', 1),
(20, 'product/thumbnail/delish-u-rice-2-152907', 'RICE', '800', '2020-02-19 21:02:28', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ca_user`
--

CREATE TABLE `ca_user` (
  `user_id` int(11) NOT NULL,
  `user_username` char(100) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `real_password` varchar(500) NOT NULL,
  `user_firstname` char(100) NOT NULL,
  `user_lastname` char(100) NOT NULL,
  `user_email_id` varchar(255) DEFAULT NULL,
  `user_mobile_number` varchar(30) DEFAULT NULL,
  `user_phone_number` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ca_user`
--

INSERT INTO `ca_user` (`user_id`, `user_username`, `user_password`, `real_password`, `user_firstname`, `user_lastname`, `user_email_id`, `user_mobile_number`, `user_phone_number`) VALUES
(100, 'admin', 'admin', 'admin', '', '', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `phone` int(11) NOT NULL,
  `address` text NOT NULL,
  `city` text NOT NULL,
  `message` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `customer_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `customer_name`, `email`, `phone`, `address`, `city`, `message`, `created`, `modified`, `customer_status`) VALUES
(1, 'erer', 'praveenhertzon01@gmail.com', 2147483647, '26,Bharathidasan nagar, haridranathi west', 'mannargudi', 'rerr', '2020-02-02 05:53:27', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` float NOT NULL,
  `description` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `order_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `product_id`, `customer_id`, `quantity`, `total_price`, `description`, `created`, `modified`, `order_status`) VALUES
(1, 2, 1, 10, 2000, 'jjjjhjh', '2020-02-02 05:53:27', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(512) NOT NULL,
  `product_code` varchar(250) NOT NULL,
  `product_img` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `product_status` int(11) NOT NULL DEFAULT '1',
  `category_id` int(11) NOT NULL,
  `sub_category_id` int(11) NOT NULL,
  `availability` text NOT NULL,
  `feature` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='products that can be added to cart';

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `product_code`, `product_img`, `description`, `price`, `created`, `modified`, `product_status`, `category_id`, `sub_category_id`, `availability`, `feature`) VALUES
(52, 'TOOR DHAAL', '20', 'product/toordhaal.png', 'YES', '10.00', '2020-02-19 00:00:00', '2020-02-19 20:59:52', 1, 15, 0, '1', 'YES');

-- --------------------------------------------------------

--
-- Table structure for table `product_admin`
--

CREATE TABLE `product_admin` (
  `admin_id` int(11) NOT NULL,
  `user_firstname` varchar(200) NOT NULL,
  `user_lastname` varchar(200) NOT NULL,
  `admin_username` varchar(100) NOT NULL,
  `admin_password` varchar(500) NOT NULL,
  `firm_id` varchar(100) NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_admin`
--

INSERT INTO `product_admin` (`admin_id`, `user_firstname`, `user_lastname`, `admin_username`, `admin_password`, `firm_id`, `role`) VALUES
(100000, 'Admin', '', 'demo', 'demo', '1', 1),
(100001, 'Sub Admin', 'demo', 'demo', 'demo', '1', 2),
(100002, 'iyyappan', 'iyyappan', 'iyyappan', 'e10adc3949ba59abbe56e057f20f883e', '1', 3);

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `product_images_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_rel_name` varchar(512) NOT NULL,
  `product_rel_img` varchar(250) NOT NULL,
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `category_id` int(11) NOT NULL,
  `sub_category_id` int(11) NOT NULL,
  `product_images_status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='image files related to a product';

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`product_images_id`, `product_id`, `product_rel_name`, `product_rel_img`, `created`, `modified`, `category_id`, `sub_category_id`, `product_images_status`) VALUES
(105, 1, 'watch1', 'cart_img_two.jpg', '0000-00-00 00:00:00', '2019-02-17 11:38:00', 1, 1, 1),
(106, 1, 'watch2', 'cart_img_three.jpg', '0000-00-00 00:00:00', '2019-02-17 11:30:52', 2, 2, 1),
(107, 1, 'watch3', 'cart_img_five.jpg', '0000-00-00 00:00:00', '2019-02-17 11:38:07', 1, 1, 1),
(108, 2, 'Bag2', 'product_rel_img/Screenshot_(5).png', '0000-00-00 00:00:00', '2019-02-17 11:30:55', 2, 2, 1),
(109, 4, 'sss', 'product_rel_img/Screenshot_(13).png', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 0),
(110, 50, 'hj', 'product_related/IMG_8584.JPG', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_setting`
--

CREATE TABLE `product_setting` (
  `product_setting_id` int(255) NOT NULL,
  `no_of_slider` int(255) NOT NULL,
  `no_of_products` int(255) NOT NULL,
  `no_of_service` int(255) NOT NULL,
  `no_of_gallery` int(255) NOT NULL,
  `contact_type` enum('beginner','intermediate','advance') NOT NULL DEFAULT 'beginner',
  `no_of_logogallery` enum('yes','no') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `service_id` int(255) NOT NULL,
  `service_title` varchar(255) NOT NULL,
  `service_description` varchar(255) NOT NULL,
  `service_image` varchar(255) NOT NULL,
  `service_order_by` int(255) NOT NULL,
  `service_status` enum('active','inactive') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE `sub_category` (
  `sub_category_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_name` varchar(250) NOT NULL,
  `subcategory_code` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `sub_cat_status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_category`
--

INSERT INTO `sub_category` (`sub_category_id`, `category_id`, `subcategory_name`, `subcategory_code`, `created`, `modified`, `sub_cat_status`) VALUES
(1, 1, 'subcat1', '', '2019-02-18 13:00:00', '0000-00-00 00:00:00', 1),
(2, 1, 'subcat2', '', '2019-02-17 13:00:00', '0000-00-00 00:00:00', 1),
(3, 9, 'test', '44', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_admin`
--
ALTER TABLE `product_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`product_images_id`);

--
-- Indexes for table `product_setting`
--
ALTER TABLE `product_setting`
  ADD PRIMARY KEY (`product_setting_id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD PRIMARY KEY (`sub_category_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `product_admin`
--
ALTER TABLE `product_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100003;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `product_images_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `product_setting`
--
ALTER TABLE `product_setting`
  MODIFY `product_setting_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `service_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sub_category`
--
ALTER TABLE `sub_category`
  MODIFY `sub_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
