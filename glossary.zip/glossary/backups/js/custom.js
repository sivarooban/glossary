
// google map
// var map = '';
// var center;

// function initialize() {
//     var mapOptions = {
//       zoom: 16,
//       center: new google.maps.LatLng(40.7679619,-73.9800172),
//       scrollwheel: false
//     };
  
//     map = new google.maps.Map(document.getElementById('map-canvas'),  mapOptions);

//     google.maps.event.addDomListener(map, 'idle', function() {
//         calculateCenter();
//     });
  
//     google.maps.event.addDomListener(window, 'resize', function() {
//         map.setCenter(center);
//     });
// }

// function calculateCenter() {
//   center = map.getCenter();
// }

// function loadGoogleMap(){
//     var script = document.createElement('script');
//     script.type = 'text/javascript';
//     script.src = 'https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false&' + 'callback=initialize';
//     document.body.appendChild(script);
// }

// Flexslider
$(function(){
  /* FlexSlider */
  $('.flexslider').flexslider({
      easing: 'swing',
      directionNav: false,
      controlNav: true,
      touch: true,
      slideshow: true,
      animationSpeed: 1000
  });

  new WOW().init();

  // loadGoogleMap();
});

// isotope
jQuery(document).ready(function($){

  if ( $('.iso-box-wrapper').length > 0 ) { 

      var $container  = $('.iso-box-wrapper'), 
        $imgs     = $('.iso-box img');

      $container.imagesLoaded(function () {

        $container.isotope({
        layoutMode: 'fitRows',
        itemSelector: '.iso-box'
        });

        $imgs.load(function(){
          $container.isotope('reLayout');
        })

      });

      //filter items on button click
      $('.filter-wrapper li a').click(function(){

          var $this = $(this), filterValue = $this.attr('data-filter');

      $container.isotope({ 
        filter: filterValue,
        animationOptions: { 
            duration: 750, 
            easing: 'linear', 
            queue: false, 
        }                
      });             

      // don't proceed if already selected 
      if ( $this.hasClass('selected') ) { 
        return false; 
      }

      var filter_wrapper = $this.closest('.filter-wrapper');
      filter_wrapper.find('.selected').removeClass('selected');
      $this.addClass('selected');

        return false;
      }); 

  }

});

// Hide mobile menu after clicking on a link
    $('.navbar-collapse a').click(function(){
        $(".navbar-collapse").collapse('hide');
    });

//jQuery for page scrolling feature - requires jQuery Easing plugin
    // $(function() {
    //     $('.navbar-default a, a,').bind('click', function(event) {
    //         var $anchor = $(this);
    //         $('html, body').stop().animate({
    //             scrollTop: $($anchor.attr('href')).offset().top - 68
    //         }, 1000);
    //         event.preventDefault();
    //     });
    // });
   $('.progress .progress-bar').css("width",
                function() {
                    return $(this).attr("aria-valuenow") + "%";
                }
        )
   $(window).load(function() {
      
     $('#loadimg').fadeOut("slow");
   });

   // 11-05-17 starts here

  /* wait for images to load */
  $(window).load(function() {
    $('.sp-wrap').smoothproducts();
  });

   // 11-05-17 ends here


   // 12-05-17 starts here

    $(document).ready(function() {
         $('#form_style').bootstrapValidator({
           
            fields: {
            fullname: {
                row: '.col-xs-4',
                validators: {
                    notEmpty: {
                        message: 'The name is required'
                    }
                }
            },
             mobilenumbr: {
                row: '.col-xs-4',
                validators: {
                    notEmpty: {
                        message: 'The Phone Number is required'
                    },
                    phone: {             
                        message: 'Please supply a vaild phone number'
                    }
                }
            },
            email: {
                row: '.col-xs-4',
                validators: {
                    notEmpty: {
                        message: 'The business email is required'
                    },
                    emailAddress: {
                        message: 'Please supply a valid email address'
                    }
                }
            },
            address: {
                row: '.col-xs-4',
                validators: {
                    notEmpty: {
                        message: 'The field is required'
                    }
                }
            },
            city: {
                row: '.col-xs-4',
                validators: {
                    notEmpty: {
                        message: 'The field is required'
                    }
                }
            },
            message: {
                row: '.col-xs-4',
                validators: {
                    notEmpty: {
                        message: 'The field is required'
                    }
                }
            }
            }
        })        
       function enquirySubmit() {
          document.getElementById("form_style").submit();
          console.log();
      }
    });

   // 12-05-17 ends here

   // 15-05-17 starts here
   (function ($) {
  $('.spinner .btn:first-of-type').on('click', function() {
    $('.spinner input').val( parseInt($('.spinner input').val(), 10) + 1);
  });
  $('.spinner .btn:last-of-type').on('click', function() {
    $('.spinner input').val( parseInt($('.spinner input').val(), 10) - 1);
  });
  $('.spinner_one .btn:first-of-type').on('click', function() {
    $('.spinner_one input').val( parseInt($('.spinner_one input').val(), 10) + 1);
  });
  $('.spinner_one .btn:last-of-type').on('click', function() {
    $('.spinner_one input').val( parseInt($('.spinner_one input').val(), 10) - 1);
  });
   $('.spinner_two .btn:first-of-type').on('click', function() {
    $('.spinner_two input').val( parseInt($('.spinner_two input').val(), 10) + 1);
  });
  $('.spinner_two .btn:last-of-type').on('click', function() {
    $('.spinner_two input').val( parseInt($('.spinner_two input').val(), 10) - 1);
  });
  $('.spinner_three .btn:first-of-type').on('click', function() {
    $('.spinner_three input').val( parseInt($('.spinner_three input').val(), 10) + 1);
  });
  $('.spinner_three .btn:last-of-type').on('click', function() {
    $('.spinner_three input').val( parseInt($('.spinner_three input').val(), 10) - 1);
  });
})(jQuery);

   // 15-05-17 ends here
  