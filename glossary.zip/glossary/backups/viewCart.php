<?php
// initializ shopping cart class
//error_reporting(0);
include("header.php");
include 'Cart.php';
$cart = new Cart;
?>

<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <title>View Cart - PHP Shopping Cart Tutorial</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
    .container{padding: 50px;}
    input[type="number"]{width: 20%;}
    </style>
    <script>
    function updateCartItem(obj,id){
        $.get("cartAction.php", {action:"updateCartItem", id:id, qty:obj.value}, function(data){
            if(data == 'ok'){
                location.reload();
            }else{
                alert('Cart update failed, please try again.');
            }
        });
    }
    </script>
</head>
</head>
<body> -->
<!-- Services Section -->
<div id="product_enquiry">
<div id="services">
  <div class="container">
    <div class="section-title">
      <h2>Our Products</h2>
    </div>
         
                <div class="row">
<form name="orders" id="orders" action="productaction.php" method="post">
  <div class="col-md-8 col-sm-8 col-xs-12">

  <a id="btnEmpty" style="float:left" class="btnAddAction btn btn-success" href="cartAction.php?action=emptyCart">Empty Cart</a>
   <a id="btnEmpty" style="float:right"  class="btnAddAction btn btn-success" href="product.php">Continue Shopping</a><br><br>
            
          <table class="table table-bordered table-hover">
            <thead>
              <tr>
                <th class="text-center">Product-Title</th>
                <th class="text-center">Product-image</th>
                <th class="text-center">Quantity</th>
                <th class="text-center">Price</th>
                <th class="text-center">Description</th>
                 <th class="text-center">Total</th>
                <th class="text-center">Action</th>
              </tr>
            </thead>
            <tbody>
        <?php
        if($cart->total_items() > 0){
            //get cart items from session
           // 
        //  echo "<pre>";
            $cartItems = $cart->contents();
            //echo "<pre>";
            //print_r($cartItems); 
            foreach($cartItems as $item){
        ?>
        <tr>
            <td><?php echo $item["name"]; ?></td>
            <td>            
                  <img src="img/<?php echo $item["product_image"]; ?>"  style="width:37px; height:28px" class="img-responsive  product_enquiry">
            </td>
           
            <td><input type="number"  class="form-control text-center" value="<?php echo $item["qty"]; ?>" onchange="updateCartItem(this, '<?php echo $item["rowid"]; ?>')"></td>
              <td><?php echo 'Rs '.$item["price"].' '; ?></td>

            <td>
              <textarea class="form-control" value="<?php echo $item["desc_details"]; ?>" onchange="updateCartItem1(this, '<?php echo $item["rowid"]; ?>')"><?php echo $item["desc_details"]; ?></textarea>
            </td>

           
             
            <td><?php echo 'Rs '.$item["subtotal"].' '; ?></td>
            <td>
                <a href="cartAction.php?action=removeCartItem&id=<?php echo $item["rowid"]; ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')"><i class="glyphicon glyphicon-trash"></i></a>
            </td>
        </tr>
        <?php } 
		
		?>
            <tfoot>
        <tr>
           <!--  <td><a href="product.php" class="btn btn-warning"><i class="glyphicon glyphicon-menu-left"></i> Continue Shopping</a></td> -->
            <td colspan="5">Total</td>
            <?php if($cart->total_items() > 0){ ?>
            <td class="text-center"><strong> <?php echo 'Rs '.$cart->total().' '; ?></strong></td>
           <!-- <td><a href="checkout.php" class="btn btn-success btn-block">Checkout <i class="glyphicon glyphicon-menu-right"></i></a></td>-->
            <?php } ?>
        </tr>
    </tfoot>
    <?php
	}
		else{ ?>
        <tr><td colspan="7"><p>Your cart is empty.....</p></td>
        <?php } ?>
    </tbody>


          </table>
          
          

          </div>
          <div class="col-md-4 col-sm-4 col-xs-12">
             
              <h3 class="text-center">Enquire Now<i class="fa fa-long-arrow-right" id="arrow_form" aria-hidden="true"></i></h3>
              <div class="form-group">
                <label for="fullname">Full Name:</label>
                <input class="form-control" id="fullname" name="fullname" required>
              </div>
              <div class="form-group">
                <label for="mobilenumbr">Mobile Number:</label>
                <input class="form-control" id="mobilenumbr" name="mobilenumbr" required>
              </div>
              <div class="form-group">
                <label for="email">Email:</label>
                <input class="form-control" id="email" name="email" required>
              </div>
              <div class="form-group">
                <label for="address">Address:</label>
                <input class="form-control" id="address" name="address" required>
              </div>
              <div class="form-group">
                <label for="city">City:</label>
                <input class="form-control" id="city" name="city" required>
              </div>
              <div class="form-group">
                <label for="message">Message:</label>
                <textarea class="form-control" id="message" rows="5" placeholder="Enter Your Message" name="message" required></textarea>
              </div>
              <div class="submit_btn">
                <button type="submit" name="save" id="save" class="btn btn-danger" >Enquire Now</button><!-- onClick="enquirySubmit()" -->
              </div>
         
          </div>
        </div>
      </form>
  </div>
</div>
</div>
<?php
include("footer.php");
?>

 


