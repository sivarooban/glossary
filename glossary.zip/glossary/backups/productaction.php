<?php
include("db_conn.php");
include 'Cart.php';
$cart = new Cart;
if(isset($_POST["save"])){
   
   
  // unset($_SESSION['cart_contents']);
					//header("Refresh:0");
					//header("Refresh:0; url=cartAction.php?action=emptyCart");
				
   
      $name = $_POST['fullname'];
      $phone = $_POST['mobilenumbr'];
      $email = $_POST['email'];
      $address = $_POST['address'];
      $city = $_POST['city'];
      $message = $_POST['message'];

$sql = "INSERT INTO customers (customer_name, phone, email,address,city,message,customer_status)
VALUES ('".$name."', '".$phone."', '".$email."','".$address."', '".$city."','".$message."',1)";

if (mysqli_query($conn, $sql)) {

      $sql1 = "select max(customer_id) id from customers ";
       $result = $conn->query($sql1); 
          while($row = $result->fetch_assoc()) {
       
              $customer_id= $row['id'];
            }
      if($cart->total_items() > 0){
                  //get cart items from session
                 // echo "<pre>";
                  $cartItems = $cart->contents();
                  //print_r($cartItems);die; product_id customer_id quantity  total_price description created modified  order_status
                  foreach($cartItems as $item){
                    //print_r($item);  
                           $sql3 = "INSERT INTO orders (product_id, customer_id, quantity,total_price, description,order_status)
                          VALUES ('".$item['id']."', '".$customer_id."', '".$item['qty']."','".$item['price']."', '".$item['desc_details']."' ,1)";

                           if (mysqli_query($conn, $sql3)) {
						   
						   
            /*                  echo '<div id="light" class="white_content">Your orders are added successfully.We will contact  soon... <a href="javascript:void(0)" onclick="document.getElementById("light").style.display="none";document.getElementById("fade").style.display="none">Close</a>
  </div>';*/
                          } else {
                              echo "Error: " . $sql3 . "<br>" . mysqli_error($conn);
                          }    

                       }
					   
					 //  session_destroy();
					    
		/*			      echo '<div id="light" class="white_content">Your orders are added successfully.We will contact  soon... <a href="javascript:void(0)" onclick="document.getElementById("light").style.display="none";document.getElementById("fade").style.display="none">Close</a>
  </div>';*/
                    }
					
				header("Location:cartAction.php?action=emptyCart");die;		
  
 }


}
?>