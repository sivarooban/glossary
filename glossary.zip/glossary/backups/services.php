 <?php 
 @ob_start();
 include("header.php"); 
 include("db_conn.php"); 
?>



<!-- Services Section -->
<div id="services">
  <div class="container">
    <div class="section-title">
      <h2>Our Services</h2>
    </div>
    <div class="row">
      <div class="col-md-4">
        <div class="service-media"> <img src="img/services/service-1.jpg" alt=" "> </div>
        <div class="service-desc">
          <h3>Offset brochure printing service</h3>
          <p>We design brochure by highly skilled professionals. So, our brochure designs will attract more targeted customers and helps in development of your business.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="service-media"> <img src="img/services/service-2.jpg" alt=" "> </div>
        <div class="service-desc">
          <h3>Pamphlet printing</h3>
          <p>A pamphlet is a single sheet of paper ,an unbound booklet,  printed on single side or both side. Pamphlet is widely used to popularize political or religious ideas or business needs.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="service-media"> <img src="img/services/service-3.png" alt=" "> </div>
        <div class="service-desc">
          <h3>ID card designing</h3>
          <p>ID card bears the information about the person with photograph. It also includes name, address and other personal information’s.cards are mainly focused in school, colleges and corporate offices.</p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-4">
        <div class="service-media"> <img src="img/services/service-4.jpg" alt=" "> </div>
        <div class="service-desc">
          <h3>Wedding card designing and printing</h3>
          <p>Wedding card designing and printing service is done in both digital and offset printing with high quality. This bond of union is made for lifelong and this union is done by God.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="service-media"> <img src="img/services/service-5.jpg" alt=" "> </div>
        <div class="service-desc">
          <h3>Flyers printing</h3>
          <p>Flyers are used by the individuals or businesses to promote their products or services. Flyers are suitable for mass distribution.  Fliers are mostly used for advertising a service or events or other activity</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="service-media"> <img src="img/services/service-6.jpg" alt=" "> </div>
        <div class="service-desc">
          <h3>Calendar printing service</h3>
          <p>Create a printable calendar for a large number of countries with holiday listed. Support for A4, letter and legal. Monthly and yearly calendars available</p>
        </div>
      </div>
    </div>
  </div>
</div>




 <?php  include("footer.php");  ?>
