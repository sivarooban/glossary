<?php
@ob_start(); 
session_start();
include("header.php");
include("db_conn.php"); 

 $product_id = $_GET["product_id"];

 
            
              $sql="SELECT * FROM products where product_status=1 and product_id='$product_id' ORDER BY product_id  ASC"; 
              $result = $conn->query($sql); 
                
              if ($result->num_rows > 0) {
              // output data of each row
              while($row = $result->fetch_assoc()) {  
                 $product_id = $row['product_id'];
                  $product_name = $row['product_name'];
                  $product_code = $row['product_code'];
                  $price = $row['price'];
                  $availability = $row['availability'];
                  $product_img = $row['product_img'];
                  $description = $row['description'];
                  $feature = $row['feature'];

       // print_r($product_id);die;
	   //	echo md5(2);
	$v=md5($product_id);
	// echo "<pre>";
	$ros=$_SESSION['cart_contents'][$v];
	//print_r($ros);

	
	if($ros['id']==$product_id){
	$pdetails=$ros['desc_details'];
	}
	else
	{
	$pdetails='';
	}
	
?>


<!-- Services Section -->

<div id="services">
  <div class="container">
    <div class="section-title">
      <h2>Our Products</h2>
    </div>
             
                 <div class="row">
               <!--?action=addToCart&id=<?php echo $product_id; ?>-->
                 <form method="get" action="cartAction.php" autocomplete="off">
          <p class="prodts">products > product_1</p>
          <h2 class=prod_head> Product_1 </h2>
          <div class="col-md-6 col-sm-6 col-xs-12">           
            <div class="sp-wrap " id="smoothproducts_align">
             <a href="img/<?php echo $product_img ?>">
                <img src="img/<?php echo $product_img ?>" alt=""> 
                <?php   

                $sql="SELECT * FROM product_images where product_images_status=1 and product_id='$product_id' ORDER BY product_id  ASC"; 
              $result = $conn->query($sql); 
                //echo $sql;
              if ($result->num_rows > 0) {
              // output data of each row
              while($row = $result->fetch_assoc()) {  
                  
                  $product_rel_img = $row['product_rel_img'];

                   
                ?>
              <a  href="img/<?php echo $product_rel_img ?>">
                <img src="img/<?php echo $product_rel_img ?>" alt="" /> </a>
                   

             <?php }
           }
             
            ?>
            </a>
            </div>
          </div>
              <input type="hidden" name="action" id="action" value="addToCart" />
                  <input type="hidden" name="id" id="id" value="<?php echo $product_id; ?>" />
          <div class="col-md-6 col-sm-6 col-xs-12 prod_info">
            <h2><?php echo $product_name; ?></h2>
            <p><?php echo $price;?></p>
            <p><b>item code:</b> <?php echo $product_code;?></p>
            <p><b>Availability:</b> <?php echo $availability;?></p>
            <p><b>item code:</b> 6011</p>
            <span style="    font-size: 20px;
    line-height: 2;"><b>Quantity :  </b></span>       <input type="text" name="qty_line" id="qty_line" value="1" />
           
          
           
            <input type="hidden" name="qty_details" id="qty_details" value="<?php echo $pdetails;?>" />
           
           <input type="submit" class="btn btn-success"  name="submitdetails" id="submitdetails" value="Add to cart" />
            <!-- <button type="button" class="btn btn-default">Add to cart</button> -->
            <!-- <a class="btn btn-success" href="cartAction.php?action=addToCart&id=<?php echo $product_id; ?>">Add to cart</a>-->
           <!-- <a href="product-enquiry.html" target="_self" class="btn btn-success">Add to Enquiry</a>-->
          </div>
        </div>
        </form>
        <div class="row tabs_align">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <ul class="nav nav-tabs">
              <li class="active"><a data-toggle="tab" href="#description">Description</a></li>
              <li><a data-toggle="tab" href="#feature">Feature</a></li>
            </ul>
            <div class="tab-content">
              <div id="description" class="tab-pane fade in active">
                <h3>The Fruit</h3>

                <p><?php echo $description; ?></p>
              </div>
              <div id="feature" class="tab-pane fade">
                <h3>The product</h3>
                <p><?php echo $feature; ?></p>
              </div>
            </div>
          </div>
        </div>
        <?php
              }
           }
?>
   
  </div>
</div>

  
  

<?php
include("footer.php");
?>

