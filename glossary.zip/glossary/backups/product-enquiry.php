<?php
@ob_start();
session_start();
error_reporting(0);
include("header.php");
//include("db_conn.php");
require_once("dbcontroller.php");
$db_handle = new DBController();

if(!empty($_GET["action"])) {
switch($_GET["action"]) {
  case "add":
    if(!empty($_POST["quantity"])) {
      $productByCode = $db_handle->runQuery("SELECT * FROM products WHERE product_id='" . $_GET["code"] . "'");
      $itemArray = array($productByCode[0]["product_id"]=>array('name'=>$productByCode[0]["product_name"], 'product_id'=>$productByCode[0]["product_id"], 'quantity'=>$_POST["quantity"], 'price'=>$productByCode[0]["price"], 'image'=>$productByCode[0]["product_img"]));
      
      if(!empty($_SESSION["cart_item"])) {
        if(in_array($productByCode[0]["product_id"],array_keys($_SESSION["cart_item"]))) {
          foreach($_SESSION["cart_item"] as $k => $v) {
              if($productByCode[0]["product_id"] == $k) {
                if(empty($_SESSION["cart_item"][$k]["quantity"])) {
                  $_SESSION["cart_item"][$k]["quantity"] = 0;
                }
                $_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
              }
          }
        } else {
          $_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
        }
      } else {
        $_SESSION["cart_item"] = $itemArray;
      }
    }
  break;
  case "remove":
  //print_r($_SESSION);
    if(!empty($_SESSION["cart_item"])) {
      foreach($_SESSION["cart_item"] as $k => $v) {
          if($_GET["product_id"] == $k)
            unset($_SESSION["cart_item"][$k]);        
          if(empty($_SESSION["cart_item"]))
            unset($_SESSION["cart_item"]);
        /*  else
               unset($_SESSION["cart_item"]);*/
      }
    }
  break;
  case "empty":
    unset($_SESSION["cart_item"]);
  break;  
  }
}
?>

<!-- Services Section -->
<div id="product_enquiry">
<div id="services">
  <div class="container">
    <div class="section-title">
      <h2>Our Products</h2>
    </div>
         
                <div class="row">

  <div class="col-md-8 col-sm-8 col-xs-12">

  <a id="btnEmpty" style="float:left" class="btnAddAction btn btn-success" href="product-enquiry.php?action=empty">Empty Cart</a>
   <a id="btnEmpty" style="float:right"  class="btnAddAction btn btn-success" href="product.php">Continue Shopping</a><br><br>
            
          <table class="table table-bordered table-hover">
            <thead>
              <tr>
                <th class="text-center">Product-Title</th>
                <th class="text-center">Product-image</th>
                <th class="text-center">Quantity</th>
                <th class="text-center">Price</th>
                <th class="text-center">Description</th>
                <th class="text-center">Action</th>
              </tr>
            </thead>
            <tbody>
                  <?php
if(isset($_SESSION["cart_item"])){

  //print_r($_SESSION["cart_item"]);die;
    $total_quantity = 0;
    $total_price = 0;
    
    foreach ($_SESSION["cart_item"] as $item){
        $item_price = $item["quantity"]*$item["price"];
    ?>
              <tr>
                 <td class="text-center"><?php echo $item["name"]; ?></td>
                 <td>            
                  <img src="img/<?php echo $item["image"]; ?>" class="img-responsive  product_enquiry">
                </td>
                <td class="text-center"><div class="input-group spinner">
                    <input type="text" class="form-control" value="<?php echo $item["quantity"]; ?>">
                  <!--  <div class="input-group-btn-vertical">
                      <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
                      <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
                    </div>
                  </div>--> </td>
               
                <td class="text-center"><?php echo "$ ".$item["price"]; ?></td>
                  <td class="text-center">
                  <div class="input-group ">
                    <input type="text" class="form-control" value="">
                    <div class="input-group-btn-vertical">
                    
                    </div>
                  </div>
                </td>
                <td class="text-center"><a href="product-enquiry.php?action=remove&code=<?php echo $item["product_id"]; ?>" class="btnRemoveAction"><img src="img/icon-delete.png"  style="width:27px; height:18px"  alt="Remove Item" /></a></td>
              </tr>
             <?php  
       $total_quantity += $item["quantity"];
        $total_price += ($item["price"]*$item["quantity"]);
         }
     
     ?>
         <tr>
<td colspan="2" align="right">Total:</td>
<td align="right"><?php echo $total_quantity; ?></td>
<td align="right" colspan="2"><strong><?php echo "$ ".number_format($total_price, 2); ?></strong></td>
<td></td>
</tr>

<?php } else {
?>
<tr><td colspan="6">
<center>Your Cart is Empty</center></td>
</tr>
<?php 
}
?>
         
         
            </tbody>
          </table>
          
          

          </div>
          <div class="col-md-4 col-sm-4 col-xs-12">
            <form id="form_style">
              <h3 class="text-center">Enquire Now<i class="fa fa-long-arrow-right" id="arrow_form" aria-hidden="true"></i></h3>
              <div class="form-group">
                <label for="fullname">Full Name:</label>
                <input class="form-control" id="fullname" name="fullname" required>
              </div>
              <div class="form-group">
                <label for="mobilenumbr">Mobile Number:</label>
                <input class="form-control" id="mobilenumbr" name="mobilenumbr" required>
              </div>
              <div class="form-group">
                <label for="email">Email:</label>
                <input class="form-control" id="email" name="email" required>
              </div>
              <div class="form-group">
                <label for="address">Address:</label>
                <input class="form-control" id="address" name="address" required>
              </div>
              <div class="form-group">
                <label for="city">City:</label>
                <input class="form-control" id="city" name="city" required>
              </div>
              <div class="form-group">
                <label for="message">Message:</label>
                <textarea class="form-control" id="message" rows="5" placeholder="Enter Your Message" name="message" required></textarea>
              </div>
              <div class="submit_btn">
                <button type="submit" class="btn btn-danger" onClick="enquirySubmit()">Enquire Now</button>
              </div>
            </form>
          </div>
        </div>
   
  </div>
</div>
</div>


<?php
include("footer.php");
?>




