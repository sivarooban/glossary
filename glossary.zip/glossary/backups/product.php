 <?php 
 @ob_start();
 include("header.php"); 
 include("db_conn.php"); 
?>


<!-- Services Section -->
<div id="services">
  <div class="container">
    <div class="section-title">
      <h2>Our Products</h2>
    </div>
         <div class="row">
          
        </div>
        <div class="row prodt_row_align">
          <?php 
            
              $sql="SELECT * FROM products where product_status=1 ORDER BY product_id  ASC"; 
              $result = $conn->query($sql); 
                
              if ($result->num_rows > 0) {
              // output data of each row
              while($row = $result->fetch_assoc()) {                    
          ?>                   
         
          <div class="col-md-3 col-sm-3 col-xs-12">
            <div class="thumbnail prdt_thumnail">
              <a href="product-detail.php?product_id=<?php echo $row['product_id']; ?> " target="_self">
                <img src="img/<?php echo $row['product_img'] ?>" alt="dummy"> 
                <div class="caption">
                  <h3><?php echo $row['product_name']; ?> </h3>
                  <p><?php echo $row['price']; ?></p>
                </div>
              </a>
            </div>
          </div>
          <?php 
                    
              } 
            }
          ?>

         
       

        </div>
   
  </div>
</div>

<!--<div id="services">
  <div class="container">
    <div class="section-title">
      <h2>Our Products</h2>
    </div>
         <div class="row">
          
        </div>
        <div class="row prodt_row_align">
          <div class="col-md-3 col-sm-3 col-xs-12">
            <div class="thumbnail prdt_thumnail">
              <a href="product-detail.html" target="_self">
                <img src="img/dummy.jpg" alt="dummy">
                <div class="caption">
                  <h3>Product_1</h3>
                  <p>Price:$450</p>
                </div>
              </a>
            </div>
          </div>
          <div class="col-md-3 col-sm-3 col-xs-12">
            <div class="thumbnail prdt_thumnail">
              <a href="product-detail.html" target="_self">
                <img src="img/dummy.jpg" alt="dummy">
                <div class="caption">
                  <h3>Product_2</h3>
                  <p>Price:$450</p>
                </div>
              </a>
            </div>
          </div>
          <div class="col-md-3 col-sm-3 col-xs-12">
            <div class="thumbnail prdt_thumnail">
              <a href="product-detail.html" target="_self">
                <img src="img/dummy.jpg" alt="dummy">
                <div class="caption">
                  <h3>Product_3</h3>
                  <p>Price:$450</p>
                </div>
              </a>
            </div>
          </div>
          <div class="col-md-3 col-sm-3 col-xs-12">
            <div class="thumbnail prdt_thumnail">
              <a href="product-detail.html" target="_self">
                <img src="img/dummy.jpg" alt="dummy">
                <div class="caption">
                  <h3>Product_4</h3>
                  <p>Price:$450</p>
                </div>
              </a>
            </div>
          </div>
        </div>
   
  </div>
</div>-->

 <?php  include("footer.php");  ?>

