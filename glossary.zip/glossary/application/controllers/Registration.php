<?php
	class Registration extends CI_Controller{
		function __construct(){
			parent::__construct();
			error_reporting(0);
			$this->load->model('Ca_login_model');
			$this->load->model('Register_model');
		} 

		/*
		 * Listing of ca_customer
		 */
		function index(){		
			$data_category = $this->Ca_login_model->get_all_category();
			//$pincode_data  = $this->Register_model->getall_pincode();
			
			$data4 = [];
			foreach($data_category as $value){
				$data5 = $this->Ca_login_model->product_category($value['category_id']);
				$product_data = [];			
				foreach($data5 as $value1){
					$product_data[] = array('product_name' => $value1['product_name']);
				}
				$data4[] = array('category_name' => $value['category_name'],'product_datas'=>$product_data);
			}			
			$data['all_sub_category'] = $this->Ca_login_model->get_all_category();
			$data['product'] = $this->Ca_login_model->get_all_product();
			$data['pincode_data'] = $this->Register_model->getall_pincode();
			$data['menu'] = $data4;
			$data5['menu'] = $data4;		
			$data['_view'] = 'registration/registration';
			$this->load->view('layouts/main',$data);
		}

		function insert_register(){
			$json = file_get_contents('php://input');		
			$data = json_decode($json);
			$params = array(
				'email_address' => $data->email_address,
				'passwords' => $data->passwords,
				'dob' => $data->dob,
				'phone' => $data->phone,				
				'first_name' => $data->first_name,
				'last_name' => $data->last_name,		
				'house_no' =>  $data->house_no,				
				'street' => $data->street,
				'postal_code' => $data->postal_code,
				'city' => $data->city
			);
			$product_id = $this->Register_model->add_register($params);  
			$msg  = "email_address".$data->email_address."passwords".$data->passwords;
			mail("monox.ruban@gmail.com","Registration",$msg);	
		}	
}
