<?php
	class Cart extends CI_Controller{
		function __construct(){
			parent::__construct();
			error_reporting(0);
			$this->load->model('Ca_login_model');	
			$this->load->model('Product_model');
			$this->load->model('Cart_model');
			$this->load->model('Register_model');
		} 	

		function index(){		
			$data_category = $this->Ca_login_model->get_all_category();						
			$data4 = [];
			foreach($data_category as $value){
				$data5 = $this->Ca_login_model->product_category($value['category_id']);
				$product_data = [];			
				foreach($data5 as $value1){
					$product_data[] = array('product_name' => $value1['product_name']);
				}
				$data4[] = array('category_name' => $value['category_name'],'product_datas'=>$product_data);
			}			
			$data['all_sub_category'] = $this->Ca_login_model->get_all_category();
			$data['product'] = $this->Ca_login_model->get_all_product();						
			$data5['menu'] = $data4;		
			$data['_view'] = 'cart/cart';
			$data['pincode_data'] = $this->Register_model->getall_pincode();
			//if($this->order_get() != 0){
			  $result_data = $this->order_get();		
			
			//}			
			$deliver_date = $this->Cart_model->get_deliver_date($this->session->userId['id']);
			
			$data['result_user'] = $result_data;
			$data['deliver_date'] = $deliver_date[0]->order_date;
			$this->load->view('layouts/main',$data);
		}	
		
		function delete_order(){
			$json = file_get_contents('php://input');
			$data = json_decode($json);
			$order_p_id  = $data->order_id;
			$res = $this->Product_model->delete_order($order_p_id);		
		}
		function order_get(){
			if(!empty($this->session->userId)){			
				$data_category = $this->Cart_model->get_user_count($_GET['id']);				
				if($data_category == 0){
					$data1 = $this->Cart_model->date_cal();
					
					$data_string .= '+'.$data1.'days';
					
					
					$date = date('Y-m-d', strtotime($data_string));
					$datas = $this->Cart_model->find_user_details($this->session->userId['id']);
					
					$insert_data = array('email_address'=>$datas[0]->email_address,										 
										 'phone'=>$datas[0]->phone,
										 'first_name'=>$datas[0]->first_name,
										 'first_name'=>$datas[0]->first_name,
										 'last_name'=>$datas[0]->last_name,
										 'house_no'=>$datas[0]->house_no,
										 'street'=>$datas[0]->street,
										 'postal_code'=>$datas[0]->postal_code,
										 'city'=>$datas[0]->city,
										 'order_p_id'=>$_GET['id']
										);					
					$insert_data_order = array('order_date'=>$date,
										 'order_p'=>$_GET['id']
										);					
					//die();
					$this->Cart_model->add_order_address($insert_data,$insert_data_order,$_GET['id']);					
				}
				return $data44 = $this->Cart_model->get_user_data($_GET['id']);
				
			}		
		}
		function update_order(){
			$json = file_get_contents('php://input');
			$data = json_decode($json);
			
			$date5 =  $data->deliver_date;
			
			$data4 = explode("/",$date5);			
			$date5 = $data4[2]."-".$data4[1]."-".$data4[0];
			 $params = array(
				'email_address' => $data->email_address,
				'phone' => $data->phone,
				'first_name' => $data->first_name,
				'last_name' => $data->last_name,
				'house_no' => $data->house_no,
				'street' => $data->street,
				'postal_code' => $data->postal_code,
				'city' => $data->city
            );
            
			$params1 = array(								
				'cart_status'=>0
            );
			$msg  = "email_address".$data->email_address."Order Successfully Done";
			mail("monox.ruban@gmail.com","Registration",$msg);	
            echo $product_id = $this->Cart_model->update_cart($data->id,$params,$params1);
			//$order_p_id  = $data->order_id;
			//$res = $this->Product_model->delete_order($order_p_id);	
				
		}
}