<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Cm extends CI_Controller{
    function __construct()
    {
        parent::__construct();
			error_reporting(0);
        
			if ($this->session->userdata['get_loginuserdetails']['role'] != 1){
		redirect('Login/user_logout', 'refresh');
		}
		
		if (!$this->user_logged()) {
          redirect('Login/user_logout', 'refresh');
       }
        $this->load->model('Cm_model');
    } 

    /*
     * Listing of cms
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('cm/index?');
        $config['total_rows'] = $this->Cm_model->get_all_cms_count();
        $this->pagination->initialize($config);

        $data['cms'] = $this->Cm_model->get_all_cms($params);
        
        $data['_view'] = 'cm/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new cm
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('cms_title','Cms Title','required');
		$this->form_validation->set_rules('cms_description','Cms Description','required');
		
		if($this->form_validation->run())     
        {   
            $params = array(
				'cms_model' => $this->input->post('cms_model'),
				'cms_title' => $this->input->post('cms_title'),
				'cms_image' => $this->input->post('cms_image'),
				'cms_seo_title' => $this->input->post('cms_seo_title'),
				'cms_seo_description' => $this->input->post('cms_seo_description'),
				'cms_seo_keyword' => $this->input->post('cms_seo_keyword'),
				'cms_description' => $this->input->post('cms_description'),
            );
            
            $cm_id = $this->Cm_model->add_cm($params);
            redirect('cm/index');
        }
        else
        {            
            $data['_view'] = 'cm/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a cm
     */
    function edit($cms_id)
    {   
        // check if the cm exists before trying to edit it
        $data['cm'] = $this->Cm_model->get_cm($cms_id);
        
        if(isset($data['cm']['cms_id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('cms_title','Cms Title','required');
			$this->form_validation->set_rules('cms_description','Cms Description','required');
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'cms_model' => $this->input->post('cms_model'),
					'cms_title' => $this->input->post('cms_title'),
					'cms_image' => $this->input->post('cms_image'),
					'cms_seo_title' => $this->input->post('cms_seo_title'),
					'cms_seo_description' => $this->input->post('cms_seo_description'),
					'cms_seo_keyword' => $this->input->post('cms_seo_keyword'),
					'cms_description' => $this->input->post('cms_description'),
                );

                $this->Cm_model->update_cm($cms_id,$params);            
                redirect('cm/index');
            }
            else
            {
                $data['_view'] = 'cm/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The cm you are trying to edit does not exist.');
    } 

    /*
     * Deleting cm
     */
    function remove($cms_id)
    {
        $cm = $this->Cm_model->get_cm($cms_id);

        // check if the cm exists before trying to delete it
        if(isset($cm['cms_id']))
        {
            $this->Cm_model->delete_cm($cms_id);
            redirect('cm/index');
        }
        else
            show_error('The cm you are trying to delete does not exist.');
    }
	
			public function user_logged() {
     // if (isset($this->session->userdata('user_role')) && $this->session->userdata('user_role') != "")
      if ($this->session->userdata['get_loginuserdetails']['role'] != ""){
            return true;
        } else {
            return false;
        }
    }
    
}
