<?php

class Login extends CI_Controller{
    function __construct()
    {
        parent::__construct();
		error_reporting(0);
        $this->load->model('Ca_login_model');
		$this->load->library('session');
    } 

    /*
     * Listing of ca_customer
     */
    function index(){		
	
		
			/* echo "test";
			echo "<pre>";
			print_r($this->session->userId); 
			echo "test";
			die();*/
		$data_category = $this->Ca_login_model->get_all_category();
		
		$data4 = [];
		foreach($data_category as $value){
			$data5 = $this->Ca_login_model->product_category($value['category_id']);
			$product_data = [];			
			foreach($data5 as $value1){
				$product_data[] = array('product_name' => $value1['product_name']);
			}
			$data4[] = array('category_name' => $value['category_name'],'category_image' => $value['category_image'],'product_datas'=>$product_data);
		}
		
		$data['all_sub_category'] = $this->Ca_login_model->get_all_category();
		$data['product'] = $this->Ca_login_model->get_all_product();
		$data['menu'] = $data4;
		$data5['menu'] = $data4;
		//$this->load->view('header',$data5);
        //$this->load->view('login/login',$data)
		$data['_view'] = 'login/login';
        $this->load->view('layouts/main',$data);
    }

	/*
     * Get all category
     */
    function get_all_category($params = array())
    {
        $this->db->order_by('category_id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('category')->result_array();
    }
	
	function get_all_products($params = array())
    {
        $this->db->order_by('product_id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('products')->result_array();
    }
	
	
	function login_details(){        
        $json = file_get_contents('php://input');		
		$data = json_decode($json);		
        $uid=$data->user_loginid;
		$pass=$data->user_pwd;
		$userdetails = $this->Ca_login_model->login_details($uid,$pass);
		if(!empty($userdetails)){		 
			$this->session->set_userdata('userId', $userdetails);			
			echo json_encode(1);
        }else{
			echo json_encode(0);
        }
    }
	
	function session_destroys(){
		session_destroy();
	}
	
	public function user_logout(){
	
		 header("Cache-Control: private, must-revalidate, max-age=0");
		 header("Pragma: no-cache");
   
	
			$this->session->sess_destroy();
        @session_destroy();
		$this->db->close();
       redirect('Login', 'refresh');
	}
  
    
}
