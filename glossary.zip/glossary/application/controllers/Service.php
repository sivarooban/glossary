<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Service extends CI_Controller{
    function __construct()
    {
        parent::__construct();
			error_reporting(0);
        
			if ($this->session->userdata['get_loginuserdetails']['role'] != 1){
		redirect('Login/user_logout', 'refresh');
		}
		
		if (!$this->user_logged()) {
          redirect('Login/user_logout', 'refresh');
       }
        $this->load->model('Service_model');
    } 

		public function user_logged() {
     // if (isset($this->session->userdata('user_role')) && $this->session->userdata('user_role') != "")
      if ($this->session->userdata['get_loginuserdetails']['role'] != ""){
            return true;
        } else {
            return false;
        }
    }
    /*
     * Listing of service
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('service/index?');
        $config['total_rows'] = $this->Service_model->get_all_service_count();
        $this->pagination->initialize($config);

        $data['service'] = $this->Service_model->get_all_service($params);
        
        $data['_view'] = 'service/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new service
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('service_title','Service Title','required');
		$this->form_validation->set_rules('service_description','Service Description','required');
		//$this->form_validation->set_rules('service_image','Service Image','required');
		$this->form_validation->set_rules('service_order_by','Service Order By','required');
		$this->form_validation->set_rules('service_status','Service Status','required');
		
		if($this->form_validation->run())     
        {   
		
		
			$source_path  = './uploads/service/'; 
		$target_path  = './uploads/service/thumbnail/'; 
	  
         $config['upload_path']   = './uploads/service/'; 
		 $config['allowed_types'] = 'gif|jpg|png'; 
		  $config['max_width']     = 720; 
         $config['max_height']    = 440;
        // $config['max_size']      = 100; 
        // $config['max_width']     = 1024; 
        // $config['max_height']    = 768;  
		
		
           $this->load->library('upload', $config);
		  if ( ! $this->upload->do_upload('service_image')) {
          $error = array('error' => $this->upload->display_errors()); 
          
         }
			
         else { 
            $data = array('upload_data' => $this->upload->data());
			  
		  $this->resizeImage($data['upload_data']['file_name']);
		  		
              } 
			$name=$this->upload->data('file_name');   
		$name1="service/".$name;
		
		
		
		
            $params = array(
				'service_status' => $this->input->post('service_status'),
				'service_title' => $this->input->post('service_title'),
				'service_description' => $this->input->post('service_description'),
				'service_image' => $name1,
				'service_order_by' => $this->input->post('service_order_by'),
            );
            
            $service_id = $this->Service_model->add_service($params);
            redirect('service/index');
        }
        else
        {            
            $data['_view'] = 'service/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a service
     */
    function edit($service_id)
    {   
        // check if the service exists before trying to edit it
        $data['service'] = $this->Service_model->get_service($service_id);
        
        if(isset($data['service']['service_id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('service_title','Service Title','required');
			$this->form_validation->set_rules('service_description','Service Description','required');
			//$this->form_validation->set_rules('service_image','Service Image','required');
			$this->form_validation->set_rules('service_order_by','Service Order By','required');
			$this->form_validation->set_rules('service_status','Service Status','required');
		
			if($this->form_validation->run())     
            {   
			
			
				if($_FILES['service_image']['name']!=''){
	//print_r($_FILES['gallery_image']['name']);die;
		$source_path  = './uploads/service/'; 
		$target_path  = './uploads/service/thumbnail/'; 
	  
         $config['upload_path']   = './uploads/service/'; 
		 $config['allowed_types'] = 'gif|jpg|png'; 
        // $config['max_size']      = 100; 
       //  $config['max_width']     = 720; 
       //  $config['max_height']    = 440;  
		
		
           $this->load->library('upload', $config);
		  if ( ! $this->upload->do_upload('service_image')) {
          $error = array('error' => $this->upload->display_errors()); 
          
         }
			
         else { 
            $data = array('upload_data' => $this->upload->data()); 		
			 $this->resizeImage($data['upload_data']['file_name']);
			
           } 
			$name=$this->upload->data('file_name');   			
			$name1="service/".$name;
			$params['service_image'] =  $name1;
			}
			
			
			
			
			
                $params['service_status']= $this->input->post('service_status');
					$params['service_title']= $this->input->post('service_title');
					$params['service_description']= $this->input->post('service_description');
					//'service_image' => $this->input->post('service_image'),
					$params['service_order_by']= $this->input->post('service_order_by');
            
                $this->Service_model->update_service($service_id,$params);            
                redirect('service/index');
            }
            else
            {
                $data['_view'] = 'service/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The service you are trying to edit does not exist.');
    } 

    /*
     * Deleting service
     */
    function remove($service_id)
    {
        $service = $this->Service_model->get_service($service_id);

        // check if the service exists before trying to delete it
        if(isset($service['service_id']))
        {
            $this->Service_model->delete_service($service_id);
            redirect('service/index');
        }
        else
            show_error('The service you are trying to delete does not exist.');
    }
    
	
	   public function resizeImage($filename)
   {

     
	  
       	$source_path  = './uploads/service/'.$filename; 
		$target_path  = './uploads/service/thumbnail/'.$filename; 

	  $config_manip['image_library'] = 'gd2';
      $config_manip = array(
          'image_library' => 'gd2',
          'source_image' => $source_path,
          'new_image' => $target_path,
          'maintain_ratio' => TRUE,
          'create_thumb' => TRUE,
          'thumb_marker' => '_thumb',
          'width' => 200,
          'height' => 200
      );

//print_r($config_manip);

      $this->load->library('image_lib', $config_manip);
      if (!$this->image_lib->resize()) {
         echo  $this->image_lib->display_errors();
      exit;
      }
	  
	  $this->image_lib->clear();
   }
	
	
}
