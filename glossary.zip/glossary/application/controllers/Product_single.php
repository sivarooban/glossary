<?php
class Product_single extends CI_Controller{
    function __construct(){
        parent::__construct();
		error_reporting(0);
		$this->load->model('Ca_login_model');
        $this->load->model('Product_model');
		$this->load->library('session');
    } 

    /*
     * Listing of ca_customer
     */
    function index(){		
		
		$id = $_GET['id'];
		$cat_id = $this->Product_model->find_cat_product($id);
		
		$data_category1 = $this->Ca_login_model->get_all_category();		
		$data_category = $this->Product_model->get_product($id);
		$data4 = [];
		foreach($data_category1 as $value){
			$data5 = $this->Ca_login_model->product_category($value['category_id']);
			$product_data = [];
			
			foreach($data5 as $value1){
				$product_data[] = array('product_name' => $value1['product_name']);
			}
			$data4[] = array('category_name' => $value['category_name'],'product_datas'=>$product_data);
		}		
		$data['all_sub_category'] = $this->Ca_login_model->get_all_category();
		$data['product'] = $this->Ca_login_model->get_all_product();
		$data['menu'] = $data4;
		$data['products'] = $data_category1;		
		$data['product_single'] = $data_category;
		$data['product'] = $cat_id;
		$data['_view'] = 'registration/product_single';
        $this->load->view('layouts/main',$data);
    }
	
	function check_data(){        
        $json = file_get_contents('php://input');		
		$data = json_decode($json);		
        $uid  = $data->user_loginid;
		$pass = $data->user_pwd;
		$userdetails = $this->Ca_login_model->login_details($uid,$pass);
		if(!empty($userdetails)){		 
			$this->session->set_userdata('userId', $userdetails);			
			echo json_encode(1);
        }else{
			echo json_encode(0);
        }
    }
	
	function insert_orders(){
		$json = file_get_contents('php://input');
		$data_order_check = $this->Product_model->check_order_status($this->session->userId['id']);
		$data = json_decode($json);
		$product_id  = $data->id;
		$customer_id = $data->user_id;
		$total_price  = $data->price;
		$quantity = $data->quantity;
		
		if($data_order_check == 0){
			$params_primary = array(		
					'user_id' => $customer_id,
					'cart_status'=>1,
					'order_total'=>$total_price
				);
			$pid = $this->Product_model->add_order_primary($params_primary);
			$params = array(
					'product_id' => $product_id,
					'single_price' => $total_price,
					'quantity' => $quantity,
					'primary_ids'=>$pid,
					'single_total'=>$total_price
			);
			$userdetails = $this->Product_model->add_order($params);
		}else{
			$data_order_check = $this->Product_model->find_order_id($this->session->userId['id']);			
			$order_p_id = $data_order_check[0]->order_p;
			$get_product_count = $this->Product_model->find_product_id($product_id,$order_p_id);
			if($get_product_count == 0){
				$params = array(
					'product_id' => $product_id,
					'single_price' => $total_price,
					'quantity' => $quantity,
					'primary_ids'=>$order_p_id,
					'single_total'=>$total_price
				);
				$userdetails = $this->Product_model->add_order($params);
			}else{				
				$product_single  = $this->Product_model->product_single_retrieve($product_id,$order_p_id);
				$single_quantity = $product_single['quantity'];
				$price           = $product_single['single_price'];
				$order_id     = $product_single['order_id'];
				$single_quantity += $quantity;
				
				$single_inital_price = $single_quantity*$price;
				$single_product_array = array('single_price'=>$price,'single_total'=>$single_inital_price,'quantity'=>$single_quantity);
				$product_update  = $this->Product_model->update_product_order($order_id,$single_product_array);
			}
			$this->order_total_update($order_p_id);
		}
	}
	
	function insert_orders_plus(){
		$json = file_get_contents('php://input');
		$data_order_check = $this->Product_model->check_order_status($this->session->userId['id']);
		$data = json_decode($json);
		$product_id  = $data->id;
		$customer_id = $data->user_id;
		$total_price  = $data->price;
		$quantity = $data->quantity;
		
		if($data_order_check == 0){
			$params_primary = array(		
					'user_id' => $customer_id,
					'cart_status'=>1,
					'order_total'=>$total_price
				);
			$pid = $this->Product_model->add_order_primary($params_primary);
			$params = array(
					'product_id' => $product_id,
					'single_price' => $total_price,
					'quantity' => $quantity,
					'primary_ids'=>$pid,
					'single_total'=>$total_price
			);
			$userdetails = $this->Product_model->add_order($params);
		}else{
			$data_order_check = $this->Product_model->find_order_id($this->session->userId['id']);			
			$order_p_id = $data_order_check[0]->order_p;
			$get_product_count = $this->Product_model->find_product_id($product_id,$order_p_id);
			if($get_product_count == 0){
				$params = array(
					'product_id' => $product_id,
					'single_price' => $total_price,
					'quantity' => $quantity,
					'primary_ids'=>$order_p_id,
					'single_total'=>$total_price
				);
				$userdetails = $this->Product_model->add_order($params);
			}else{				
				$product_single  = $this->Product_model->product_single_retrieve($product_id,$order_p_id);
				$single_quantity = $product_single['quantity'];
				$price           = $product_single['single_price'];
				$order_id     = $product_single['order_id'];
				$single_quantity  = $quantity+1;
				
				$single_inital_price = $single_quantity*$price;
				$single_product_array = array('single_price'=>$price,'single_total'=>$single_inital_price,'quantity'=>$single_quantity);
				$product_update  = $this->Product_model->update_product_order($order_id,$single_product_array);
			}
			$this->order_total_update($order_p_id);
		}
	}
	function insert_order_minus(){
		$json = file_get_contents('php://input');
		$data_order_check = $this->Product_model->check_order_status($this->session->userId['id']);
		$data = json_decode($json);
		$product_id  = $data->id;
		$customer_id = $data->user_id;
		$total_price  = $data->price;
		$quantity = $data->quantity;
		
		if($data_order_check == 0){
			$params_primary = array(		
					'user_id' => $customer_id,
					'cart_status'=>1,
					'order_total'=>$total_price
				);
			$pid = $this->Product_model->add_order_primary($params_primary);
			$params = array(
					'product_id' => $product_id,
					'single_price' => $total_price,
					'quantity' => $quantity,
					'primary_ids'=>$pid,
					'single_total'=>$total_price
			);
			$userdetails = $this->Product_model->add_order($params);
		}else{
			$data_order_check = $this->Product_model->find_order_id($this->session->userId['id']);			
			$order_p_id = $data_order_check[0]->order_p;
			$get_product_count = $this->Product_model->find_product_id($product_id,$order_p_id);
			if($get_product_count == 0){
				$params = array(
					'product_id' => $product_id,
					'single_price' => $total_price,
					'quantity' => $quantity,
					'primary_ids'=>$order_p_id,
					'single_total'=>$total_price
				);
				$userdetails = $this->Product_model->add_order($params);
			}else{				
				$product_single  = $this->Product_model->product_single_retrieve($product_id,$order_p_id);
				$single_quantity = $product_single['quantity'];
				$price           = $product_single['single_price'];
				$order_id     = $product_single['order_id'];
				$single_quantity = $quantity;
				
				$single_inital_price = $single_quantity*$price;
				$single_product_array = array('single_price'=>$price,'single_total'=>$single_inital_price,'quantity'=>$single_quantity);
				$product_update  = $this->Product_model->update_product_order($order_id,$single_product_array);
			}
			$this->order_total_update($order_p_id);
		}
	}
	
	function order_total_update($order_p_id){
		$res = $this->Product_model->update_total_order($order_p_id);		
	}

	function order_get(){
		if(!empty($this->session->userId)){			
			$data_category = $this->Product_model->check_order($this->session->userId['id']);
			echo json_encode($data_category);
		}else{			
			echo "Not Logged";
		}		
	}	

	function total_products(){
		$data_category = $this->Product_model->total_products();
		echo json_encode($data_category);
	}
	
	function order_cart_total(){		
		$array_data = [];
		if(!empty($this->session->userId)){			
			$data_category = $this->Product_model->get_order_total($this->session->userId['id']);
			$array_data =  $data_category;
			echo json_encode($array_data);
		}else{			
			echo json_encode($array_data);
		}
	}
}
