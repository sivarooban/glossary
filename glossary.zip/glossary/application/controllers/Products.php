<?php
class Products extends CI_Controller{
    function __construct(){
        parent::__construct();
		error_reporting(0);
		$this->load->model('Ca_login_model');
        $this->load->model('Product_model');
		$this->load->library('session');
    } 

    function index(){		
		$products = $this->Product_model->total_products();
		$data['products']= $products;
		$data['_view'] = 'products/products';
        $this->load->view('layouts/main',$data);
    }
	
}
