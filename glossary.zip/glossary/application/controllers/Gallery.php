<?php
/* 
 * Product Enquiry V1.0
 * www.bigeyeglobal.com
 */
 
class Gallery extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Gallery_model');
    } 

    /*
     * Listing of gallery
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('gallery/index?');
        $config['total_rows'] = $this->Gallery_model->get_all_gallery_count();
        $this->pagination->initialize($config);

        $data['gallery'] = $this->Gallery_model->get_all_gallery($params);
        
        $data['_view'] = 'gallery/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new gallery
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('gallery_title','Gallery Title','required');
		$this->form_validation->set_rules('gallery_order_by','Gallery Order By','required');
		$this->form_validation->set_rules('gallery_status','Gallery Status','required');
		//$this->form_validation->set_rules('gallery_image','Gallery Image','required');
		
		if($this->form_validation->run())     
        {   
            
            
        
		$source_path  = './uploads/gallery/'; 
		$target_path  = './uploads/gallery/thumbnail/'; 
	  
         $config['upload_path']   = './uploads/gallery/'; 
		 $config['allowed_types'] = 'gif|jpg|png'; 
		  $config['max_width']     = 720; 
         $config['max_height']    = 440;
        // $config['max_size']      = 100; 
        // $config['max_width']     = 1024; 
        // $config['max_height']    = 768;  
		
		
           $this->load->library('upload', $config);
		  if ( ! $this->upload->do_upload('gallery_image')) {
          $error = array('error' => $this->upload->display_errors()); 
          
         }
			
         else { 
            $data = array('upload_data' => $this->upload->data());
			  
		  $this->resizeImage($data['upload_data']['file_name']);
		  		
              } 
			$name=$this->upload->data('file_name');   
		$name1="gallery/".$name;
	     $params = array(
				'gallery_title' => $this->input->post('gallery_title'),
				'gallery_image' =>  $name1,
				'gallery_order_by' => $this->input->post('gallery_order_by'),
				'gallery_status' => $this->input->post('gallery_status'),
					'created' => date('Y-m-d')
            );
            $gallery_id = $this->Gallery_model->add_gallery($params);
            redirect('gallery/index');
        }
        else
        {            
            $data['_view'] = 'gallery/add';
            $this->load->view('layouts/main',$data);
        }
    }  

	
	 /**
    * Manage uploadImage
    *
    * @return Response
   */
   
   
   //Create Thumbnail function

   
   
   public function resizeImage($filename)
   {

     
	  
       	$source_path  = './uploads/gallery/'.$filename; 
		$target_path  = './uploads/gallery/thumbnail/'.$filename; 

	  $config_manip['image_library'] = 'gd2';
      $config_manip = array(
          'image_library' => 'gd2',
          'source_image' => $source_path,
          'new_image' => $target_path,
          'maintain_ratio' => TRUE,
          'create_thumb' => TRUE,
          'thumb_marker' => '_thumb',
          'width' => 360,
          'height' => 220
      );

//print_r($config_manip);

      $this->load->library('image_lib', $config_manip);
      if (!$this->image_lib->resize()) {
         echo  $this->image_lib->display_errors();
      exit;
      }
	  
	  $this->image_lib->clear();
   }
	
	

	
	
    /*
     * Editing a gallery
     */
    function edit($gallery_id)
    {   
        // check if the gallery exists before trying to edit it
        $data['gallery'] = $this->Gallery_model->get_gallery($gallery_id);
        
        if(isset($data['gallery']['gallery_id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('gallery_title','Gallery Title','required');
			//$this->form_validation->set_rules('gallery_image','Gallery Image','required');
			$this->form_validation->set_rules('gallery_order_by','Gallery Order By','required');
			$this->form_validation->set_rules('gallery_status','Gallery Status','required');
		
			if($this->form_validation->run())     
            {   
	if($_FILES['gallery_image']['name']!=''){
	//print_r($_FILES['gallery_image']['name']);die;
		$source_path  = './uploads/gallery/'; 
		$target_path  = './uploads/gallery/thumbnail/'; 
	  
         $config['upload_path']   = './uploads/gallery/'; 
		 $config['allowed_types'] = 'gif|jpg|png'; 
        // $config['max_size']      = 100; 
         $config['max_width']     = 720; 
         $config['max_height']    = 440;  
		
		
           $this->load->library('upload', $config);
		  if ( ! $this->upload->do_upload('gallery_image')) {
          $error = array('error' => $this->upload->display_errors()); 
          
         }
			
         else { 
            $data = array('upload_data' => $this->upload->data()); 		
			 $this->resizeImage($data['upload_data']['file_name']);
			
           } 
			$name=$this->upload->data('file_name');   			
			$name1="gallery/".$name;
			$params['gallery_image'] =  $name1;
			}
		   
                $params['gallery_status'] = $this->input->post('gallery_status');
					$params['gallery_title'] =  $this->input->post('gallery_title');
					
					$params['gallery_order_by'] =  $this->input->post('gallery_order_by');
                $params['modified'] =  date('Y-m-d');

                $this->Gallery_model->update_gallery($gallery_id,$params);            
                redirect('gallery/index');
            }
            else
            {
                $data['_view'] = 'gallery/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The gallery you are trying to edit does not exist.');
    } 

    /*
     * Deleting gallery
     */
    function remove($gallery_id)
    {
        $gallery = $this->Gallery_model->get_gallery($gallery_id);

        // check if the gallery exists before trying to delete it
        if(isset($gallery['gallery_id']))
        {
            $this->Gallery_model->delete_gallery($gallery_id);
            redirect('gallery/index');
        }
        else
            show_error('The gallery you are trying to delete does not exist.');
    }
    
}
