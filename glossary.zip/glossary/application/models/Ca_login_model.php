<?php

class Ca_login_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get ca_customer by company_id
     */
    function login_details($a,$b){
		
       $query = $this->db->query('SELECT * FROM registration_page WHERE  email_address = "'.$a.'" and passwords = "'.$b.'"  ');
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return FALSE ;
        }

       // echo $this->db->last_query();exit;
    }
	
	
	/*
     * Get product category by company_id
     */
    function product_category($a){
		
       $query = $this->db->query('SELECT * FROM products WHERE  category_id = "'.$a.'"   ');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return FALSE ;
        }

       // echo $this->db->last_query();exit;
    }
  
	function get_all_product()
    {
        $this->db->order_by('product_id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('products')->result_array();
    }
  
        /*
     * Get all category
     */
    function get_all_category($params = array())
    {
        $this->db->order_by('category_id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('category')->result_array();
    }

}
