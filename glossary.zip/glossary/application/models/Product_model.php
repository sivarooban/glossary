<?php
 
class Product_model extends CI_Model{
    function __construct(){
        parent::__construct();
    }
    
    /*
     * Get product by product_id
     */
    function get_product($product_id){
        return $this->db->get_where('products',array('product_id'=>$product_id))->row_array();
    }
    
    /*
     * Get all products count
     */
    function get_all_products_count(){
        $this->db->from('products');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all products
     */
    function get_all_products($params = array())
    {
        $this->db->order_by('product_id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('products')->result_array();
    }
        
    /*
     * function to add new product
     */
    function add_product($params)
    {
        $this->db->insert('products',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update product
     */
    function update_product($product_id,$params)
    {
        $this->db->where('product_id',$product_id);
        return $this->db->update('products',$params);
    }
    
    /*
     * function to delete product
     */
    function delete_product($product_id)
    {
        return $this->db->delete('products',array('product_id'=>$product_id));
    }



     function cat_name($category_id)
    {
      $cat_name=$this->db->get_where('category',array('category_id'=>$category_id))->row_array();
      return $cat_name['category_name'];
    }
     function sub_cat_name($sub_category_id)
    {
      $cat_name=$this->db->get_where('sub_category',array('sub_category_id'=>$sub_category_id))->row_array();
      return $cat_name['subcategory_name'];
    }
	
	function product_single_data($a,$b){		
        $query = $this->db->query('SELECT * FROM registration_page WHERE  email_address = "'.$a.'" and passwords = "'.$b.'"  ');
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return FALSE ;
        }
    }
	
	function add_order($params){
        $this->db->insert('orders',$params);
        return $this->db->last_query();
    }
    
	function single_order_data($customer_id){		
		$this->db->where('orders.customer_id',$customer_id);
		$this->db->where('orders.order_status',1);
		$this->db->from('orders');
		$this->db->join('products', 'orders.product_id = products.product_id','left');
		$query = $this->db->get();
		return $query->result();
    }
	
	function total_products(){				
		$this->db->from('products');		
		$query = $this->db->get();
		return $query->result();
    }
   
	function check_order($user_id){		       
		$this->db->where('user_id',$user_id);
		$this->db->where('cart_status',1);
		$this->db->from('order_primarys');		
		$query = $this->db->get();
		$cat =  $query->result();
		$order_id = $cat[0]->order_p;
		$query = $this->db->query('SELECT * FROM orders as o left join products as p on o.product_id = p.product_id  WHERE  primary_ids = "'.$order_id.'"');       
		return $query->result();
    }	
	
	function check_order_status($user_id){		
        $query = $this->db->query('SELECT * FROM order_primarys WHERE  user_id = "'.$user_id.'" and cart_status = "1"  ');       
		return $query->num_rows();
    }

	function add_order_primary($params){		        
		$this->db->insert('order_primarys',$params);
        return $this->db->insert_id();	
    }
	
	function check_product_insert_status($product_id){		
        $query = $this->db->query('SELECT * FROM orders WHERE  product_id = "'.$product_id.'"');       
		return $query->num_rows();
    }
	
	function find_order_id($user_id){				
		$this->db->where('user_id',$user_id);
		$this->db->from('order_primarys');		
		$query = $this->db->get();
		return $query->result();
    }	
	
	function find_product_id($product_id,$primary_ids){		
        $query = $this->db->query('SELECT * FROM orders WHERE  product_id = "'.$product_id.'" and primary_ids = "'.$primary_ids.'"  ');
		return $query->num_rows();
    }
	
	function product_single_retrieve($product_id,$primary_ids){		
        $query = $this->db->query('SELECT * FROM orders WHERE  product_id = "'.$product_id.'" and primary_ids = "'.$primary_ids.'"  ');
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return FALSE ;
        }
    }
	function product_single_update($product_id,$quantity,$primary_order_id){		
        $query = $this->db->query('SELECT * FROM orders WHERE  product_id = "'.$product_id.'" and primary_ids = "'.$primary_ids.'"  ');
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return FALSE ;
        }
    }
	
	function update_product_order($order_id,$single_product_array){		
		$this->db->where('order_id',$order_id);
        return $this->db->update('orders',$single_product_array);
		
    }

	function update_total_order($primary_ids){
		$this->db->where('primary_ids',$primary_ids);
		$this->db->select_sum('single_total');
		$this->db->from('orders');				
		$query = $this->db->get();
		$m = $query->result();
		$single_total = $m[0]->single_total;

		$params = array(					
					'order_total' => $single_total,					
				);
		$this->db->where('order_p',$primary_ids);
        return $this->db->update('order_primarys',$params);
	}

	function find_cat_product($product_id){	
		$this->db->where('product_id',$product_id);
		$this->db->from('products');		
		$query = $this->db->get();
		$cat =  $query->result();
		$category_id = $cat[0]->category_id;

		$this->db->where('category_id',$category_id);
		$this->db->from('products');		
		$query1 = $this->db->get();
		return $query1->result();
    }
	
	function get_order_total($user_id){		       
		$this->db->where('user_id',$user_id);
		$this->db->where('cart_status',1);
		$this->db->from('order_primarys');		
		$query = $this->db->get();
		$cat =  $query->result();
		$order_id = $cat[0]->order_p;
		
		$this->db->where('primary_ids',$order_id);
		$this->db->select_sum('single_total');
		$this->db->from('orders');				
		$query = $this->db->get();
		$m = $query->result();
		$data = array('total'=>$m[0]->single_total,'order_id'=>$order_id);
		return $data;
    }
	
    function delete_order($order_id){
		$this->db->where('order_id',$order_id);		
		$this->db->from('orders');		
		$query = $this->db->get();
		$cat =  $query->result();
		$primary_ids = $cat[0]->primary_ids;
		
		
        $this->db->delete('orders',array('order_id'=>$order_id));		
		
		
		$query = $this->db->query('SELECT * FROM orders WHERE    primary_ids = "'.$primary_ids.'"  ');
		$query->num_rows();
        if($query->num_rows() == 0){
            $this->db->delete('order_primarys',array('order_p'=>$primary_ids));
			$this->db->delete('order_address',array('order_p_id'=>$primary_ids));
        } 
    }
	
	
}