<?php
/* 
 * Product Enquiry V1.0
 * www.bigeyeglobal.com
 */
 
class Register_model extends CI_Model{
    function __construct(){
        parent::__construct();
    }    
        
    /*
     * function to add new service
     */
    function add_register($params){
        $this->db->insert('registration_page',$params);
        return $this->db->insert_id();
    }
	
	function getall_pincode(){
		return $this->db->get('pincode')->result_array();
	}
}
