<?php
/* 
 * Product Enquiry V1.0
 * www.bigeyeglobal.com
 */
 
class Sub_category_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get sub_category by sub_category_id
     */
    function get_sub_category($sub_category_id)
    {
        return $this->db->get_where('sub_category',array('sub_category_id'=>$sub_category_id))->row_array();
    }
    
    /*
     * Get all sub_category count
     */
    function get_all_sub_category_count()
    {
        $this->db->from('sub_category');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all sub_category
     */
    function get_all_sub_category($params = array())
    {
        $this->db->order_by('sub_category_id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('sub_category')->result_array();
    }
        
    /*
     * function to add new sub_category
     */
    function add_sub_category($params)
    {
        $this->db->insert('sub_category',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update sub_category
     */
    function update_sub_category($sub_category_id,$params)
    {
        $this->db->where('sub_category_id',$sub_category_id);
        return $this->db->update('sub_category',$params);
    }
    
    /*
     * function to delete sub_category
     */
    function delete_sub_category($sub_category_id)
    {
        return $this->db->delete('sub_category',array('sub_category_id'=>$sub_category_id));
    }

     function cat_name($category_id)
    {
      $cat_name=$this->db->get_where('category',array('category_id'=>$category_id))->row_array();
      return $cat_name['category_name'];
    }
  

}
