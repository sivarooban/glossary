<?php
/* 
 * Product Enquiry V1.0
 * www.bigeyeglobal.com
 */
 
class Category_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get category by category_id
     */
    function get_category($category_id)
    {
        return $this->db->get_where('category',array('category_id'=>$category_id))->row_array();
    }
    
    /*
     * Get all category count
     */
    function get_all_category_count()
    {
        $this->db->from('category');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all category
     */
    function get_all_category($params = array())
    {
        $this->db->order_by('category_id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('category')->result_array();
    }
        
    /*
     * function to add new category
     */
    function add_category($params)
    {
        $this->db->insert('category',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update category
     */
    function update_category($category_id,$params)
    {
        $this->db->where('category_id',$category_id);
        return $this->db->update('category',$params);
    }
    
    /*
     * function to delete category
     */
    function delete_category($category_id)
    {
        return $this->db->delete('category',array('category_id'=>$category_id));
    }
}
