<?php
/* 
 * Product Enquiry V1.0
 * www.bigeyeglobal.com
 */
 
class Testimonal_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get testimonal by testimonals_id
     */
    function get_testimonal($testimonals_id)
    {
        return $this->db->get_where('testimonals',array('testimonals_id'=>$testimonals_id))->row_array();
    }
    
    /*
     * Get all testimonals count
     */
    function get_all_testimonals_count()
    {
        $this->db->from('testimonals');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all testimonals
     */
    function get_all_testimonals($params = array())
    {
        $this->db->order_by('testimonals_id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('testimonals')->result_array();
    }
        
    /*
     * function to add new testimonal
     */
    function add_testimonal($params)
    {
        $this->db->insert('testimonals',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update testimonal
     */
    function update_testimonal($testimonals_id,$params)
    {
        $this->db->where('testimonals_id',$testimonals_id);
        return $this->db->update('testimonals',$params);
    }
    
    /*
     * function to delete testimonal
     */
    function delete_testimonal($testimonals_id)
    {
        return $this->db->delete('testimonals',array('testimonals_id'=>$testimonals_id));
    }
}
