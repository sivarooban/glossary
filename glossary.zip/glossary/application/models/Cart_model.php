<?php
/* 
 * Product Enquiry V1.0
 * www.bigeyeglobal.com
 */
 
class Cart_model extends CI_Model{
    function __construct(){
        parent::__construct();
    }    
        
	function get_user_count($order_p_id){
		$query = $this->db->query('SELECT * FROM order_address WHERE order_p_id = "'.$order_p_id.'"  ');
		return $query->num_rows();        
	}
	
	function daysUntil($start, $end) {
		$lookup = [
			'Sunday' => 0,
			'Monday' => 1,
			'Tuesday' => 2,
			'Wednesday' => 3,
			'Thursday' => 4,
			'Friday' => 5,
			'Saturday' => 6
		];
		$days = $lookup[$end] - $lookup[$start] + ($lookup[$end] <= $lookup[$start] ? 7 : 0);
        return $days;
	}


	function find_user_details($id){			
		$this->db->where('id',$id);
		$this->db->from('registration_page');		
		$query = $this->db->get();
		return $query->result();
	}
	
	function date_cal(){
		
		$query = $this->db->query('SELECT CURDATE() as dates;');
		$datas = $query->result();
		
		
		$date5 = $datas[0]->dates;
		
		$query = $this->db->query('SELECT DAYNAME("'.$date5.'") as days;');
		$data44 = $query->result();
		$date5 = strtoupper($data44[0]->days);
		
		
		$this->db->where('id',$id);
		$this->db->from('registration_page');		
		$query = $this->db->get();
		$data_pincode = $query->result();
		
		$pincode_id =  $data_pincode[0]->postal_code;
		
	
		
		
		$this->db->where('pincode_id',$pincode_id);
		$this->db->from('pincode');		
		$query = $this->db->get();
		$data_pincode = $query->result();
		
		$day4 =  $data_pincode[0]->days;
		return $this->daysUntil($date5, $day4);
		
	}
	function add_order_address($params,$param1,$id){
        $this->db->insert('order_address',$params);
        
		
		//$this->db->insert('order_primarys',$param1);
		$this->db->where('order_p',$id);
        $this->db->update('order_primarys',$param1);
        
    }
	
	function get_user_data($order_p_id){	
		$this->db->where('order_p_id',$order_p_id);
		$this->db->from('order_address');		
		$query = $this->db->get();
		return $query->result();
	}
	function update_cart($order_p_id,$params,$params1){
        $this->db->where('order_p_id',$order_p_id);
        $this->db->update('order_address',$params);
		$this->db->where('order_p',$order_p_id);
        $this->db->update('order_primarys',$params1);
		return $this->db->last_query();
    }    
	
	function get_deliver_date($user_id){	
		$this->db->where('user_id',$user_id);
		$this->db->from('order_primarys');		
		$query = $this->db->get();
		return $query->result();
	}
}
