<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Contact Edit</h3>
            </div>
			<?php echo form_open('contact/edit/'.$contact['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="name" class="control-label"><span class="text-danger">*</span>Name</label>
						<div class="form-group">
							<input type="text" name="name" value="<?php echo ($this->input->post('name') ? $this->input->post('name') : $contact['name']); ?>" class="form-control" id="name" />
							<span class="text-danger"><?php echo form_error('name');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="email" class="control-label">Email</label>
						<div class="form-group">
							<input type="text" name="email" value="<?php echo ($this->input->post('email') ? $this->input->post('email') : $contact['email']); ?>" class="form-control" id="email" />
							<span class="text-danger"><?php echo form_error('email');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="mobilenumber" class="control-label">Mobilenumber</label>
						<div class="form-group">
							<input type="text" name="mobilenumber" value="<?php echo ($this->input->post('mobilenumber') ? $this->input->post('mobilenumber') : $contact['mobilenumber']); ?>" class="form-control" id="mobilenumber" />
							<span class="text-danger"><?php echo form_error('mobilenumber');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="entry-date&time" class="control-label">Entry-date&time</label>
						<div class="form-group">
							<input type="text" name="entry-date&time" value="<?php echo ($this->input->post('entry-date&time') ? $this->input->post('entry-date&time') : $contact['entry-date&time']); ?>" class="form-control" id="entry-date&time" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="enquiry" class="control-label"><span class="text-danger">*</span>Enquiry</label>
						<div class="form-group">
							<input type="text" name="enquiry" value="<?php echo ($this->input->post('enquiry') ? $this->input->post('enquiry') : $contact['enquiry']); ?>" class="form-control" id="enquiry" />
							<span class="text-danger"><?php echo form_error('enquiry');?></span>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>