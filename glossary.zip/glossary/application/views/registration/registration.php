
<div class="banner-wrap">
	<div style="clear:both"></div>
	<div class="container" style="padding-top:134px;">
		<div class="">
			<h1>Registration</h1>
		</div>
		<form method='post' id="reset_forms" class="myForm" action="">
			<div class="row">
				<div class="col-md-6">
					<label>Email Address</label>
					<input class="form-control" ng-model="email_address" ng-blur="email_change()" id="email_address" type="email" required name="email_address" >											
				</div>	
				<div class="col-md-6">
					<label>Confirm Email Address</label>
					<input class="form-control" ng-model="c_email_address" ng-blur="c_email_change()" name="c_email_address" id="c_email_address" type="email">
				</div>	
			</div>
			<div class="row">
				<div class="col-md-6">
					<label>Password</label>
					<input class="form-control" ng-model="passwords" id="passwords" ng-blur="passwords_change()" name="passwords" ng-model="passwords" type="password">
				</div>	
				<div class="col-md-6">
					<label>Confirm Password</label>
					<input class="form-control" ng-model="c_password" id="c_password" ng-blur="c_password_change()" name="c_password" ng-model="c_password"  type="password">
				</div>	
			</div>
			<div class="row">
				<div class="col-md-6">
					<label>Date Of Birth</label>
					<input class="form-control" placeholder="dd/mm/yy" name="dob" ng-blur="dob_change()" id="dob" ng-model="dob" type="text">
				</div>	
				<div class="col-md-6">
					<label>Phone</label>
					<input class="form-control" ng-blur="phone_change()"  name="phone" id="phone" ng-model="phone" id="phone" type="text">
				</div>	
			</div>
			<div class="row">
				<div class="col-md-6">
					<label>First Name</label>
					<input class="form-control" name="first_name" ng-blur="first_name_change()" id="first_name" ng-model="first_name" type="text">
				</div>	
				<div class="col-md-6">
					<label>Last Name</label>
					<input class="form-control" name="last_name" id="last_name" ng-blur="last_name_change()" ng-model="last_name" type="text">
				</div>	
			</div>
			<div class="row">
				<b>Billing Address</b>
			</div>
			<div class="row">
				<div class="col-md-6">
					<label>House No</label>
					<input class="form-control" name="house_no" id="house_no" ng-model="house_no" ng-blur="house_no_change()" type="text">
				</div>	
				<div class="col-md-6">
					<label>Street</label>
					<input class="form-control" name="street" id="street" ng-blur="street_change()" ng-model="street" type="text">
				</div>						
			</div>
			<div class="row">
				<div class="col-md-6">
					<label>Postal code</label>
					<select ng-change="postal_code_change()" class="form-control" id="postal_code" name="pincode" ng-model="postal_code">
						<option value="">select</option>
						<?php foreach($pincode_data as $value){?>
							<option value="<?php echo $value['pincode_id'] ?>"><?php echo $value['pincode'] ?></option>
						<?php } ?>
					</select>					
				</div>	
				<div class="col-md-6">
					<label>City</label>
					<input class="form-control" id="city" name="city" ng-blur="city_change()" ng-model="city" type="text">
				</div>						
			</div>
			<br>
			<div class="row">
				<div class="col-md-1">
					<button type="button" ng-click="click_register()" class="btn btn-primary">submit</button>
				</div>	
				<div class="col-md-1">					
					<button type="reset" class="btn btn-primary">reset</button>
				</div>						
			</div>
			<br>
		</form>	
	</div>


	
</div>
	
