	<div style="clear:both"></div>
	<div class="banner-wrap">
		<div style="clear:both"></div>
		<div class="container" style="padding-top:134px;">
			<br><br><br>
			<div class="row">
				<div class="col-md-4 col-lg-4">
					
					<img style="width:100%" src="<?php echo base_url().'admin/uploads/'.$product_single['product_img']?>">
				</div>
				<div class="col-md-4 col-lg-4">
					<b>Name:</b><?php echo  $product_single['product_name']?>
					<br>
					<b>Price:</b><font id="price_data"><?php echo $product_single['price']?></font>
					<?php echo $product_single['text_area']?>
				</div>
				<div class="col-md-4 col-lg-4">
					<div class="col-xs-push-2 col-xs-8 col-lg-8 col-lg-push-2">	
 							<div class="row">
					<div class="col-xs-12 col-md-12">
						<div class="form-group">					
							<div class="quantity-wrapper" style="width:190px">
								<div class="wrapper"  style="height:50px">																	
									<span class="qty-up btooltip">
										<i class="fa fa-minus" ng-click="cart_minus()"></i>
									</span>
									<input class="item-quantity" type="text" name="ArticleQuantity" value="1" size="3" maxlength="3" readonly>
									<span class="qty-down btooltip" ng-click="cart_plus()">
										<i class="fa fa-plus"></i>
									</span>	
								</div>
							</div>						 
                        </div><br>						
					</div>
						<div style="clear:both"></div>
                            <br>
							<?php if(($this->session->userdata('userId'))){?>
							<div class="col-xs-12 col-md-12">
								<div class=" shipping-tray toBasketWrapper" data-plenty="toBasketWrapper">
									<a class="btn btn-success btn-lg" id="click_cart">
										<span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart
									</a>
						
								</div>                         	
                         	</div>
							<?php } ?>
                         </div>              			
					</div>
				</div>
			</div>
			
			<div style="clear:both"></div>
			<br><br>
			<div class="row" style="text-align:center;" >
				<h1>Similar Products</h1>      
			</div>
			<br><br>
			<div class="">
				<ul class="row categoryDetails isGridView ">
					<div class="col-12">	
						<div class="">
							<?php				
								$g = 0;
								forEach($product as $value){						
									
									$g = $g+1;
									if($g == 5){
										
										$g=1;
							?>
									<div style="clear:both"></div>
									<br><br>
								<?php
									}
								?>		
							<!-- item box -->
							<div class="col-md-3">							
								<div class="itemBoxInner">
									
									<div id="previewImages-990294" class="p_slider-img-wrap h-md-3 h-sm-2 h-xs-6">						
										<div class="imageBox p_slider-img-wrap h-md-3 h-sm-2 h-xs-6 adapt-line-height">
											<a href="en/all-categories/beverages/soft-drinks/rubicon-mango-juice-drink-deluxe-1liter/a-990294/index.html">		
												<img style="width:200px;height:200px" class="center img-responsive id-990294 js-link" src="<?php echo base_url()."admin/uploads/".$value->product_img?>" >
											</a>									
										</div>										
									</div>							
									<!-- item info -->	
									<a href="#">	
										<h4 class="name block" href="#" style="text-align:center">
											<?php echo $value->product_name?>
										</h4>
									</a>							
									<a href="#">
										<p class="p_sub-text" style="text-align:center">
											Size:  1 kg
										</p>
									</a>						
									<p class="price bold js-link margin-bottom-0" style="text-align:center">
										<br />
										<?php echo $value->price?>
									</p>
									<div class="visible-hover" >						
										<div class="basketButtonContainer clearfix" style="text-align: center;">												
											<div style="color: #d87e3e;font-weight: 700;border-radius: 0;border: 2px solid #d87e3e;" class="buttonBox shipping-tray isViewItem">
												<a class="btn" href="<?php echo base_url()."product_single?id=".$value->product_id?>">								
													View Product
												</a>															
											</div>												
										</div>
									</div>								
								</div>					
							</div>
							<!-- ./item box -->
						
							<?php } ?>				
						</div>				
					</div>
				</ul>
			</div>
					

		</div>		
	</div>