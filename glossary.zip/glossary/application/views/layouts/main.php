<!DOCTYPE html>
<html lang="en">
	<head>   		
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
		<title>Glossary Items</title>
		<link rel="shortcut icon" type="image/x-icon" href="layout/images/favicon.png">
		<script src="<?php  echo base_url();?>resources/js/compressed.js" type="text/javascript"></script>
    	<link rel="canonical" href="en/index.html" />
		<link rel="stylesheet" type="text/css" href="<?php  echo base_url();?>resources/css/jamoona_en_content2335.css?625" />
		<link rel="shortcut icon" type="image/ico" href="tpl/favicon_0.html" />
		<meta name="keywords" content="" /></meta>		
		<meta charset="UTF-8"></meta>
		<meta name="viewport" content="width=device-width, initial-scale=1.0"></meta>
		<!--css-->
		<link href="<?php  echo base_url();?>resources/css/bootstrap.css" rel="stylesheet" type="text/css" />
		<link href="<?php  echo base_url();?>resources/css/style1.css" rel="stylesheet" type="text/css" />
		<link href="<?php  echo base_url();?>resources/css/responsive.css" rel="stylesheet" type="text/css" />    
		<link href="<?php  echo base_url();?>resources/css/style.css" rel="stylesheet" media="screen">        
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900,900i&amp;display=swap" rel="stylesheet">
        <link rel="stylesheet" href="<?php  echo base_url();?>resources/css/font-awesome.min.css">
		<!--<link href="/layout/new/css/font-awesome.css" rel="stylesheet" type="text/css" />-->
		<link href="<?php  echo base_url();?>resources/css/owl.carousel.min.css" rel="stylesheet" type="text/css" />
		<link href="<?php  echo base_url();?>resources/css/owl.theme.default.min.css" rel="stylesheet" type="text/css" />		
		<link href="<?php  echo base_url();?>resources/css/slick.css" rel="stylesheet" type="text/css" />
		<link href="<?php  echo base_url();?>resources/css/slick-theme.css" rel="stylesheet" type="text/css" />		
		<script src="<?php  echo base_url();?>resources/js/bootstrap.js" type="text/javascript"></script>
		<script src="<?php  echo base_url();?>resources/js/easing.js" type="text/javascript"></script>
		<script src="<?php  echo base_url();?>resources/js/move-top.js" type="text/javascript"></script>
		<script src="<?php  echo base_url();?>resources/js/owl.carousel.min.js" type="text/javascript"></script>    
		<script src="<?php  echo base_url();?>resources/js/slick.min.js" type="text/javascript"></script>
		<script src="<?php  echo base_url();?>resources/js/script.js" type="text/javascript"></script>
		<script src="<?php  echo base_url();?>resources/js/plenty/ScriptLoader.js"></script>
		<script src="<?php  echo base_url();?>resources/js/angular.min.js"></script>	
		<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
		  <link rel="stylesheet" href="/resources/demos/style.css">
		  
		  <script>
  $( function() {
    $( "#datepicker" ).datepicker({
    dateFormat: 'dd/mm/yy'
	});
});
  </script>
	</head>
	<body  ng-app="myApp" ng-controller="myCtrl" style="margin:0px">
		<div class="wrapper">	
			<a id="top"></a>
			<header>    	
				<div class="top-header">
					<div class="container-fluid">
						<div class="row">
							<div class="col-md-6">
								<p style="text-transform:uppercase;">FREE shipping at Dollar 29 inside Europe</p>
							</div> 
							<div class="col-md-6 pull-rgt">
								<ul class="top-menu">
									<li>
										<a href="#">
											About Us
										</a>    
									</li>
									<li>
										<a href="#">
											FAQ
										</a>    
									</li>
									<li>
										<a href="#">
											Shipping Details
										</a>    
									</li>    
								</ul>    
							</div>   
						</div>						
						<div class="row">
							<div class="col-lg-8 col-md-8" style="position:relative">
								<div class="menu-lft">
									<a href="<?php echo base_url();?>">
										<div class="logo">
											<img style="width:50px;height:50px;" src="<?php echo base_url();?>resources/img/logo.jpg">
										</div>
									</a> 

									<div class="serach-bar">
										<div class="form-group" id="search_desktop">					 
											<input type="text" ng-model="search_events" ng-keyup="search_event(this)" class="form-control"  placeholder="Search your favorite asian products at wholesale prices..." 
											autocomplete="off"  />
										</div>
									</div>    
								</div>								
								<div class="search_div"   ng-hide="res.length == 0">
									<div ng-click="hide_search()"  class="close_icon close_data"><i class="fa fa-close"></i></div>								
									<div class="search_div1" style="position:relative">										
										<a href="<?php echo base_url()."product_single?id= "; ?>{{x.product_id}}" class="row cursors"  ng-repeat="x in res">										
										<div class="col-md-4" style="text-align:center">
											<img style="width:50px;height:50px" src="<?php echo base_url()."admin/uploads/";?>{{x.product_img}}">
										</div>
										<div class="col-md-4" style="text-align:center">
											<br>
											{{x.product_name}}
										</div>
										<div class="col-md-4" style="text-align:center">
											<br>
											{{x.price}} Rs
										</div>
										</a><br>
									</div>									
								</div>	
							</div>													 
							<ul class="nav navbar-nav navbar-right pull-right">		
						<li class="dropdown isLogin enable-xs-sm">
							<?php if($this->session->userdata('userId')){
												$data = $this->session->userdata('userId');
												echo "teee". $data['firstname'];	
											}else{ ?>
												<a href="javascript:void(0);" class="dropdown-toggle toggle-xs-sm-or-touch" data-plenty="click:MobileDropdown.openDropdown(this, true)">
								<span class="fa fa-user" style="float:left;"></span><span class="hidden-xs" style="float:left;">&nbsp;Login</span>
							</a>
											<?php } ?>
							
							<ul class="dropdown-menu dropdown-menu-right dropdown-padding" role="menu" data-plenty="loginFormContainer">
								<li>
									<?php if(!($this->session->userdata('userId'))){?>
										<div class="form-group login_user">
										</div>
										<form class="form-inline form-block-2-button break-sm loginForm" method="post">
											<div class="form-group">
												<label class="sr-only" for="checkout-login-email">Login Id</label>
												<input ng-blur="user_empty()" class="form-control" id="user_loginid" ng-model='user_loginid' id="checkout-login-email" name="loginMail" type="email" placeholder="E-Mail-Adress">
											</div>
											<div class="form-group">
												<label class="sr-only" for="checkout-login-password">Password</label>
												<input ng-blur="password_empty()" class="form-control" id="user_pwd" ng-model="user_password" id="checkout-login-password" name="loginPassword" type="password" placeholder="Password">
											</div>
											<button class="btn btn-primary" type="button" ng-click="clicked()" style="background-color:green">
												<i style="color:white" class="fa fa-sign-in"></i>
											</button>
										</form>									
									<?php } ?>
									<div>
										<a class="iconLink" href="en/jamoona/forgot-passwort/index.html"><span></span>&nbsp;Forgot password?</a>
									</div>
									<hr class="margin-top-05 margin-bottom-05">
									<div class="clearfix">
										<?php if($this->session->userdata('userId')){?>
										  <a class="iconLink pull-left" ng-click="session_des()" href="#"><span class="glyphicon glyphicon-pencil"></span>&nbsp;Logout</a>
										<?php }else{ ?>
											<a class="iconLink pull-left" href="<?php echo base_url()?>registration"><span></span>&nbsp;Register</a>
										<?php }?>
										<a class="iconLink cancel pull-right"  data-plenty="cancelLogin"><span></span>&nbsp;Close</a>
									</div>
								</li>
							</ul>
						</li>					
					<li class="dropdown isBasketPreview disabled" data-plenty-basket-empty="disabled">
						<a href="en/jamoona/cart/index.html" style="float:left;" class="dropdown-toggle toggle-xs-sm-or-touch" data-plenty="click:MobileDropdown.openDropdown(this, true); click:UI.toggleClass('aside-visible', 'body', 'xs,sm'); click:Tab.showRemoteTab('basketPreview', 'aside', 'xs,sm')">
							<span class="fa fa-cart" style="float:left;"></span><span class="hidden-xs" style="float:left;">&nbsp;Cart</span>&nbsp;<span class="badge" data-plenty-basket-preview="itemQuantityTotal" style="float:left;"><span class="basket_quantity" id="basket_quantity">{{carts.length}}</span></span>
						</a>						
						
						<ul class="dropdown-menu dropdown-padding" style="width:400px;color:green;font-size:10px"  role="menu">
							<li ng-repeat="x in carts">
								<div class="row">
									<div class="col-md-3">
										
										<img style="width:50px;height:50px" src="<?php echo base_url()."admin/uploads/";?>{{x.product_img}}">
									</div>
									<div class="col-md-3">
										{{x.product_name}}
									</div>
									<div class="col-md-3">
										USD {{x.single_price}}
									</div>
									<div class="col-md-3">
										{{x.quantity}}
									</div>
								</div>
							</li>							
							<div style="text-align: right;color: red;font-size: 20px;">Order Total: {{order_total}}</div>
							<a style="margin:10px"  href="<?php echo base_url().'cart?id={{order_id}}'?>""><button class="btn btn-primary">Checkout</button></a>
							<a style="margin:10px" href="<?php echo base_url().'cart?id={{order_id}}'?>"><button class="btn btn-primary">Cart</button></a>
						</ul>
						
					</li>
							</ul>
								</div>        
							 
						 
					</div>   
				</div>				
            <nav id="wednavbar" class="navbar menu-wrap bottom-header">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>				
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav menu-main">
                        <li class="dropdown active">
                            <a href="products" class="dropdown-toggle" data-toggle="dropdown">All Products
                               <!-- <i class="fa fa-caret-down"></i>-->
                            </a>
                            <ul class="dropdown-menu" style="display:none">
								<?php 									
									foreach($menu as $value){  ?>
									<li class="dropdown dropdown-submenu">
										<a href="en/all-categories/rice-pulses-flour/index.html" class="dropdown-toggle" data-toggle="dropdown"><?php print_r($value['category_name']);?>
											<i class="fa fa-caret-right"></i>
										</a>
										<?php if(!empty($value['product_datas']) ) {  ?>
											<ul class="dropdown-menu">
												<?php foreach($value['product_datas'] as $value1){  ?>
													<li>
														<a href="en/all-categories/rice-pulses-flour/atta-flour/index.html"><?php echo $value1['product_name'] ?> </a>
													</li>
												<?php } ?>	
												<img style="padding:10px"  class="dropdown-highlight__img" src="<?php echo base_url()."admin/uploads/".$value['category_image']; ?>">
											</ul>
										<?php } ?>
									</li>                               
								  
								<?php } ?>
                                <li>
                                    <a href="en/all-categories/profession-chef-range/index.html">Professional Chefs</a>
                                </li>
                                <li>
                                    <a href="en/all-categories/index.html">Shop All Products </a>
                                </li>
                            </ul>
                        </li>
                        <li style="display:none">
                            <a href="en/all-categories/bestsellers/index.html">Best Sellers</a>
                        </li>
                        <li style="display:none">
                            <a href="en/all-categories/new-items/index.html">All New</a>
                        </li>
                        <li style="display:none">
                            <a href="en/all-categories/sale/index.html" style="color:red; font-weight:500;">Sale!</a>
						</li>                        
                    </ul>
                </div>
				
			</nav>    
        </header>        
        <div class="mobile-menu">        		
            <div class="mobile-menu-top">
                <div class="row">
                    <div class="mobile-menu-topleft">
                        <div class="col-xs-1">
                            <nav id="menu">
                                <div class="swipe-area"></div>
                               	<label for="tm" data-toggle=".main-menu" id="toggle-menu" >
                               		<img class="img-fluid" src="layout/newsheader/images/menu-icon.png" alt="" onclick="lockScroll();">
                               	</label>
                                <input type="checkbox" id="tm">
                                <ul class="main-menu clearfix">
                                    <li class="login-signup">
                                        <a href="en/jamoona/login/index.html" class="usr-icn"><img src="layout/newsheader/images/black-user.png" /></a>
										<?php if($this->session->userdata('userId')){
											$data = $this->session->userdata('userId');
											echo $data['firstname'];	
										}else{ ?>
											<a href="en/jamoona/login/index.html" class="lgn">
												Login
											</a>
										<?php } ?>
                                        <a href="en/jamoona/registration/index.html">
                                            Signup
                                        </a>    
                                    </li> 
                                    <hr>
                                    <li>
                                        <a href="en/all-categories/index.html">All Products
                                            <span class="drop-icon">▾</span>
                                            <label title="Toggle Drop-down" class="drop-icon" for="sm1">▾</label>
                                        </a>
                                        <input type="checkbox" id="sm1">
                                        <ul class="sub-menu">
                                            <li>
                                                <a href="products/category/98/grocery/index.html">Rice,Pulses & Flour
                                                    <span class="drop-icon"></span>
                                                    <label title="Toggle Drop-down" class="drop-icon" for="sm2">▾</label>
                                                </a>                                                
                                                <ul class="sub-menu">
													<li>
														<a href="en/all-categories/rice-pulses-flour/atta-flour/index.html">Atta &amp; flour </a>
													</li>
													<li>
														<a href="en/all-categories/rice-pulses-flour/rice-noodles/index.html">Rice &amp; Rice products</a>
													</li>
													<li>
														<a href="en/all-categories/rice-pulses-flour/dal-lentils-beans/index.html">Dals, Lentils, &amp; Beans </a>
													</li>
													<li>
														<a href="en/all-categories/rice-pulses-flour/index.html">Shop All Rice, Pulses &amp; Flour </a>
													</li>
                                                </ul>
                                            </li>                                                                            
                                <li>
                                    <a href="en/all-categories/profession-chef-range/index.html">Professional Chefs</a>
                                </li>
                                <li>
                                    <a href="en/all-categories/index.html">Shop All Products </a>
                                </li>                                           
                            </ul>
                                      
                                        
                                    
                                    </li>
                                    <hr>
                                    <li>
                                        <a href="en/all-categories/bestsellers/index.html">
                                            Best Sellers
                                        </a>    
                                    </li>
                                    <li>
                                        <a href="en/all-categories/new-items/index.html">
                                            All New
                                        </a>    
                                    </li>
                                 
                            </li>
                            
                           
                                    <li class="red-menu">
                                        <a href="en/all-categories/sale/index.html">
                                            SALE
                                        </a>    
                                    </li>
                                    <hr>
                                    <li>
                                        <a href="infos/about-us/index.html">
                                            About Us
                                        </a>    
                                    </li>
                                    <li>
                                        <a href="infos/faq/index.html">
                                            FAQ
                                        </a>    
                                    </li>
                                    <li>
                                         <a href="en/infos/shipping-paymentinfos/index.html">
                                        Shipping Details
                                    </a>    
                                    </li>
                                </ul>
                            </nav>
                        </div>
                        <div class="col-xs-7">
                            <a href="en.html">
                                <div class="logo">
                                    <img src="layout/newsheader/images/logo.png" alt="logo">
                                </div>
                            </a>
                        </div>
                        <div class="col-xs-3 pull-right">
                            <div class="cart">
                                <a href="en/jamoona/cart/index.html">
                                    <img src="layout/newsheader/images/cart.png">
                                <span data-plenty-basket-preview="itemQuantityTotal"> <span class="basket_quantity" id="basket_quantity">0</span></span>
                                </a>    
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
             
        </div>
        <!-- JavaScripts -->
		
		<?php                    
            if(isset($_view) && $_view){
				$this->load->view($_view);
			}				
        ?>
		
		<footer>

		<!--Footer-->
		<footer>
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12 col-lg-9">
						<div class="row">
							<div class="col-md-12">
							  <!--  <div class="invite-friend">
									<i class="fa fa-envelope-open"></i>
									<a href="https://www.jamodaa.com/account/invite/">INVITE FRIENDS! GIVE $15 - GET $15</a>
								</div>-->
							</div>
							<div class="col-sm-4 col-md-3">
								<div class="footer-container">
									<h3>Categories</h3>
									<ul>
										<li>
											<a href="en/all-categories/index.html">All Products</a>
										</li>
									 
									   <li>
													   
									   <a href="#">Grains & Lentils </a></li>
													
												   
									   <li>
													   
									   <a href="#">Oils & Spices </a></li>
										<li>
													   
									   <a href="#">Dry Fruit & Snacks </a></li>
										<li>
													   
									   <a href="#">Ready to Eat </a></li>
										<li>
													   
									   <a href="#">Beverages </a></li>
										 <li>
													   
									   <a href="#">Health Care </a></li>
									  
									  
									</ul>
								</div>
							</div>
							<div class="col-sm-4 col-md-3">
								<div class="footer-container">
									<h3>Infos</h3>
									<ul>
										
										<li>
											<a href="#">Shipping & Paymentinfos</a>
										</li>
										<li>
											<a href="#">Versand & Zahlungsinformationen</a>
										</li>
								  
										<li>
											<a href="#">FAQ</a>
										</li>
										  <li>
											<a href="#">About Us</a>
										</li>
										
									 
									</ul>
								</div>
							</div>
							<div class="col-sm-4 col-md-3">
								<div class="footer-container">
									  <h3>RECHTLICHES</h3>
									<ul>
										<li>
											<a href="#">Impressum</a>
										</li>
										<li>
											<a href="#">ABG</a>
										</li>
											<li>
											<a href="#">Haftungsausschluss</a>
										</li>
										<li>
											<a href="#">Datenschutz</a>
										</li>
									<li>
											<a href="#">Widerrufsrecht</a>
										</li>
									  
								 
									</ul>
									
									<h3>LEGAL</h3>
									<ul>
										<li>
											<a href="#">Imprint</a>
										</li> 
										<li>
											<a href="#">Terms & Conditions</a>
										</li>
											<li>
											<a href="#">Disclaimer</a>
										</li>
										<li>
											<a href="#">Data protection declaration</a>
										</li>
									<li>
											<a href="#">Revocation right for consumers</a>
										</li>
									  
								 
									</ul>
									
								  
								</div>
							</div>
							<div class="col-sm-4 col-md-3">
								 <div class="footer-container">
									<h3>Contact</h3>
									<ul>
										<li style="color:white;">
											E-Mail: info@.com
										</li>									   
									    <li style="color:white;">									  
											Mobil:     +49 (0) 176 139 899 05 - Mo-Fr 9am to 6pm<br />
											Whats App: +49 (0) 176 139 899 05 - Mo-Fr 9am to 6pm
										</li>										
									</ul>
								</div>							   
							</div>
							<div class="col-sm-4 col-md-3">
								<div class="footer-container">
									<h3>SOCIAL</h3>
									<ul class="list-inline social-links">
										<li>
											<a href="https://www.facebook.com/Jamoona-549794422112112/">
												<i class="fa fa-facebook"></i>
											</a>
										</li>
										<li>
											<a href="https://twitter.com/JamoonaC">
												<i class="fa fa-twitter"></i>
											</a>
										</li>
										<li>
											<a href="https://www.youtube.com/channel/UCXD91Sat5ole3SaHsnFf5zg">
												<i class="fa fa-youtube"></i>
											</a>
										</li>										
									</ul>
								</div>
							   </div>
							</div>
						</div>
					</div>
					<div>
					<div class="copyright">
						<p>© 2020  glossary</p>
					</div>
					</div>
				</div>
			</div>
		</footer>
		<!--/Footer-->
	</footer>
</div>
</body>
<script>
	var app = angular.module("myApp", []);
	app.controller("myCtrl", ['$scope', '$http', function($scope, $http) {
		//alert($(this).href.substring(this.href.lastIndexOf('/') + 1));
		var urls = window.location.pathname;
		//alert(urls);
		var res = urls.split("/");
		//alert(res[2])
		if(res[2] == 'cart'){
			$scope.house_no = "<?php echo $result_user[0]->house_no; ?>";
			$scope.street = "<?php echo $result_user[0]->street; ?>";
			$scope.first_name = "<?php echo $result_user[0]->first_name; ?>";
			$scope.last_name = "<?php echo $result_user[0]->last_name; ?>";
			$scope.phone = "<?php echo $result_user[0]->phone; ?>";
			$scope.address = "<?php echo $result_user[0]->address; ?>";
			$scope.email_address = "<?php echo $result_user[0]->email_address; ?>";
			$scope.postal_code = "<?php echo $result_user[0]->postal_code; ?>";
			$scope.city = "<?php echo $result_user[0]->city; ?>";
			$scope.id = "<?php echo GET['id']; ?>";			
			
		}
		$scope.session_des = function(){
			$http({
				method: "POST",
				url: '<?php echo WEB_URL?>Login/session_destroys'
			}).then(function (response) {								
				window.location.href= "<?php echo WEB_URL;?>";							
			},function(){							
			});
		}
		$scope.clicked = function(){									
			$status_username = $status_password = 0;
			if ($scope.user_loginid == null || $scope.user_loginid == "") {					   
			   $("#user_loginid").css("border", " 2px solid red");
			   $("#user_loginid").focus();
			   $status_username = 1;
			}										  
			if ($scope.user_password == null || $scope.user_password == "") { 					   
			   $("#user_pwd").css("border", " 2px solid red");		
			   $("#user_pwd").focus();
			   $status_password = 1;
			}
			if($status_username == 0 && $status_password == 0 ){						
				var dataObj = {
								user_loginid : $scope.user_loginid,
								user_pwd : $scope.user_password										
						};							
				$http({
					method: "POST",
					url: '<?php echo WEB_URL?>Login/login_details',
					data: dataObj,          // You don't need to stringify it and no need to set any headers
				}).then(function (response) {							
					if (response.data == 1){								
						window.location.href= "<?php echo WEB_URL;?>";
					} else if (response.data == 0) {								
						$("#user_loginid").val('');
						$("#user_pwd").val('');
						$('.login_user').html('Incorrect Username Or Password');
						reset_alert();
					}
				}, function() {
					// Error callback
				});						
			}
		}			
			$scope.carts = [];
			$scope.cart_result = function() {
				$http.get("<?php echo WEB_URL?>product_single/order_get")
				.then(function(response) {
					console.log(response.data);
					if(response.data != "Not Logged"){
						$scope.carts = response.data;
					}					
				});
			}
			
			$scope.order_total = 0;
			$scope.order_id = "";
			$scope.order_total1 = function(){
				$http.get("<?php echo WEB_URL?>product_single/order_cart_total")
				.then(function(response) {			
					console.log(response.data);
					$scope.order_total =  response.data.total;	
					$scope.order_id = response.data.order_id;	
					console.log($scope.order_total);
				});					
			}			
			$scope.order_total1();
			
			$scope.cart_result();
			$scope.searchdata = function(){
				$http.get("<?php echo WEB_URL?>product_single/total_products")
				.then(function(response) {					 						
					$scope.search_result = response.data;	
						
					console.log($scope.search_result);
				});					
			}
			$scope.searchdata();
			$scope.res = [];
			$scope.search_event = function(input) {
				
				datas = $scope.search_events;
				if(datas == "" || datas == null){
					$scope.res = [];
				}else{
					$scope.res = $scope.search_result.filter(function(item){				
							if(item.product_name.toLowerCase().indexOf(datas.toLowerCase()) != -1){									
								return item;							
							}
						}
					)					
				}					
			}				
			$scope.hide_search = function(input) {
				$scope.res = [];
			}				
			
			$scope.cart_minus = function(){				
				$quantity = $('.item-quantity').val();
				if(parseInt($quantity) > 1){
					$quantity = parseInt($quantity)-1;
					$('.item-quantity').val($quantity);
				}					
			}
			$scope.cart_plus_cartpage = function(product_id,primary_ids,order_id,quantity){						
				$quantity = quantity;
				console.log($quantity);
				$quantity = parseInt($quantity)+1;
				$('.item-quantity'+order_id).val($quantity);
				$quantity = parseInt($quantity)-1;
					$('.item-quantity'+order_id).val($quantity);
					
					$id = product_id;
					console.log($('#single_cart'+order_id));
					$price_data = $('#single_cart'+order_id).html();
					alert($price_data);
					
					var dataObj = {
										id : product_id,
										user_id : "<?php echo $this->session->userdata['userId']['id'];?>",
										price : $price_data,
										quantity : $quantity
								};							
					console.log(dataObj);
					$http({
						method: "POST",
						url: '<?php echo WEB_URL?>product_single/insert_orders_plus',
						data: dataObj,
					}).then(function (response) {					
						alert('product added sucessfully ');
						console.log(response);
						$scope.cart_result();	
						$scope.order_total1();	
							
					}, function() {					
					});
			}
			
			$scope.cart_minus_cartpage = function(product_id,primary_ids,order_id,quantity){
				$quantity = quantity;
				if(parseInt($quantity) > 1){
					$quantity = parseInt($quantity)-1;					
					$('.item-quantity'+order_id).val($quantity);					
					$id = product_id;
					console.log($('#single_cart'+order_id));
					$price_data = $('#single_cart'+order_id).html();					
					var dataObj = {
										id : product_id,
										user_id : "<?php echo $this->session->userdata['userId']['id'];?>",
										price : $price_data,
										quantity : $quantity
								};					
					$http({
						method: "POST",
						url: '<?php echo WEB_URL?>product_single/insert_order_minus',
						data: dataObj,
					}).then(function (response) {					
						alert('product added sucessfully ');
						console.log(response);
						$scope.cart_result();	
						$scope.order_total1();	
					}, function() {					
					});
				}					
			}
			
			$scope.cart_remove = function(order_id){
				var dataObj = {
										order_id : order_id										
								};					
				$http({
						method: "POST",
						url: '<?php echo WEB_URL?>cart/delete_order',
						data: dataObj,
					}).then(function (response) {					
						alert('product added sucessfully ');
						console.log(response);
						$scope.cart_result();	
						$scope.order_total1();	
					}, function() {					
					});
			}
			$scope.user_empty = function(){					
				if($scope.user_loginid == "" || $scope.user_loginid == null || $scope.user_loginid == "undefined"){						
					$("#user_loginid").css("border", "2px solid red");					
				}else{
					$('#user_loginid').css("border", " 1px solid #cccccc");
				}
			}
			$scope.password_empty = function(){					
				if($scope.user_password == "" || $scope.user_password == null ||  $scope.user_password == "undefined"){
					$("#user_pwd").css("border", " 2px solid red");					
				}else{
					$("#user_pwd").css("border", " 1px solid #cccccc");	
				}		
			}
		
			$scope.click_register = function () {
				$scope.myTxt = "You clicked submit!";
				console.log('rest')
				$status_email = $status_password = $status_dob = $status_email = $status_dob = $status_first_name =   0;
				$status_last_name = $status_phone =  $status_house_no = $status_street = $status_postal_code = $status_city = 0;
				if ($scope.email_address == null || $scope.email_address == "") {					  
				   $("#email_address").css("border", " 2px solid red");		
				   $("#email_address").focus();
				   $status_email = 1;
				}										  
				if ($scope.c_email_address == null || $scope.c_email_address == "") {					  
				   $("#c_email_address").css("border", " 2px solid red");		
				   $("#c_email_address").focus();
				   $status_email = 1;
				}
				if ($scope.passwords == null || $scope.passwords == "") {					  
				   $("#passwords").css("border", " 2px solid red");		
				   $("#passwords").focus();
				   $status_password = 1;
				}										  
				if ($scope.c_password == null || $scope.c_password == "") {					  
				   $("#c_password").css("border", " 2px solid red");		
				   $("#c_password").focus();
				   $status_password = 1;
				}
				if ( ($scope.c_email_address != null || $scope.c_email_address != "") && ($scope.c_email_address != null || $scope.c_email_address != "")  ) {					  
					
				   if($scope.email_address != $scope.c_email_address ){
					   $("#c_email_address").css("border", " 2px solid red");		
					   $("#c_email_address").focus();
					   $("#email_address").css("border", " 2px solid red");		
					   $status_email = 1;
				   }					   
				}
				/*if ( ($scope.passwords != null || $scope.passwords != "") && ($scope.c_password != null || $scope.c_password != "")  ) {					  
					
				   if($scope.passwords != $scope.c_password ){
				
					   $("#passwords").css("border", " 2px solid red");		
					   $("#passwords").focus();
					   $("#c_password").css("border", " 2px solid red");		
					   $status_password = 1;
				   }				 	   
				}*/
				if ($scope.dob == null || $scope.dob == "") {					  
				   $("#dob").css("border", " 2px solid red");		
				   $("#dob").focus();
				   $status_dob = 1;
				
				}
				if ($scope.phone == null || $scope.phone == "") {					  
				   $("#phone").css("border", " 2px solid red");		
				   $("#phone").focus();
				   $status_phone = 1;
				
				}
				if ($scope.first_name == null || $scope.first_name == "") {					  
				   $("#first_name").css("border", " 2px solid red");		
				   $("#first_name").focus();
				   $status_first_name = 1;					
				}					
				if ($scope.last_name == null || $scope.last_name == "") {					  
				   $("#last_name").css("border", " 2px solid red");		
				   $("#last_name").focus();
				   $status_last_name = 1;					
				}
				if ($scope.house_no == null || $scope.house_no == "") {					  
				   $("#house_no").css("border", " 2px solid red");		
				   $("#house_no").focus();
				   $status_house_no = 1;					
				}
				if ($scope.street == null || $scope.street == "") {					  
				   $("#street").css("border", " 2px solid red");		
				   $("#street").focus();
				   $status_street = 1;					
				}
				if ($scope.postal_code == null || $scope.postal_code == "") {					  
				   $("#postal_code").css("border", " 2px solid red");		
				   $("#postal_code").focus();
				   $status_postal_code = 1;					
				}
				if ($scope.city == null || $scope.city == "") {					  
				   $("#city").css("border", " 2px solid red");		
				   $("#city").focus();
				   $status_city = 1;					
				}					
				if( ($status_email == 0) && ($status_password == 0) && ($status_dob == 0) && ($status_phone == 0) 
					 && ($status_first_name == 0) && ($status_last_name == 0)
					&& ($status_house_no == 0) && ($status_street == 0) && ($status_postal_code == 0) && ($status_city == 0)
				  ){		
					$("#c_email_address").css("border", "1px solid #cccccc");		
					$("#email_address").css("border", "1px solid #cccccc");		
					$("#dob").css("border", "1px solid #cccccc");		
					$("#phone").css("border", "1px solid #cccccc");		
					$("#first_name").css("border", "1px solid #cccccc");
					$("#last_name").css("border", "1px solid #cccccc");
					$("#house_no").css("border", "1px solid #cccccc");
					$("#street").css("border", "1px solid #cccccc");
					$("#postal_code").css("border", "1px solid #cccccc");
					$("#status_city").css("border", "1px solid #cccccc");
					var dataObj = {
									email_address : $scope.email_address,
									passwords : $scope.passwords,										
									dob : $scope.dob,
									phone : $scope.phone,
									first_name : $scope.first_name,
									last_name : $scope.last_name,
									house_no : $scope.house_no,
									street : $scope.street,
									postal_code : $scope.postal_code,
									city:$scope.city
							};							
					$http({
						method: "POST",
						url: '<?php echo WEB_URL?>registration/insert_register',
						data: dataObj,          // You don't need to stringify it and no need to set any headers
					}).then(function (response) {
						// Success callback
						
						alert('registered Successfully');
						$scope.email_address = "";
						$scope.passwords= "";
						$scope.c_password= "";
						$scope.dob= "";
						$scope.phone= "";
						$scope.first_name= "";
						$scope.last_name= "";
						$scope.house_no= "";
						$scope.street= "";
						$scope.postal_code= "";
						$scope.city= "";
						
					}, function() {
						// Error callback
					});						
				}					
			}
		
			
			$scope.click_save_order = function () {				
				$status_email =  $status_first_name =   0;
				$status_last_name = $status_phone =  $status_house_no = $status_street = $status_postal_code = $status_city = 0;
				if ($scope.email_address == null || $scope.email_address == "") {					  
				   $("#email_address").css("border", " 2px solid red");		
				   $("#email_address").focus();
				   $status_email = 1;
				}										  
				
				if ($scope.phone == null || $scope.phone == "") {					  
				   $("#phone").css("border", " 2px solid red");		
				   $("#phone").focus();
				   $status_phone = 1;
				
				}
				if ($scope.first_name == null || $scope.first_name == "") {					  
				   $("#first_name").css("border", " 2px solid red");		
				   $("#first_name").focus();
				   $status_first_name = 1;					
				}					
				if ($scope.last_name == null || $scope.last_name == "") {					  
				   $("#last_name").css("border", " 2px solid red");		
				   $("#last_name").focus();
				   $status_last_name = 1;					
				}
				if ($scope.house_no == null || $scope.house_no == "") {					  
				   $("#house_no").css("border", " 2px solid red");		
				   $("#house_no").focus();
				   $status_house_no = 1;					
				}
				if ($scope.street == null || $scope.street == "") {					  
				   $("#street").css("border", " 2px solid red");		
				   $("#street").focus();
				   $status_street = 1;					
				}
				if ($scope.postal_code == null || $scope.postal_code == "") {					  
				   $("#postal_code").css("border", " 2px solid red");		
				   $("#postal_code").focus();
				   $status_postal_code = 1;					
				}
				if ($scope.city == null || $scope.city == "") {					  
				   $("#city").css("border", " 2px solid red");		
				   $("#city").focus();
				   $status_city = 1;					
				}				
				if( ($status_email == 0)  && ($status_phone == 0) 
					 && ($status_first_name == 0) && ($status_last_name == 0)
					&& ($status_house_no == 0) && ($status_street == 0) && ($status_postal_code == 0) && ($status_city == 0)
				  ){		
					/*$("#c_email_address").css("border", "1px solid #cccccc");		
					$("#email_address").css("border", "1px solid #cccccc");		
					$("#dob").css("border", "1px solid #cccccc");		
					$("#phone").css("border", "1px solid #cccccc");		
					$("#first_name").css("border", "1px solid #cccccc");
					$("#last_name").css("border", "1px solid #cccccc");
					$("#house_no").css("border", "1px solid #cccccc");
					$("#street").css("border", "1px solid #cccccc");
					$("#postal_code").css("border", "1px solid #cccccc");
					$("#status_city").css("border", "1px solid #cccccc");*/
					
					//alert($scope.deliver_date);
					var dataObj = {
									email_address : $scope.email_address,																	
									phone : $scope.phone,
									first_name : $scope.first_name,
									last_name : $scope.last_name,
									house_no : $scope.house_no,
									street : $scope.street,
									postal_code : $scope.postal_code,
									city:$scope.city,
									id : "<?php echo $_GET['id']?>"								
							};			
					console.log(dataObj);			
					$http({
						method: "POST",
						url: '<?php echo WEB_URL?>cart/update_order',
						data: dataObj,          // You don't need to stringify it and no need to set any headers
					}).then(function (response) {
						// Success callback
						
						alert('registered Successfully');
						$scope.email_address = "";												
						$scope.phone= "";
						$scope.first_name= "";
						$scope.last_name= "";
						$scope.house_no= "";
						$scope.street= "";
						$scope.postal_code= "";
						$scope.city= "";
						
					}, function() {
						// Error callback
					});						
				}					
			}
		
			$(document).on('click', '#click_cart', function(){
				$id = "<?php echo $_GET['id'] ?>";
				$price_data = $('#price_data').html();
				$quantity = $('.item-quantity').val();	
				var dataObj = {
									id : $id,
									user_id : "<?php echo $this->session->userdata['userId']['id'];?>",
									price : $price_data,
									quantity : $quantity
							};							
					$http({
						method: "POST",
						url: '<?php echo WEB_URL?>product_single/insert_orders',
						data: dataObj,          // You don't need to stringify it and no need to set any headers
					}).then(function (response) {					
						alert('product added sucessfully ');
						console.log(response);
						$scope.cart_result();	
						$scope.order_total1();	
					}, function() {					
					});
			});				
			
			$scope.cart_minus = function(){
				console.log('fff');
				$quantity = $('.item-quantity').val();
				if(parseInt($quantity) > 1){
					$quantity = parseInt($quantity)-1;
					$('.item-quantity').val($quantity);
				}					
			}
			$scope.cart_plus = function(){						
				$quantity = $('.item-quantity').val();
				console.log($quantity);
				$quantity = parseInt($quantity)+1;
				$('.item-quantity').val($quantity);
			}
		
			$scope.dob_change = function(){					
				if($scope.dob == "" || $scope.dob == null ||  $scope.dob == "undefined"){
					$("#dob").css("border", "2px solid red");					
				}else{
					$("#dob").css("border", "1px solid #cccccc");	
				}		
			}
			$scope.phone_change = function(){					
				if($scope.phone == "" || $scope.phone == null ||  $scope.phone == "undefined"){
					$("#phone").css("border", "2px solid red");					
				}else{
					$("#phone").css("border", "1px solid #cccccc");	
				}		
			}
			$scope.first_name_change = function(){					
				if($scope.first_name == "" || $scope.first_name == null ||  $scope.first_name == "undefined"){
					$("#first_name").css("border", "2px solid red");					
				}else{
					$("#first_name").css("border", "1px solid #cccccc");	
				}		
			}
			$scope.first_name_change = function(){					
				if($scope.first_name == "" || $scope.first_name == null ||  $scope.first_name == "undefined"){
					$("#first_name").css("border", "2px solid red");					
				}else{
					$("#first_name").css("border", "1px solid #cccccc");	
				}		
			}
			$scope.last_name_change = function(){					
				if($scope.last_name == "" || $scope.last_name == null ||  $scope.last_name == "undefined"){
					$("#last_name").css("border", "2px solid red");					
				}else{
					$("#last_name").css("border", "1px solid #cccccc");	
				}		
			}
			$scope.house_no_change = function(){					
				if($scope.house_no == "" || $scope.house_no == null ||  $scope.house_no == "undefined"){
					$("#house_no").css("border", "2px solid red");					
				}else{
					$("#house_no").css("border", "1px solid #cccccc");	
				}		
			}
			$scope.street_change = function(){					
				if($scope.street == "" || $scope.street == null ||  $scope.street == "undefined"){
					$("#street").css("border", "2px solid red");					
				}else{
					$("#street").css("border", "1px solid #cccccc");	
				}		
			}
			$scope.postal_code_change = function(){					
				if($scope.postal_code == "" || $scope.postal_code == null ||  $scope.postal_code == "undefined"){
					$("#postal_code").css("border", "2px solid red");					
				}else{
					$("#postal_code").css("border", "1px solid #cccccc");	
				}		
			}
			$scope.city_change = function(){					
				if($scope.city == "" || $scope.city == null ||  $scope.city == "undefined"){
					$("#city").css("border", "2px solid red");					
				}else{
					$("#city").css("border", "1px solid #cccccc");	
				}		
			}
			$scope.email_change = function(){					
				if($scope.email_address == "" || $scope.email_address == null ||  $scope.email_address == "undefined"){
					$("#email_address").css("border", "2px solid red");					
				}else{
					$("#email_address").css("border", "1px solid #cccccc");	
				}		
			}
			$scope.c_email_change = function(){					
				if($scope.c_email_address == "" || $scope.c_email_address == null ||  $scope.c_email_address == "undefined"){
					$("#c_email_address").css("border", "2px solid red");					
				}else{
					$("#c_email_address").css("border", "1px solid #cccccc");	
				}		
			}
			$scope.passwords_change = function(){					
				if($scope.passwords == "" || $scope.passwords == null ||  $scope.passwords == "undefined"){
					$("#passwords").css("border", "2px solid red");					
				}else{
					$("#passwords").css("border", "1px solid #cccccc");	
				}		
			}
			$scope.c_password_change = function(){					
				if($scope.c_password == "" || $scope.c_password == null ||  $scope.c_password == "undefined"){
					$("#c_password").css("border", "2px solid red");					
				}else{
					$("#c_password").css("border", "1px solid #cccccc");	
				}		
			}
		}]);		
	function reset_alert(){
		setTimeout(function(){ $('.login_user').html(''); }, 3000);
	}			
</script>
</html>