
<div class="banner-wrap">
	<div style="clear:both"></div>
	<div class="container" style="padding-top:134px;">
		<div class="">
			<h1>Cart</h1>
		</div>
		<div class="row">
			<div class="row">
				<div class="col-md-2">					
					Image
				</div>
				<div class="col-md-2">
					Product Name
				</div>
				<div class="col-md-2">
					Price
				</div>
				<div class="col-md-2">
					Quantity
				</div>
				<div class="col-md-2">
					Total
				</div>
				<div class="col-md-2">
					Remove
				</div>
			</div>			


			<div class="row" ng-repeat="x in carts">
				<div class="col-md-2">
					<img style="width:50px;height:50px" src="<?php echo base_url().'admin/uploads/';?>{{x.product_img}}">
				</div>
				<div class="col-md-2">
					{{x.product_name}}
				</div>
				<div class="col-md-2">
					USD <font id="single_cart{{x.order_id}}">{{x.single_price}}</font>
				</div>
				<div class="col-md-2">
					
					<div class="wrapper"  style="height:50px">																	
									<span class="qty-up btooltip">
										<i class="fa fa-minus" ng-click="cart_minus_cartpage(x.product_id,x.primary_ids,x.order_id,x.quantity)"></i>
									</span>
									<input class="item-quantity{{x.order_id}}" type="text" name="ArticleQuantity" value="{{x.quantity}}" size="3" maxlength="3" readonly>
									<span class="qty-down btooltip" ng-click="cart_plus_cartpage(x.product_id,x.primary_ids,x.order_id,x.quantity)">
										<i class="fa fa-plus"></i>
									</span>	
								</div>
				</div>
				<div class="col-md-2">
					USD <font id="single_cart{{x.order_id}}">{{x.single_total}}</font>
				</div>
				<div class="col-md-2">
					 <font class="fa fa-close"  ng-click="cart_remove(x.order_id)"></font>
				</div>
			</div>	
			<div class="row">
				<div class="col-md-2">
				</div>
				<div class="col-md-2">
				</div>
				<div class="col-md-2">
				</div>
				<div class="col-md-2">
					Total
				</div>
				<div class="col-md-4">
					{{order_total}}
				</div>
			</div>	
			
			<div class="container" style="border:1px solid black">
				<div class="row">
					<div class="col-md-6">
						<label>Email Address</label>
						<input class="form-control" ng-model="email_address" ng-blur="email_change()" id="email_address" type="email" required name="email_address" >											
					</div>	
								
					<div class="col-md-6">
						<label>Phone</label>
						<input class="form-control" ng-blur="phone_change()"  name="phone" id="phone" ng-model="phone" id="phone" type="text">
					</div>	
				</div>
				<div class="row">
					<div class="col-md-6">
						<label>First Name</label>
						<input class="form-control" name="first_name" ng-blur="first_name_change()" id="first_name" ng-model="first_name" type="text">
					</div>	
					<div class="col-md-6">
						<label>Last Name</label>
						<input class="form-control" name="last_name" id="last_name" ng-blur="last_name_change()" ng-model="last_name" type="text">
					</div>	
				</div>
				<div class="row">
					<div class="col-md-6">
						<b>Billing Address</b>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						
						<label>House No</label>
						<input class="form-control" name="house_no" value="<?php echo $result_user[0]->house_no; ?>" id="house_no" ng-model="house_no" ng-blur="house_no_change()" type="text">
					</div>	
					<div class="col-md-6">
						<label>Street</label>
						<input class="form-control" name="street" id="street" ng-blur="street_change()" ng-model="street" type="text">
					</div>						
				</div>
				
				<br>
				<div class="row">
					<div class="col-md-6">
						<label>Postal code</label>
						<select ng-change="postal_code_change()" class="form-control" id="postal_code" name="pincode" ng-model="postal_code">
							<option value="">select</option>
							<?php foreach($pincode_data as $value){?>
								<option value="<?php echo $value['pincode_id'] ?>"><?php echo $value['pincode'] ?></option>
							<?php } ?>
						</select>					
					</div>	
					<div class="col-md-6">
						<label>City</label>
						<input class="form-control" id="city" name="city" ng-blur="city_change()" ng-model="city" type="text">
					</div>						
					
				</div>
				<br>
				<div class="row">								
					<div class="col-md-6 del">
						<b>Deliver Date</b><?php echo $deliver_date;?>
					</div>
					<div class="col-md-6">
						<button class="btn btn-primary" ng-click="click_save_order()" style="background-color:red" type="button" name="next_submit">Check Out</button>
					</div>
				</div>
				<br><br>
			</div>	
			<br><br><br>
		</div>
	</div>


	
</div>
	
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
		  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		  