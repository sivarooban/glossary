
<style>
.edit_div {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

.edit_div:hover {
  border: 1px solid #777;
}

.edit_div img {
  width: 100%;
  height: auto;
}

.edit_div {
  padding: 15px;
  text-align: center;
}
</style>
<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Testimonal Edit</h3>
            </div>
			<?php echo form_open_multipart('testimonal/edit/'.$testimonal['testimonals_id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="testimonals_status" class="control-label"><span class="text-danger">*</span>Testimonals Status</label>
						<div class="form-group">
							<select name="testimonals_status" class="form-control">
								<option value="">select</option>
								<?php 
								$testimonals_status_values = array(
									'active'=>'Active',
									'inactive'=>'Inactive',
								);

								foreach($testimonals_status_values as $value => $display_text)
								{
									$selected = ($value == $testimonal['testimonals_status']) ? ' selected="selected"' : "";

									echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('testimonals_status');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="testimonals_title" class="control-label"><span class="text-danger">*</span>Testimonals Title</label>
						<div class="form-group">
							<input type="text" name="testimonals_title" value="<?php echo ($this->input->post('testimonals_title') ? $this->input->post('testimonals_title') : $testimonal['testimonals_title']); ?>" class="form-control" id="testimonals_title" />
							<span class="text-danger"><?php echo form_error('testimonals_title');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="testimonals_image" class="control-label"><span class="text-danger">*</span>Testimonals Image</label>
						<div class="form-group">
							<input type="file" name="testimonals_image" value="<?php echo ($this->input->post('testimonals_image') ? $this->input->post('testimonals_image') : $testimonal['testimonals_image']); ?>" class="form-control" id="testimonals_image" onchange="readURL(this);" />
							<span class="text-danger"><?php echo form_error('testimonals_image');?></span>
						</div>
                        
                                           <div class="edit_div">

    
                            <img id="blah" src="<?php echo DIR_URL ;?>uploads/<?php echo $testimonal['testimonals_image'];?>" width="600" height="400"/>
                            
  
</div>
                        
					</div>
					<div class="col-md-6">
						<label for="testimonals_order_by" class="control-label"><span class="text-danger">*</span>Testimonals Order By</label>
						<div class="form-group">
							<input type="text" name="testimonals_order_by" value="<?php echo ($this->input->post('testimonals_order_by') ? $this->input->post('testimonals_order_by') : $testimonal['testimonals_order_by']); ?>" class="form-control" id="testimonals_order_by" />
							<span class="text-danger"><?php echo form_error('testimonals_order_by');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="testimonals_description" class="control-label"><span class="text-danger">*</span>Testimonals Description</label>
						<div class="form-group">
							<textarea name="testimonals_description" class="form-control" id="testimonals_description"><?php echo ($this->input->post('testimonals_description') ? $this->input->post('testimonals_description') : $testimonal['testimonals_description']); ?></textarea>
							<span class="text-danger"><?php echo form_error('testimonals_description');?></span>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>

<script>
function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result)
                    .width(150)
                    .height(200);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>