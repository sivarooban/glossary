<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Gallery Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('gallery/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>SNo</th>
						<th>Gallery Status</th>
						<th>Gallery Title</th>
						<th>Gallery Image</th>
						<th>Gallery Order By</th>
						<th>Actions</th>
                    </tr>
                    <?php 
					$s=1;
					foreach($gallery as $g){ ?>
                    <tr>
						<td><?php echo $s;?> </td>
						<td><?php echo $g['gallery_status']; ?></td>
						<td><?php echo $g['gallery_title']; ?></td>
						<!--<td><img src= <?php echo base_url();?>/uploads/<?php echo $g['gallery_image']; ?> width="8%" /></td>-->
							<td width="8%"><?php echo $g['gallery_image']; ?></td>
					<td ><?php echo $g['gallery_order_by']; ?></td>
						<td>
                            <a href="<?php echo site_url('gallery/edit/'.$g['gallery_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('gallery/remove/'.$g['gallery_id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php
					$s++;
					 } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
        </div>
    </div>
</div>
