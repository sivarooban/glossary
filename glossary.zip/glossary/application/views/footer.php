<footer>

				<!--Footer-->
				<footer>
					<div class="container-fluid">
						<div class="row">
							<div class="col-md-12 col-lg-9">
								<div class="row">
									<div class="col-md-12">
									  <!--  <div class="invite-friend">
											<i class="fa fa-envelope-open"></i>
											<a href="https://www.jamodaa.com/account/invite/">INVITE FRIENDS! GIVE $15 - GET $15</a>
										</div>-->
									</div>
									<div class="col-sm-4 col-md-3">
										<div class="footer-container">
											<h3>Categories</h3>
											<ul>
												<li>
													<a href="en/all-categories/index.html">All Products</a>
												</li>
											 
											   <li>
															   
											   <a href="en/all-categories/grains-lentils/index.html">Grains & Lentils </a></li>
															
														   
											   <li>
															   
											   <a href="en/all-categories/oils-spices/index.html">Oils & Spices </a></li>
												<li>
															   
											   <a href="en/all-categories/snacks-dry-fruits/index.html">Dry Fruit & Snacks </a></li>
												<li>
															   
											   <a href="en/all-categories/ready-to-eat-products/index.html">Ready to Eat </a></li>
												<li>
															   
											   <a href="en/all-categories/beverages/index.html">Beverages </a></li>
												 <li>
															   
											   <a href="en/all-categories/health-personal-care/index.html">Health Care </a></li>
											  
											  
											</ul>
										</div>
									</div>
									<div class="col-sm-4 col-md-3">
										<div class="footer-container">
											<h3>Infos</h3>
											<ul>
												
												<li>
													<a href="en/infos/shipping-paymentinfos/index.html">Shipping & Paymentinfos</a>
												</li>
												<li>
													<a href="infos/versand-zahlungsinformationen/index.html">Versand & Zahlungsinformationen</a>
												</li>
										  
												<li>
													<a href="infos/faq/index.html">FAQ</a>
												</li>
												  <li>
													<a href="infos/about-us/index.html">About Us</a>
												</li>
												
											 
											</ul>
										</div>
									</div>
									<div class="col-sm-4 col-md-3">
										<div class="footer-container">
											  <h3>RECHTLICHES</h3>
											<ul>
												<li>
													<a href="infos/impressum/index.html">Impressum</a>
												</li>
												<li>
													<a href="infos/agb/index.html">ABG</a>
												</li>
													<li>
													<a href="infos/haftungsausschluss/index.html">Haftungsausschluss</a>
												</li>
												<li>
													<a href="infos/datenschutz/index.html">Datenschutz</a>
												</li>
											<li>
													<a href="infos/widerrufsrecht.html">Widerrufsrecht</a>
												</li>
											  
										 
											</ul>
											
											<h3>LEGAL</h3>
											<ul>
												<li>
													<a href="en/infos/imprint/index.html">Imprint</a>
												</li> 
												<li>
													<a href="en/infos/terms-conditions/index.html">Terms & Conditions</a>
												</li>
													<li>
													<a href="en/infos/disclaimer/index.html">Disclaimer</a>
												</li>
												<li>
													<a href="en/infos/data-protection-declaration/index.html">Data protection declaration</a>
												</li>
											<li>
													<a href="en/infos/revocation-policy/index.html">Revocation right for consumers</a>
												</li>
											  
										 
											</ul>
											
										  
										</div>
									</div>
									<div class="col-sm-4 col-md-3">
										 <div class="footer-container">
											<h3>Contact</h3>
											<ul>
												<li style="color:white;">
													E-Mail: info@.com
												</li>
											   
											 <li style="color:white;">
											  
												  
													Mobil:     +49 (0) 176 139 899 05 - Mo-Fr 9am to 6pm<br />
													Whats App: +49 (0) 176 139 899 05 - Mo-Fr 9am to 6pm
												</li>
												
											</ul>
										</div>
									   
									</div>
									<div class="col-sm-4 col-md-3">
										<div class="footer-container">
											<h3>SOCIAL</h3>
											<ul class="list-inline social-links">
												<li>
													<a href="https://www.facebook.com/Jamoona-549794422112112/">
														<i class="fa fa-facebook"></i>
													</a>
												</li>
												<li>
													<a href="https://twitter.com/JamoonaC">
														<i class="fa fa-twitter"></i>
													</a>
												</li>
												<li>
													<a href="https://www.youtube.com/channel/UCXD91Sat5ole3SaHsnFf5zg">
														<i class="fa fa-youtube"></i>
													</a>
												</li>
											 
												
											</ul>
										</div>
									   </div>
									</div>
								</div>
							</div>
							<div>
								<div class="copyright">
									<p>© 2020  glossary</p>
								</div>
							</div>
						</div>
					</div>
				</footer>
				<!--/Footer-->


			</footer>
