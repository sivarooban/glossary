<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Sub Category Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('sub_category/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>Sub Category Id</th>
						<th>Category Id</th>
						<th>Sub Cat Status</th>
						<th>Subcategory Name</th>
						<th>Subcategory Code</th>
						<th>Created</th>
						<th>Modified</th>
						<th>Actions</th>
                    </tr>
                    <?php
                      $this->load->model('Sub_category_model');
                     foreach($sub_category as $s){ 
                        $cat_name=$this->Sub_category_model->cat_name($s['category_id']);
                        ?>
                    <tr>
						<td><?php echo $s['sub_category_id']; ?></td>
						<td><?php echo $cat_name; ?></td>
						<td><?php echo $s['sub_cat_status']; ?></td>
						<td><?php echo $s['subcategory_name']; ?></td>
						<td><?php echo $s['subcategory_code']; ?></td>
						<td><?php echo $s['created']; ?></td>
						<td><?php echo $s['modified']; ?></td>
						<td>
                            <a href="<?php echo site_url('sub_category/edit/'.$s['sub_category_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('sub_category/remove/'.$s['sub_category_id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
        </div>
    </div>
</div>
