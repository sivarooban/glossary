<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Sub Category Add</h3>
            </div>
            <?php echo form_open('sub_category/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="category_id" class="control-label"><span class="text-danger">*</span>Category</label>
						<div class="form-group">
							<select name="category_id" class="form-control">
								<option value="">select category</option>
								<?php 
								foreach($all_category as $category)
								{
									$selected = ($category['category_id'] == $this->input->post('category_id')) ? ' selected="selected"' : "";

									echo '<option value="'.$category['category_id'].'" '.$selected.'>'.$category['category_name'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('category_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="sub_cat_status" class="control-label">Sub Cat Status</label>
						<div class="form-group">
							<select name="sub_cat_status" class="form-control">
								<option value="">select</option>
								<?php 
								$sub_cat_status_values = array(
									'1'=>'Active',
									'0'=>'Inactive',
								);

								foreach($sub_cat_status_values as $value => $display_text)
								{
									$selected = ($value == $this->input->post('sub_cat_status')) ? ' selected="selected"' : "";

									echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
								} 
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<label for="subcategory_name" class="control-label"><span class="text-danger">*</span>Subcategory Name</label>
						<div class="form-group">
							<input type="text" name="subcategory_name" value="<?php echo $this->input->post('subcategory_name'); ?>" class="form-control" id="subcategory_name" />
							<span class="text-danger"><?php echo form_error('subcategory_name');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="subcategory_code" class="control-label">Subcategory Code</label>
						<div class="form-group">
							<input type="text" name="subcategory_code" value="<?php echo $this->input->post('subcategory_code'); ?>" class="form-control" id="subcategory_code" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="created" class="control-label">Created</label>
						<div class="form-group">
							<input type="text" name="created" value="<?php echo $this->input->post('created'); ?>" class="form-control" id="created" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="modified" class="control-label">Modified</label>
						<div class="form-group">
							<input type="text" name="modified" value="<?php echo $this->input->post('modified'); ?>" class="form-control" id="modified" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>