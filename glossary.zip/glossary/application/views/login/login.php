
<div class="banner-wrap">           
	<a href="#">
		<img class="desktop" src="<?php  echo base_url();?>resources/img/organic-food-banner.jpg" style="width:100%" id="banner_desktop">  
		<img class="mobile" src="layout/images/slider/mobile.jpg" style="width:100%" id="banner_mobile">
	</a>
</div>
<div class="saving-wrap" style="    margin-top: -6px;">
    <div class="container">
        <div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6">              	
				<div class="saving--item__single">						
					<div class="saving--item__text">
						<h4>Low PRICES</h4>
						<p>Lowest Prices</p>
					</div>
				</div>               
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6">              
				<div class="saving--item__single">						
					<div class="saving--item__text">
						<h4>Cash On Delivery</h4>
						<p>Only Cash No Only Payment</p>
					</div>
				</div>               
			</div>	
			
        </div>
    </div>
</div>
<!--Featured-->
<div class="featured-wrap" style="margin-bottom: -30px;">
   <div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<div class="main-title">                  
					<h4 style="text-transform: uppercase;font-size: 15px;color: #2b2b2b;font-weight: 700;margin: 0;">
						Featured Categories
						<i class="fa fa-angle-right"></i>
						<i class="fa fa-angle-right"></i>
					</h4>                                             
				</div>
			</div>     
			<?php							
				forEach($all_sub_category as $value){						
			?>
			<div class="col-xs-6 col-sm-4">
				<div class="featured-container text-center">
					<a href="#">							
						<img class="img-responsive center-block" src="<?php echo base_url()."admin/uploads/".$value['category_image'];?>" alt="" />
						<h4><?php echo $value['category_name'];?>
							<i class="fa fa-angle-right"></i>
							<i class="fa fa-angle-right"></i>
						</h4>
					</a>
				</div>
			</div>
			<?php } ?>
		</div>
	</div>    
</div>
<!--/Featured--> 

<div class="featured-wrap">
    <div class="container-fluid">
        <div class="row">
			<div class="col-sm-12">
				<div class="main-title">
					<a href="en/all-categories/bestsellers/index.html">
						<h4>SALE PRODUCTS
							<i class="fa fa-angle-right"></i>
							<i class="fa fa-angle-right"></i>
						</h4>
					</a>                        
				</div>		
			</div>
         </div>
    </div>
</div>

<div class="container-fluid" style="margin-top:-50px;">	
	<ul class="row categoryDetails isGridView " data-plenty-details="categoryDetails">
		<div class="col-12">
			<div class="product-slider">
				<?php forEach($product as $value){ ?>			
				<!-- item box -->
				<li class="product-container margin-bottom-2 tileView onHover action-1" data-plenty="item" data-plenty-id="13070">					
					<div class="action js-link" data-plenty="click:Redirect.to( 'en/all-categories/ahmeda-rose-petal-spread-murabba-400-grams/a-13070/index.html' )"="item-13070" 
						style="background-color: red;color: #fff;padding: 1px 15px;position: absolute;z-index: 100;opacity: 0.7;">
						<?php echo $value['product_name']?>
					</div>					
					<div class="itemBoxInner">
						<div id="previewImages-13070" class="p_slider-img-wrap h-md-3 h-sm-2 h-xs-6">							
							<div class="imageBox p_slider-img-wrap h-md-3 h-sm-2 h-xs-6 adapt-line-height">
								<a href="#">		
									<img class="center img-responsive id-13070 js-link" src="<?php echo base_url()."admin/uploads/".$value['product_img']?>">
								</a>							
							</div>						
						</div>												
						<a href="#">
							<h4 class="name block" href="en/all-categories/ahmeda-rose-petal-spread-murabba-400-grams/a-13070/index.html" data-plenty-href="item-13070">Ahmed Gulkand (Rose Petal Spread) - Murabba - 400 Grams</h4>
						</a>						
						<a href="#">
							<p class="p_sub-text">Size:  0.4 kg</p>
						</a>					
						<p class="price bold js-link margin-bottom-0">
							<br />
							<?php echo $value['price']?>
						</p>																
						<div class="visible-hover">
							<div class="basketButtonContainer clearfix" style="text-align: center;">									
								<div class="buttonBox shipping-tray isViewItem">
									<a class="btn" href="<?php echo base_url()."product_single?id=".$value['product_id']?>">			
										View Product
									</a>
								</div>									
							</div>
						</div>				
					</div>								
				</li>
				<!-- ./item box -->
				<?php } ?>
			</div>
		</div>
	</ul>

</div>
    
<!--Deals-->
<div class="deals-wrap">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6">
				<div class="beverages-container sandwitch-container">
					<h3>Snacks time is the best time</h3>
					<p>up to 40% off</p>
					<a href="#" class="btn">Shop Now</a>
					<img class="img-responsive lazy" data-src="/layout/images/teaser1.png" alt="" />
				</div>
			</div>
			<div class="col-sm-6">
				<div class="beverages-container stock-container" style="padding: 33px 20px;">
					<h3>Deals like never before</h3>
				   <p>flat up to 35% off</p>
					<a href="#" class="btn">Shop Now</a>
					<img class="img-responsive lazy" data-src="/layout/images/teaser2.png" alt="" />
				</div>
			</div>
		</div>
	</div>

</div>
<!--/Deals-->
  
<div class="featured-wrap">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<div class="main-title">
					<a href="en/all-categories/sale/index.html">
						<h4>Our best selling Products
							<i class="fa fa-angle-right"></i>
							<i class="fa fa-angle-right"></i>
						</h4>
					</a>                        
				</div>
			</div>
		</div>
	</div>

</div>

<div class="container-fluid" style="margin-top:-50px;">
	<ul class="row categoryDetails isGridView " data-plenty-details="categoryDetails">
		<div class="col-12">
			<div class="product-slider">
				<?php forEach($product as $value){ ?>			
				<!-- item box -->
				<li class="product-container margin-bottom-2 tileView onHover action-1" data-plenty="item" data-plenty-id="13070">					
					<div class="action js-link" data-plenty="click:Redirect.to( 'en/all-categories/ahmeda-rose-petal-spread-murabba-400-grams/a-13070/index.html' )"="item-13070" 
						style="background-color: red;color: #fff;padding: 1px 15px;position: absolute;z-index: 100;opacity: 0.7;">
						<?php echo $value['product_name']?>
					</div>					
					<div class="itemBoxInner">
						<div id="previewImages-13070" class="p_slider-img-wrap h-md-3 h-sm-2 h-xs-6">							
							<div class="imageBox p_slider-img-wrap h-md-3 h-sm-2 h-xs-6 adapt-line-height">
								<a href="#">		
									<img class="center img-responsive id-13070 js-link" src="<?php echo base_url()."admin/uploads/".$value['product_img']?>">
								</a>							
							</div>						
						</div>												
						<a href="#">
							<h4 class="name block" href="en/all-categories/ahmeda-rose-petal-spread-murabba-400-grams/a-13070/index.html" data-plenty-href="item-13070">Ahmed Gulkand (Rose Petal Spread) - Murabba - 400 Grams</h4>
						</a>						
						<a href="#">
							<p class="p_sub-text">Size:  0.4 kg</p>
						</a>					
						<p class="price bold js-link margin-bottom-0">
							<br />
							<?php echo $value['price']?>
						</p>																
						<div class="visible-hover">
							<div class="basketButtonContainer clearfix" style="text-align: center;">									
								<div class="buttonBox shipping-tray isViewItem">
									<a class="btn" href="<?php echo base_url()."product_single?id=".$value['product_id']?>">			
										View Product
									</a>
								</div>									
							</div>
						</div>				
					</div>								
				</li>
				<!-- ./item box -->
				<?php } ?>
			</div>
		</div>
	</ul>


</div>


<!--Deals-->
<div class="deals-wrap" >
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6">
				<div class="deals-container text-center">
					<h3>Deals of the week</h3>
					<p>up to 45% off on Rice products</p>
					<a href="en/all-categories/rice-pulses-flour/rice-noodles/index.html" class="btn">Shop Now</a>
					<img class="img-responsive lazy" data-src="/layout/images/teaserricefinal_1.png" alt="" />
				</div>
			</div>
			<div class="col-sm-6">
				<div class="beverages-container">
					<h3>Your favorite beverages</h3>
					<p>up to 39% discount</p>
					<a href="en/all-categories/beverages/index.html" class="btn">Shop Now</a>
					<img class="img-responsive lazy" data-src="/layout/images/teaser4.png" alt="" />
				</div>
				<div class="beverages-container stock-container">
					<h3>Wonderful snacks with wow deals</h3>
					<p>Made for snack time</p>
					<a href="en/all-categories/snacks-dry-fruits/index.html" class="btn">Shop Now</a>
					<img class="img-responsive lazy" data-src="/layout/images/teaser5.png" alt="" />
				</div>
			</div>
		</div>
	</div>
</div>

<!--Deals-->
     
<div class="featured-wrap">
    <div class="container-fluid">
        <div class="row">
			<div class="col-sm-12">
				<div class="main-title">
					<a href="en/all-categories/new-items/index.html">
						<h4>New products
							<i class="fa fa-angle-right"></i>
							<i class="fa fa-angle-right"></i>
						</h4>
					</a>                        
				</div>		
			</div>
        </div>
    </div>
</div>
<div class="container-fluid" style="margin-top:-50px;">        
	<ul class="row categoryDetails isGridView">
		<div class="col-12">
			<div class="product-slider">			
				<?php forEach($product as $value){?>
					<!-- item box -->
					<li class="product-container margin-bottom-2 tileView onHover action-3">						
						<div class="itemBoxInner">
							<div id="previewImages-990294" class="p_slider-img-wrap h-md-3 h-sm-2 h-xs-6">							
								<div class="imageBox p_slider-img-wrap h-md-3 h-sm-2 h-xs-6 adapt-line-height">
									<a href="#">		
										<img class="center img-responsive id-990294 js-link" src="<?php echo base_url()."admin/uploads/".$value['product_img']?>" >
									</a>									
								</div>					
							</div>						
							<!-- item info -->	
							<a href="#">
								<h4 class="name block" href="#">
									<?php echo $value['product_name']?>
								</h4>
							</a>						
							<a href="#">
								<p class="p_sub-text">
									Size:  1 kg
								</p>
							</a>					
							<p class="price bold js-link margin-bottom-0">
								<br />
								<?php echo $value['price']?>
							</p>						
							<div class="visible-hover">					
								<div class="basketButtonContainer clearfix" style="text-align: center;">											
									<div class="buttonBox shipping-tray isViewItem">
										<a class="btn" href="<?php echo base_url()."product_single?id=".$value['product_id']?>">																
											View Product</a>														
									</div>					
								</div>
						</div>							
					</div>				
				</li>
				<!-- ./item box -->
		
				<?php } ?>	
		
			</div>		
		</div>		
	</ul>
</div>
