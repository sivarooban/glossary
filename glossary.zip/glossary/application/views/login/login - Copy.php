<!DOCTYPE html>
	<html lang="en">
	<head>   		
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
		<title>Glossary Items</title>
		<link rel="shortcut icon" type="image/x-icon" href="layout/images/favicon.png">
		<script src="<?php  echo base_url();?>resources/js/compressed.js" type="text/javascript"></script>
    	<link rel="canonical" href="en/index.html" />
		<link rel="stylesheet" type="text/css" href="<?php  echo base_url();?>resources/css/jamoona_en_content2335.css?625" />
		<link rel="shortcut icon" type="image/ico" href="tpl/favicon_0.html" />
		<meta name="keywords" content="" />		
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<!--css-->
		<link href="<?php  echo base_url();?>resources/css/bootstrap.css" rel="stylesheet" type="text/css" />
		<link href="<?php  echo base_url();?>resources/css/style1.css" rel="stylesheet" type="text/css" />
		<link href="<?php  echo base_url();?>resources/css/responsive.css" rel="stylesheet" type="text/css" />    
		<link href="<?php  echo base_url();?>resources/css/style.css" rel="stylesheet" media="screen">        
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900,900i&amp;display=swap" rel="stylesheet">
        <link rel="stylesheet" href="<?php  echo base_url();?>resources/css/font-awesome.min.css">
		<!--<link href="/layout/new/css/font-awesome.css" rel="stylesheet" type="text/css" />-->
		<link href="<?php  echo base_url();?>resources/css/owl.carousel.min.css" rel="stylesheet" type="text/css" />
		<link href="<?php  echo base_url();?>resources/css/owl.theme.default.min.css" rel="stylesheet" type="text/css" />		
		<link href="<?php  echo base_url();?>resources/css/slick.css" rel="stylesheet" type="text/css" />
		<link href="<?php  echo base_url();?>resources/css/slick-theme.css" rel="stylesheet" type="text/css" />			  
		<style>			
			#auorg-bg{    
				top: 45% !important;
			}
			.fa, .far, .fas {
					font-family: FontAwesome !important;
			}			
			@media (min-width: 1200px) {
				.deals-container img {    
					width: 90%;
					margin-left: 33px;
					
					
					
				} 
			}
			@media (min-width: 1900px) {
			.deals-container img {
				
				   width: 80%;
				margin-left: 85px;
				
				
			} }


				@media (max-width: 699px) {
				.deals-container img {
					
				   height: 50%;
					margin-left: 28px;
					
					
					
				}

				.desktop {
					
				   display: none;
				   
					
					
					
				}


				.quantity-wrapper {
				   
					float: none;
					}
					
					
					
				}
			
					@media (min-width: 1200px) {


					.checkout  {
						
					   
						 margin-top:200px;
						
					} 

						
					}

					@media (max-width: 1300px) {


					.serach-bar {
					   
						width: 520px;
						
					} 

						
					}

					@media (min-width: 761px) {


					.mobile  {
						
					   
						 display:none;
						
					} 

					}

			</style>
	
		  <!--scripts-->
    	
    <script src="<?php  echo base_url();?>resources/js/bootstrap.js" type="text/javascript"></script>
    <script src="<?php  echo base_url();?>resources/js/easing.js" type="text/javascript"></script>
    <script src="<?php  echo base_url();?>resources/js/move-top.js" type="text/javascript"></script>
    <script src="<?php  echo base_url();?>resources/js/owl.carousel.min.js" type="text/javascript"></script>
    
    <script src="<?php  echo base_url();?>resources/js/slick.min.js" type="text/javascript"></script>
    
    <script src="<?php  echo base_url();?>resources/js/script.js" type="text/javascript"></script>


		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="/layout/callisto_3/js/libs/html5shiv.js"></script>
			<script src="/layout/callisto_3/js/libs/respond.min.js"></script>
		<![endif]-->
		<script src="<?php  echo base_url();?>resources/js/plenty/ScriptLoader.js"></script>
		
	<body class="plenty no-js en isHome isCat-21" data-plenty="MobileDropdown.initDropdowns(); UI.initUIWindowEvents();">
	
		
		<div class="wrapper">
	
			<a id="top"></a>
	
			<header>
    	
    
    	
            <div class="top-header">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-6">
                            <p style="text-transform:uppercase;">FREE shipping at €29 inside Germany</p>
                        </div> 
                        <div class="col-md-6 pull-rgt">
                            <ul class="top-menu">
                                <li>
                                    <a href="infos/about-us/index.html">
                                        About Us
                                    </a>    
                                </li>
                                <li>
                                    <a href="infos/faq/index.html">
                                        FAQ
                                    </a>    
                                </li>
                                <li>
                                    <a href="en/infos/shipping-paymentinfos/index.html">
                                        Shipping Details
                                    </a>    
                                </li>    
                            </ul>    
                        </div>   
                    </div>
                    
	
		
	
                    <div class="row">
                        <div class="col-lg-8 col-md-8">
                            <div class="menu-lft">
                                <a href="en.html"> <div class="logo" style="color:white;font-size:15px">
                                  <!--<img src="layout/newsheader/images/logo.png" alt="logo">-->
								  Glossary
                                </div></a> 
                                <div class="serach-bar">
                                    <div class="form-group" id="search_desktop">
                                    		<form role="search" method="get" name="search_form" action="https://www.jamoona.com/" data-plenty="navbarForm">
                                    			<input type="hidden" name="ActionCall" value="WebActionArticleSearch">
                                        <input type="text" class="form-control"id="LiveSearchParam"  placeholder="Search your favorite asian products at wholesale prices..." 
                                        autocomplete="off" 
						name="Params[SearchParam]" 
						type="search" 
						
						onkeyup="if(this.value.length<2){$p('livesearch_result').style.display='none';return;}else{$p('livesearch_result').style.display='block';plentyAjaxRequest('WebAjaxBasef5b7.php?Object=article@LiveArticleSearch&amp;SearchParam='+encodeURIComponent(this.value))}" />
				
                                        <button type="button" class="btn btn-primary search-btn" type="submit">
                                          
                                        <span class="glyphicon glyphicon-search" style="color:white;    position: absolute;
    top: -2px;
    left: 17px;"></span><span class="sr-only">Finden</span>
                                        </button>
                                        		

                                        
                                        	<div id="livesearch_result" class="liveSearch"></div>
			</form>
				
				
					
						
		
                                    </div>
                                </div>    
                            </div>    
                        </div>
                       
                         
                                <ul class="nav navbar-nav navbar-right pull-right">
			
				
	
    
  
    
					<li class="dropdown isLogin enable-xs-sm">
						<a href="javascript:void(0);" class="dropdown-toggle toggle-xs-sm-or-touch" data-plenty="click:MobileDropdown.openDropdown(this, true)">
							<span class="fa fa-user" style="float:left;"></span><span class="hidden-xs" style="float:left;">&nbsp;Login</span>
						</a>
						<ul class="dropdown-menu dropdown-menu-right dropdown-padding" role="menu" data-plenty="loginFormContainer">
							<li>
								<form class="form-inline form-block-2-button break-sm loginForm" method="post" action="https://www.jamoona.com/en/my-account/" data-plenty-checkout-form="customerLogin" data-plenty="submit:Validator.validate(this, 'has-error'); submit:Authentication.login(this)">
									<div class="form-group">
										<label class="sr-only" for="checkout-login-email">E-Mail-Adress</label>
										<input class="form-control" id="checkout-login-email" name="loginMail" type="email" placeholder="E-Mail-Adress" data-plenty-validate="mail">
									</div><!--
									--><div class="form-group">
										<label class="sr-only" for="checkout-login-password">Password</label>
										<input class="form-control" id="checkout-login-password" name="loginPassword" type="password" placeholder="Password" data-plenty-validate="text">
									</div><!--
									--><button class="btn btn-primary onlyIcon" type="submit">
										<span class="large glyphicon glyphicon-arrow-right"></span><span class="hidden-md hidden-lg margin-left-05"> Login</span>
									</button>
								</form>
								<div>
									<a class="iconLink" href="en/jamoona/forgot-passwort/index.html"><span class="glyphicon glyphicon-question-sign"></span>&nbsp;Forgot password?</a>
								</div>
								<hr class="margin-top-05 margin-bottom-05">
								<div class="clearfix">
									<a class="iconLink pull-left" href="en/jamoona/registration/index.html"><span class="glyphicon glyphicon-pencil"></span>&nbsp;Register</a>
									<a class="iconLink cancel pull-right" href="javascript:void(0);" data-plenty="cancelLogin"><span class="glyphicon glyphicon-remove"></span>&nbsp;Close</a>
								</div>
							</li>
						</ul>
					</li>
				
				<li class="dropdown isBasketPreview disabled" data-plenty-basket-empty="disabled">
					<a href="en/jamoona/cart/index.html" style="float:left;" class="dropdown-toggle toggle-xs-sm-or-touch" data-plenty="click:MobileDropdown.openDropdown(this, true); click:UI.toggleClass('aside-visible', 'body', 'xs,sm'); click:Tab.showRemoteTab('basketPreview', 'aside', 'xs,sm')">
						<span class="fa fa-cart" style="float:left;"></span><span class="hidden-xs" style="float:left;">&nbsp;Cart</span>&nbsp;<span class="badge" data-plenty-basket-preview="itemQuantityTotal" style="float:left;"><span class="basket_quantity" id="basket_quantity">0</span></span>
					</a>
					<ul class="dropdown-menu dropdown-padding" role="menu">
						<li>
							<div class="overlay aside-overlay closeIcon top-left" data-plenty="click:UI.toggleClass('aside-visible', 'body')"></div>
							<div class="basketPreviewContainer asidePanel" data-plenty="basketPreviewContainer">
								<div class="remotetabs-tabpanel is-basket" data-plenty="Tab.initRemoteTab(this, 'basketPreview', 'aside')">
									<div class="basketPreviewContent gradient-y-fade-in" data-plenty-itemview-template="BasketPreviewList">
										

	<div class="padding-top-15 margin-bottom-1">You do not have any products in your shopping cart.</div>

									</div>
								</div>
							</div>
						</li>
					</ul>
				</li>
			</ul>
                               		
			
                               
                               
                               
                               
                               
                               
                               
                            </div>        
                         
                     
                </div>   
            </div>
            
               

            

            <nav id="wednavbar" class="navbar menu-wrap bottom-header">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
				
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav menu-main">
                        <li class="dropdown active">
                            <a href="en/all-categories/index.html" class="dropdown-toggle" data-toggle="dropdown">All Products
                                <i class="fa fa-caret-down"></i>
                            </a>
                            <ul class="dropdown-menu">
								<?php 
									foreach($menu as $value){  ?>
									<li class="dropdown dropdown-submenu">
										<a href="en/all-categories/rice-pulses-flour/index.html" class="dropdown-toggle" data-toggle="dropdown"><?php print_r($value['category_name']);?>
											<i class="fa fa-caret-right"></i>
										</a>
										<?php if(!empty($value['product_datas']) ) {  ?>
											<ul class="dropdown-menu">
												<?php foreach($value['product_datas'] as $value1){  ?>
													<li>
														<a href="en/all-categories/rice-pulses-flour/atta-flour/index.html"><?php echo $value1['product_name'] ?> </a>
													</li>
												<?php } ?>	
											</ul>
										<?php } ?>
									</li>                               
								  
								<?php } ?>
                                <li>
                                    <a href="en/all-categories/profession-chef-range/index.html">Professional Chefs</a>
                                </li>


                                <li>
                                    <a href="en/all-categories/index.html">Shop All Products </a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="en/all-categories/bestsellers/index.html">Best Sellers</a>
                        </li>
                        <li>
                            <a href="en/all-categories/new-items/index.html">All New</a>
                        </li>

                        <!-- <li>
                             <a href="https://www.jamodaa.com/products/highlight/2/on-sale/">Stock clearance</a>
                         </li>-->
                         
                        <li>
                            <a href="en/all-categories/sale/index.html" style="color:red; font-weight:500;">Sale!</a> </li>
                            
                           
                        <!-- <li>
                             <a href="https://www.jamodaa.com/samples/">Recipes blog</a>
                         </li>-->
                    </ul>
                </div>
            </nav>    

        </header>
        
        <div class="mobile-menu">
        		
            <div class="mobile-menu-top">
                <div class="row">
                    <div class="mobile-menu-topleft">
                        <div class="col-xs-1">
                            <nav id="menu">
                                <div class="swipe-area"></div>
                               	<label for="tm" data-toggle=".main-menu" id="toggle-menu" >
                               		<img class="img-fluid" src="layout/newsheader/images/menu-icon.png" alt="" onclick="lockScroll();">
                               	</label>
                                <input type="checkbox" id="tm">
                                <ul class="main-menu clearfix">
                                    <li class="login-signup">
                                        <a href="en/jamoona/login/index.html" class="usr-icn"><img src="layout/newsheader/images/black-user.png" /></a>
                                        <a href="en/jamoona/login/index.html" class="lgn">
                                            Login
                                        </a>
                                        <a href="en/jamoona/registration/index.html">
                                            Signup
                                        </a>    
                                    </li> 
                                    <hr>
                                    <li>
                                        <a href="en/all-categories/index.html">All Products
                                            <span class="drop-icon">▾</span>
                                            <label title="Toggle Drop-down" class="drop-icon" for="sm1">▾</label>
                                        </a>
                                        <input type="checkbox" id="sm1">
                                        <ul class="sub-menu">
                                            <li>
                                                <a href="products/category/98/grocery/index.html">Rice,Pulses & Flour
                                                    <span class="drop-icon">▾</span>
                                                    <label title="Toggle Drop-down" class="drop-icon" for="sm2">▾</label>
                                                </a>                                                
                                                <ul class="sub-menu">
													<li>
														<a href="en/all-categories/rice-pulses-flour/atta-flour/index.html">Atta &amp; flour </a>
													</li>
													<li>
														<a href="en/all-categories/rice-pulses-flour/rice-noodles/index.html">Rice &amp; Rice products</a>
													</li>
													<li>
														<a href="en/all-categories/rice-pulses-flour/dal-lentils-beans/index.html">Dals, Lentils, &amp; Beans </a>
													</li>
													<li>
														<a href="en/all-categories/rice-pulses-flour/index.html">Shop All Rice, Pulses &amp; Flour </a>
													</li>
                                                </ul>
                                            </li>
                                            
                                            
                                             
                                              
                                              
                                              
                                             
                                             
                                             
                                             
                                            
                                 
                                <li>
                                    <a href="en/all-categories/profession-chef-range/index.html">Professional Chefs</a>
                                </li>


                                <li>
                                    <a href="en/all-categories/index.html">Shop All Products </a>
                                </li>
                                            
                                            
                                            
                                            
                                        </ul>
                                      
                                        
                                    
                                    </li>
                                    <hr>
                                    <li>
                                        <a href="en/all-categories/bestsellers/index.html">
                                            Best Sellers
                                        </a>    
                                    </li>
                                    <li>
                                        <a href="en/all-categories/new-items/index.html">
                                            All New
                                        </a>    
                                    </li>
                                 
                            </li>
                            
                           
                                    <li class="red-menu">
                                        <a href="en/all-categories/sale/index.html">
                                            SALE
                                        </a>    
                                    </li>
                                    <hr>
                                    <li>
                                        <a href="infos/about-us/index.html">
                                            About Us
                                        </a>    
                                    </li>
                                    <li>
                                        <a href="infos/faq/index.html">
                                            FAQ
                                        </a>    
                                    </li>
                                    <li>
                                         <a href="en/infos/shipping-paymentinfos/index.html">
                                        Shipping Details
                                    </a>    
                                    </li>
                                </ul>
                            </nav>
                        </div>
                        <div class="col-xs-7">
                            <a href="en.html">
                                <div class="logo">
                                    <img src="layout/newsheader/images/logo.png" alt="logo">
                                </div>
                            </a>
                        </div>
                        <div class="col-xs-3 pull-right">
                            <div class="cart">
                                <a href="en/jamoona/cart/index.html">
                                    <img src="layout/newsheader/images/cart.png">
                                <span data-plenty-basket-preview="itemQuantityTotal"> <span class="basket_quantity" id="basket_quantity">0</span></span>
                                </a>    
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
            <div class="mobile-menu-middle">
               <!--<div class="row">
                    <div class="col-sm-12">-->
                        <div class="serach-bar">
                            <div class="form-group" id="search_mobile">
                            		<form role="search" method="get" name="search_form" action="https://www.jamoona.com/" data-plenty="navbarForm">
                            				<input type="hidden" name="ActionCall" value="WebActionArticleSearch">
                                 <input  style="font-size:17px;" type="text" class="form-control" id="LiveSearchParam"  placeholder="Search your favorite asian products..." 
                                        autocomplete="off" 
						name="Params[SearchParam]" 
						type="search" 
					
						onkeyup="if(this.value.length<2){$p('livesearch_result').style.display='none';return;}else{$p('livesearch_result').style.display='block';plentyAjaxRequest('WebAjaxBasef5b7.php?Object=article@LiveArticleSearch&amp;SearchParam='+encodeURIComponent(this.value))}" />
				
                                <button type="button" class="btn btn-primary" type="submit">
                                    <i class="fa fa-search"  style="color:white;     position: absolute;
    top: 10px;
    left: 17px;"></i>
                                </button>
                                
                                
                                        	<div id="livesearch_result" class="liveSearch"></div>
			</form>
                                
                            </div>
                        </div>
                   <!--   </div>    
                </div>  -->
            </div>
            <div class="mobile-menu-bottom">
                <p style="text-transform:uppercase;">FREE shipping at €29 inside Germany</p>
            </div>  
        </div>
        <!-- JavaScripts -->
        
      <script>
            

            $(document).mouseup(function (e)
            {
                var container = $("#menu");
                

                // if the target of the click isn't the container nor a descendant of the container
                if (!container.is(e.target) && container.has(e.target).length === 0)
                {
                	
                	if ($("#toggle-menu").html() == '<img class="img-fluid" src="/layout/newsheader/images/close-icon.png" alt="" onclick="lockScroll();">') {
                        $("#toggle-menu").html('<img class="img-fluid" src="/layout/newsheader/images/menu-icon.png" alt="" onclick="lockScroll();">');
                        $(".main-menu").slideToggle();
                    	$(".main-menu").removeClass("open-sidebar"); 
                    	
                    	$('html').removeClass('lock-scroll');
                    	$('body').removeClass('lock-scroll');
            			$('.wrapper').removeClass('lock-scroll');
                
                    } 
                   
                    
                }
            });
            
            $(document).on('touchstart', function(e)
            {
                
                var container = $("#menu");

                // if the target of the click isn't the container nor a descendant of the container
                if (!container.is(e.target) && container.has(e.target).length === 0)
                {
                	if ($("#toggle-menu").html() == '<img class="img-fluid" src="/layout/newsheader/images/close-icon.png" alt="" onclick="lockScroll();">') {
                        $("#toggle-menu").html('<img class="img-fluid" src="/layout/newsheader/images/menu-icon.png" alt="" onclick="lockScroll();">');
                        $(".main-menu").slideToggle();
                    	$(".main-menu").removeClass("open-sidebar"); 
                    	
                    	$('html').removeClass('lock-scroll');
                    	$('body').removeClass('lock-scroll');
            			$('.wrapper').removeClass('lock-scroll');
                    } 
                   
                    
                }
            });
            $(document).ready(function () {

					
                    if ($("#toggle-menu").html() == '<img class="img-fluid" src="/layout/newsheader/images/close-icon.png" alt="" onclick="lockScroll();">') {
                        $("#toggle-menu").html('<img class="img-fluid" src="/layout/newsheader/images/menu-icon.png" alt="" onclick="lockScroll();">');
                    } else {
                        $("#toggle-menu").html('<img class="img-fluid" src="/layout/newsheader/images/close-icon.png" alt="" onclick="lockScroll();">');
                    }
                    $(".main-menu").slideToggle();
                    $(".main-menu").toggleClass("open-sidebar"); 


					
                    if ($("#toggle-menu").html() == '<img class="img-fluid" src="/layout/newsheader/images/close-icon.png" alt="" onclick="lockScroll();">') {
                        $("#toggle-menu").html('<img class="img-fluid" src="/layout/newsheader/images/menu-icon.png" alt="" onclick="lockScroll();">');
                    } else {
                        $("#toggle-menu").html('<img class="img-fluid" src="/layout/newsheader/images/close-icon.png" alt="" onclick="lockScroll();">');
                    }
                    $(".main-menu").slideToggle();
                    $(".main-menu").toggleClass("open-sidebar");

                $("#toggle-menu").click(function () {
                	
                    
                    if ($("#toggle-menu").html() == '<img class="img-fluid" src="/layout/newsheader/images/close-icon.png" alt="" onclick="lockScroll();">') {
                        $("#toggle-menu").html('<img class="img-fluid" src="/layout/newsheader/images/menu-icon.png" alt="" onclick="lockScroll();">');
                    } else {
                        $("#toggle-menu").html('<img class="img-fluid" src="/layout/newsheader/images/close-icon.png" alt="" onclick="lockScroll();">');
                    }
                    $(".main-menu").slideToggle();
                    $(".main-menu").toggleClass("open-sidebar");
                });

                var isMobile = false; //initiate as false
                // device detection
                if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent) 
                    || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0,4))) { 
                    isMobile = true;
                } 

                if(isMobile) {
                    $("#search_desktop").remove();

                } else {
                    $("#search_mobile").remove();
                }

            });
          
           
        </script>
        
        <script>
            function lockScroll() {
            	if ($('html').hasClass('lock-scroll')) {
                    $('html').removeClass('lock-scroll');
                } else {
                    $('html').addClass('lock-scroll');
                } 
                
                if ($('body').hasClass('lock-scroll')) {
                    $('body').removeClass('lock-scroll');
                } else {
                    $('body').addClass('lock-scroll');
                }
                
                if ($('.wrapper').hasClass('lock-scroll')) {
                    $('.wrapper').removeClass('lock-scroll');
                } else {
                    $('.wrapper').addClass('lock-scroll');
                } 
            }
        </script>
        
 
		



	  <!--Banner-->
   
    <div class="banner-wrap">



        
   
    

          
          
        
           
<a href="en/all-categories/index.html">
     <img class="desktop" src="<?php  echo base_url();?>resources/img/organic-food-banner.jpg" style="width:100%" id="banner_desktop">
  
 <img class="mobile" src="layout/images/slider/mobile.jpg" style="width:100%" id="banner_mobile">
          </a>
             
           
            
          
  <script>
          	 var isMobile = false; //initiate as false
                // device detection
                if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent) 
                    || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0,4))) { 
                    isMobile = true;
                } 

                if(isMobile) {
                    $("#banner_desktop").remove();

                } else {
                    $("#banner_mobile").remove();
                }

            });
          	
          	
          	
          </script>
          
          
           
         

             
                
               
             
            

      </div>


     
    
    
    
    
    
    <!--/Banner-->

    <div class="saving-wrap" style="    margin-top: -6px;">
        <div class="container">
            <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6">              	
					<div class="saving--item__single">						
						<div class="saving--item__text">
							<h4>Low PRICES</h4>
							<p>Lowest Prices</p>
						</div>
					</div>               
				</div>
				<div class="col-xs-6 col-sm-6 col-md-6">              
					<div class="saving--item__single">						
						<div class="saving--item__text">
							<h4>Cash On Delivery</h4>
							<p>Only Cash No Only Payment</p>
						</div>
					</div>               
				</div>				
            </div>
        </div>
    </div>
    
    

    <!--Featured-->
    <div class="featured-wrap" style="margin-bottom: -30px;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <div class="main-title">                  
						<h4 style="text-transform: uppercase;font-size: 15px;color: #2b2b2b;font-weight: 700;margin: 0;">Featured Categories
							<i class="fa fa-angle-right"></i>
							<i class="fa fa-angle-right"></i>
						</h4>                                             
                    </div>
                </div>     
				<?php							
					forEach($all_sub_category as $value){						
				?>
                <div class="col-xs-6 col-sm-4">
                    <div class="featured-container text-center">
                        <a href="en/all-categories/rice-pulses-flour/index.html">							
                            <img class="img-responsive center-block" src="<?php echo base_url()."admin/uploads/".$value['category_image'];?>" alt="" />
                            <h4><?php echo $value['category_name'];?>
                                <i class="fa fa-angle-right"></i>
                                <i class="fa fa-angle-right"></i>
                            </h4>
                        </a>
                    </div>
                </div>
				<?php } ?>
            </div>
        </div>
    </div>
    <!--/Featured-->

  

                     	
<div class="featured-wrap">
        <div class="container-fluid">
            <div class="row">
 <div class="col-sm-12">
                    <div class="main-title">
                        <a href="en/all-categories/bestsellers/index.html">
                            <h4>SALE PRODUCTS
                                <i class="fa fa-angle-right"></i>
                                <i class="fa fa-angle-right"></i>
                            </h4>
                        </a>
                        
                    </div>
                </div>
                </div>
                </div>
                </div>


<div class="container-fluid" style="margin-top:-50px;">
	
<ul class="row categoryDetails isGridView " data-plenty-details="categoryDetails">
	<div class="col-12">
		<div class="product-slider">
		<?php				
			forEach($product as $value){						
		?>
		
		<!-- item box -->
		<li class="product-container margin-bottom-2 tileView onHover action-1" data-plenty="item" data-plenty-id="13070">
			<form action="https://www.jamoona.com/" name="Article_13070" id="Article_13070" class="article_order_form" method="post" enctype="multipart/form-data">
				 				
				<div class="action js-link" data-plenty="click:Redirect.to( 'en/all-categories/ahmeda-rose-petal-spread-murabba-400-grams/a-13070/index.html' )"="item-13070" style="background-color: red;
    color: #fff;padding: 1px 15px;
    position: absolute;
    z-index: 100;
    opacity: 0.7;"><?php echo $value['product_name']?></div>
				
				<div class="itemBoxInner">
					<div id="previewImages-13070" class="p_slider-img-wrap h-md-3 h-sm-2 h-xs-6">
						
					
					<div class="imageBox p_slider-img-wrap h-md-3 h-sm-2 h-xs-6 adapt-line-height">
						<a href="en/all-categories/ahmeda-rose-petal-spread-murabba-400-grams/a-13070/index.html">		
							<img class="center img-responsive id-13070 js-link" src="<?php echo base_url()."admin/uploads/".$value['product_img']?>">
						</a>							
						</div>
					
					</div>
					
					<!-- item info -->	
						<a href="en/all-categories/ahmeda-rose-petal-spread-murabba-400-grams/a-13070/index.html">	<h4 class="name block" href="en/all-categories/ahmeda-rose-petal-spread-murabba-400-grams/a-13070/index.html" data-plenty-href="item-13070">Ahmed Gulkand (Rose Petal Spread) - Murabba - 400 Grams</h4></a>
					
				<a href="en/all-categories/ahmeda-rose-petal-spread-murabba-400-grams/a-13070/index.html">	<p class="p_sub-text">Size:  
0.4 kg</p></a>
				
					<p class="price bold js-link margin-bottom-0" data-plenty="click:Redirect.to( 'en/all-categories/ahmeda-rose-petal-spread-murabba-400-grams/a-13070/index.html' )"="item-13070"><br />
					
						
						<span class="large linkToItem">&euro; <input type="hidden" id="price_dynamic_1_13070_orderparam_markup" value="0"/><input type="hidden" id="price_dynamic_1_13070_total" value="2.25"/><input type="hidden" id="price_dynamic_1_13070_cfgFormat" value="0"/><span class="Price" id="price_dynamic_1_13070">2,25</span><input type="hidden" id="price_dynamic_1_13070_variationId" value="2817" /></span>
					
							<span class="uvp line-through small" style="font-size:16px; color:grey;margin-left:6px;display:none;"></span>
						


							<span class="uvp line-through small" style="font-size:16px; color:grey;margin-left:6px;"><?php echo $value['price']?></span>
						


						<p style="font-size:12px;">	(Baseprice: 5,63&thinsp;&euro;&thinsp;/&thinsp;kilogram)</p>
					






					</p>
					
			<a href="en/all-categories/ahmeda-rose-petal-spread-murabba-400-grams/a-13070/index.html">	<p class="p_sub-text">Save <span style="color:red; font-size:17px;">37,50%</span> vs retail</p></a>										
					<div class="visible-hover">
						<div class="basketButtonContainer clearfix" style="text-align: center;">
							
								<div class="buttonBox shipping-tray isViewItem">
									<a class="btn" href="en/all-categories/ahmeda-rose-petal-spread-murabba-400-grams/a-13070/index.html">
										<!--<span class="glyphicon glyphicon-eye-open"></span>-->
										View Product</a>
								</div>
							
						</div>
					</div>
						
				</div>
			</form>
		</li>
		<!-- ./item box -->
	
			<?php } ?>
		</div>
	</div>
</ul>
	</div>




               
 
    
    
       <!--Deals-->
    <div class="deals-wrap">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    <div class="beverages-container sandwitch-container">
                        <h3>Snacks time is the best time</h3>
                        <p>up to 40% off</p>
                        <a href="en/all-categories/snacks-dry-fruits/index.html" class="btn">Shop Now</a>
                        <img class="img-responsive lazy" data-src="/layout/images/teaser1.png" alt="" />
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="beverages-container stock-container" style="padding: 33px 20px;">
                        <h3>Deals like never before</h3>
                       <p>flat up to 35% off</p>
                        <a href="en/all-categories/oils-spices/index57c1.html?producer=11" class="btn">Shop Now</a>
                        <img class="img-responsive lazy" data-src="/layout/images/teaser2.png" alt="" />
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/Deals-->
    
      
                

<div class="featured-wrap">
        <div class="container-fluid">
            <div class="row">
 <div class="col-sm-12">
                    <div class="main-title">
                        <a href="en/all-categories/sale/index.html">
                            <h4>Our best selling Products
                                <i class="fa fa-angle-right"></i>
                                <i class="fa fa-angle-right"></i>
                            </h4>
                        </a>
                        
                    </div>
                </div>
                </div>
                </div>
                </div>


<div class="container-fluid" style="margin-top:-50px;">
	 
<ul class="row categoryDetails isGridView " data-plenty-details="categoryDetails">
	
	<div class="col-12">
		
		<div class="product-slider">
			
		<?php				
			forEach($product as $value){						
		?>
		
		
			<!-- item box -->
			<li class="product-container margin-bottom-2 tileView onHover action-3" data-plenty="item" data-plenty-id="990294">
				<form action="https://www.jamoona.com/" name="Article_990294" id="Article_990294" class="article_order_form" method="post" enctype="multipart/form-data">
					 
					 
						
					<div class="itemBoxInner">
						<div id="previewImages-990294" class="p_slider-img-wrap h-md-3 h-sm-2 h-xs-6">
							
						
							<div class="imageBox p_slider-img-wrap h-md-3 h-sm-2 h-xs-6 adapt-line-height">
								<a href="en/all-categories/beverages/soft-drinks/rubicon-mango-juice-drink-deluxe-1liter/a-990294/index.html">		
									<img class="center img-responsive id-990294 js-link" src="<?php echo base_url()."admin/uploads/".$value['product_img']?>" >
								</a>									
							</div>					
						</div>
						
						<!-- item info -->	
							<a href="en/all-categories/beverages/soft-drinks/rubicon-mango-juice-drink-deluxe-1liter/a-990294/index.html">	<h4 class="name block" href="en/all-categories/beverages/soft-drinks/rubicon-mango-juice-drink-deluxe-1liter/a-990294/index.html" data-plenty-href="item-990294"><?php echo $value['product_name']?></h4></a>
						
				<a href="en/all-categories/beverages/soft-drinks/rubicon-mango-juice-drink-deluxe-1liter/a-990294/index.html">	<p class="p_sub-text">Size:  
	1 kg</p></a>
					
						<p class="price bold js-link margin-bottom-0" data-plenty="click:Redirect.to( 'en/all-categories/beverages/soft-drinks/rubicon-mango-juice-drink-deluxe-1liter/a-990294/index.html' )"="item-990294"><br />											
							<span class="large linkToItem">&euro; <input type="hidden" id="price_dynamic_1_990294_orderparam_markup" value="0"/><input type="hidden" id="price_dynamic_1_990294_total" value="1.59"/><input type="hidden" id="price_dynamic_1_990294_cfgFormat" value="0"/><span class="Price" id="price_dynamic_1_990294">1,59</span><input type="hidden" id="price_dynamic_1_990294_variationId" value="3871" /></span>					
							<span class="uvp line-through small" style="font-size:16px; color:grey;margin-left:6px;display:none;"></span>						
							<p style="font-size:12px;">	(Baseprice: 1,59&thinsp;&euro;&thinsp;/&thinsp;liter)</p>					
						</p>
						
				<a href="en/all-categories/beverages/soft-drinks/rubicon-mango-juice-drink-deluxe-1liter/a-990294/index.html">	<p class="p_sub-text">Save <span style="color:red; font-size:17px;">36,40%</span> vs retail</p></a>
							
					
						
						
						<div class="visible-hover">
					
							<div class="basketButtonContainer clearfix" style="text-align: center;">
											
												<div class="buttonBox shipping-tray isViewItem">
													<a class="btn" href="en/all-categories/beverages/soft-drinks/rubicon-mango-juice-drink-deluxe-1liter/a-990294/index.html">
														<!--<span class="glyphicon glyphicon-eye-open"></span>-->
														View Product</a>
														
												</div>
											
										</div>
						</div>
							
					</div>
				</form>
			</li>
			<!-- ./item box -->
		
		<?php } ?>	
		
		</div>
			
			</div>
</ul>
	</div>
      	
      
      
      
      <!--Deals-->
    <div class="deals-wrap" >
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    <div class="deals-container text-center">
                        <h3>Deals of the week</h3>
                        <p>up to 45% off on Rice products</p>
                        <a href="en/all-categories/rice-pulses-flour/rice-noodles/index.html" class="btn">Shop Now</a>
                        <img class="img-responsive lazy" data-src="/layout/images/teaserricefinal_1.png" alt="" />
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="beverages-container">
                        <h3>Your favorite beverages</h3>
                        <p>up to 39% discount</p>
                        <a href="en/all-categories/beverages/index.html" class="btn">Shop Now</a>
                        <img class="img-responsive lazy" data-src="/layout/images/teaser4.png" alt="" />
                    </div>
                    <div class="beverages-container stock-container">
                        <h3>Wonderful snacks with wow deals</h3>
                        <p>Made for snack time</p>
                        <a href="en/all-categories/snacks-dry-fruits/index.html" class="btn">Shop Now</a>
                        <img class="img-responsive lazy" data-src="/layout/images/teaser5.png" alt="" />
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Deals-->
     
    <script type="text/javascript">
    	document.addEventListener("DOMContentLoaded", function() {
                var lazyloadImages;    

               
                    var lazyloadThrottleTimeout;
                    lazyloadImages = document.querySelectorAll(".lazy");
                    
                    function lazyload () {
                        
                        if(lazyloadThrottleTimeout) {
                            clearTimeout(lazyloadThrottleTimeout);
                        }    

                        lazyloadThrottleTimeout = setTimeout(function() {
                            var scrollTop = window.pageYOffset;
                            lazyloadImages.forEach(function(img) {
                                if(img.offsetTop < (window.innerHeight + scrollTop)) {
                                    img.src = img.dataset.src;
                                    img.classList.remove('lazy');
                                }
                            });
                            if(lazyloadImages.length == 0) { 
                                document.removeEventListener("scroll", lazyload);
                                window.removeEventListener("resize", lazyload);
                                window.removeEventListener("orientationChange", lazyload);
                            }
                        }, 20);
                    }

                    document.addEventListener("scroll", lazyload);
                    window.addEventListener("resize", lazyload);
                    window.addEventListener("orientationChange", lazyload);
                
            });
    </script>
                  
                        
                
                     
        



<div class="featured-wrap">
        <div class="container-fluid">
            <div class="row">
 <div class="col-sm-12">
                    <div class="main-title">
                        <a href="en/all-categories/new-items/index.html">
                            <h4>New products
                                <i class="fa fa-angle-right"></i>
                                <i class="fa fa-angle-right"></i>
                            </h4>
                        </a>
                        
                    </div>
                </div>
                </div>
                </div>
                </div>


<div class="container-fluid" style="margin-top:-50px;">
		
        
	<ul class="row categoryDetails isGridView " data-plenty-details="categoryDetails">
	
		<div class="col-12">
			<div class="product-slider">
			
		<?php				
			forEach($product as $value){						
		?>
		
		
			<!-- item box -->
			<li class="product-container margin-bottom-2 tileView onHover action-3" data-plenty="item" data-plenty-id="990294">
				<form action="https://www.jamoona.com/" name="Article_990294" id="Article_990294" class="article_order_form" method="post" enctype="multipart/form-data">
					 
					 
						
					<div class="itemBoxInner">
						<div id="previewImages-990294" class="p_slider-img-wrap h-md-3 h-sm-2 h-xs-6">
							
						
							<div class="imageBox p_slider-img-wrap h-md-3 h-sm-2 h-xs-6 adapt-line-height">
								<a href="en/all-categories/beverages/soft-drinks/rubicon-mango-juice-drink-deluxe-1liter/a-990294/index.html">		
									<img class="center img-responsive id-990294 js-link" src="<?php echo base_url()."admin/uploads/".$value['product_img']?>" >
								</a>									
							</div>					
						</div>
						
						<!-- item info -->	
							<a href="en/all-categories/beverages/soft-drinks/rubicon-mango-juice-drink-deluxe-1liter/a-990294/index.html">	<h4 class="name block" href="en/all-categories/beverages/soft-drinks/rubicon-mango-juice-drink-deluxe-1liter/a-990294/index.html" data-plenty-href="item-990294"><?php echo $value['product_name']?></h4></a>
						
				<a href="en/all-categories/beverages/soft-drinks/rubicon-mango-juice-drink-deluxe-1liter/a-990294/index.html">	<p class="p_sub-text">Size:  
	1 kg</p></a>
					
						<p class="price bold js-link margin-bottom-0" data-plenty="click:Redirect.to( 'en/all-categories/beverages/soft-drinks/rubicon-mango-juice-drink-deluxe-1liter/a-990294/index.html' )"="item-990294"><br />											
							<span class="large linkToItem">&euro; <input type="hidden" id="price_dynamic_1_990294_orderparam_markup" value="0"/><input type="hidden" id="price_dynamic_1_990294_total" value="1.59"/><input type="hidden" id="price_dynamic_1_990294_cfgFormat" value="0"/><span class="Price" id="price_dynamic_1_990294">1,59</span><input type="hidden" id="price_dynamic_1_990294_variationId" value="3871" /></span>					
							<span class="uvp line-through small" style="font-size:16px; color:grey;margin-left:6px;display:none;"></span>						
							<p style="font-size:12px;">	(Baseprice: 1,59&thinsp;&euro;&thinsp;/&thinsp;liter)</p>					
						</p>
						
				<a href="en/all-categories/beverages/soft-drinks/rubicon-mango-juice-drink-deluxe-1liter/a-990294/index.html">	<p class="p_sub-text">Save <span style="color:red; font-size:17px;">36,40%</span> vs retail</p></a>
							
					
						
						
						<div class="visible-hover">
					
							<div class="basketButtonContainer clearfix" style="text-align: center;">
											
												<div class="buttonBox shipping-tray isViewItem">
													<a class="btn" href="en/all-categories/beverages/soft-drinks/rubicon-mango-juice-drink-deluxe-1liter/a-990294/index.html">
														<!--<span class="glyphicon glyphicon-eye-open"></span>-->
														View Product</a>
														
												</div>
											
										</div>
						</div>
							
					</div>
				</form>
			</li>
			<!-- ./item box -->
		
		<?php } ?>	
		
		</div>
		
		</div>
		
	</ul>
</div>

      	
      
  

   
   	
   

	


	
			
		
			
			
	


 


<script>
	jQuery(document).ready(function() {
		
		PlentyFramework.setGlobal( 'PageDesign', "Content" );
		PlentyFramework.setGlobal( 'LoginSessionExpiration', 60 * 60 * 1000 ); // 1 hour
		PlentyFramework.setGlobal( 'TimeoutItemToBasketOverlay', 1000 );
		PlentyFramework.setGlobal( 'Checkout.AtrigaShowValidationError', true );
		PlentyFramework.setGlobal( 'Checkout.AtrigaRequireUserConfirmation', false );
	});
</script>

<footer>

	<!--Footer-->
    <footer>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 col-lg-9">
                    <div class="row">
                        <div class="col-md-12">
                          <!--  <div class="invite-friend">
                                <i class="fa fa-envelope-open"></i>
                                <a href="https://www.jamodaa.com/account/invite/">INVITE FRIENDS! GIVE $15 - GET $15</a>
                            </div>-->
                        </div>
                        <div class="col-sm-4 col-md-3">
                            <div class="footer-container">
                                <h3>Categories</h3>
                                <ul>
                                    <li>
                                        <a href="en/all-categories/index.html">All Products</a>
                                    </li>
                                 
                                   <li>
                                                   
                                   <a href="en/all-categories/grains-lentils/index.html">Grains & Lentils </a></li>
                                                
                                               
                                   <li>
                                                   
                                   <a href="en/all-categories/oils-spices/index.html">Oils & Spices </a></li>
                                    <li>
                                                   
                                   <a href="en/all-categories/snacks-dry-fruits/index.html">Dry Fruit & Snacks </a></li>
                                    <li>
                                                   
                                   <a href="en/all-categories/ready-to-eat-products/index.html">Ready to Eat </a></li>
                                    <li>
                                                   
                                   <a href="en/all-categories/beverages/index.html">Beverages </a></li>
                                     <li>
                                                   
                                   <a href="en/all-categories/health-personal-care/index.html">Health Care </a></li>
                                  
                                  
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-4 col-md-3">
                            <div class="footer-container">
                                <h3>Infos</h3>
                                <ul>
                                    
                                    <li>
                                        <a href="en/infos/shipping-paymentinfos/index.html">Shipping & Paymentinfos</a>
                                    </li>
                                    <li>
                                        <a href="infos/versand-zahlungsinformationen/index.html">Versand & Zahlungsinformationen</a>
                                    </li>
                              
                                    <li>
                                        <a href="infos/faq/index.html">FAQ</a>
                                    </li>
                                      <li>
                                        <a href="infos/about-us/index.html">About Us</a>
                                    </li>
                                    
                                 
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-4 col-md-3">
                            <div class="footer-container">
                            	  <h3>RECHTLICHES</h3>
                                <ul>
                                	<li>
                                        <a href="infos/impressum/index.html">Impressum</a>
                                    </li>
                                    <li>
                                        <a href="infos/agb/index.html">ABG</a>
                                    </li>
                                    	<li>
                                        <a href="infos/haftungsausschluss/index.html">Haftungsausschluss</a>
                                    </li>
                                    <li>
                                        <a href="infos/datenschutz/index.html">Datenschutz</a>
                                    </li>
                                <li>
                                        <a href="infos/widerrufsrecht.html">Widerrufsrecht</a>
                                    </li>
                                  
                             
                                </ul>
                                
                                <h3>LEGAL</h3>
                                <ul>
                                	<li>
                                        <a href="en/infos/imprint/index.html">Imprint</a>
                                    </li> 
                                    <li>
                                        <a href="en/infos/terms-conditions/index.html">Terms & Conditions</a>
                                    </li>
                                    	<li>
                                        <a href="en/infos/disclaimer/index.html">Disclaimer</a>
                                    </li>
                                    <li>
                                        <a href="en/infos/data-protection-declaration/index.html">Data protection declaration</a>
                                    </li>
                                <li>
                                        <a href="en/infos/revocation-policy/index.html">Revocation right for consumers</a>
                                    </li>
                                  
                             
                                </ul>
                                
                              
                            </div>
                        </div>
                        <div class="col-sm-4 col-md-3">
                        	 <div class="footer-container">
                                <h3>Contact</h3>
                                <ul>
                                    <li style="color:white;">
                                        E-Mail: info@.com
                                    </li>
                                   
                                 <li style="color:white;">
                                  
                                      
                                        Mobil:     +49 (0) 176 139 899 05 - Mo-Fr 9am to 6pm<br />
                                        Whats App: +49 (0) 176 139 899 05 - Mo-Fr 9am to 6pm
                                    </li>
                                    
                                </ul>
                            </div>
                           
                        </div>
                        <div class="col-sm-4 col-md-3">
                            <div class="footer-container">
                                <h3>SOCIAL</h3>
                                <ul class="list-inline social-links">
                                    <li>
                                        <a href="https://www.facebook.com/Jamoona-549794422112112/">
                                            <i class="fa fa-facebook"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://twitter.com/JamoonaC">
                                            <i class="fa fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.youtube.com/channel/UCXD91Sat5ole3SaHsnFf5zg">
                                            <i class="fa fa-youtube"></i>
                                        </a>
                                    </li>
                                 
                                    
                                </ul>
                            </div>
                           </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="copyright">
                        <p>© 2020  glossary</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--/Footer-->


</footer>


			<div class="toTop" data-plenty="UI.initToTop(this)"><a class="btn btn-primary onlyIcon" href="#top"><span class="glyphicon glyphicon-arrow-up"></span><span class="sr-only">Nach oben</span></a></div>
			<a id="bottom"></a>
		
		</div>
		<!-- js (webshop) -->
		<div class="PlentyWebshopOverlay" id="PlentyWebshopOverlay" style="display:none"></div>
		<div class="PlentyWebshopPopup " id="PlentyWebshopPopup_AfterItem2Basket" style="display:none"></div><div class="PlentyWebshopPopup " id="PlentyWebshopPopup_ErrorMessage" style="display:none"></div>
							<script type="text/javascript">
								var webshopPopup		= new PlentyWebshopPopup({ popupId: "PlentyWebshopPopup_AfterItem2Basket"});
								var webshopErrorPopup	= new PlentyWebshopPopup({ popupId: "PlentyWebshopPopup_ErrorMessage"});
							</script>
							
		
		<script>
			ScriptLoader.load({
				layout: 'PageDesignContent',
				position: 'body', 
				rootPath: '/layout/callisto_3/js/',
				sourceMap: '/layout/callisto_3/js/plenty/scripts-3.5.json',
				debug: false
			});
		</script>
		
		<script>
			
				PlentyFramework.loadLanguageFile('/lang/en_EN.json');
			
		</script>
		
		
		
		<div class="modal fade" data-plenty-id="dynamicModal" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
				
				</div>
			</div>
		</div>
		
		<div class="modal browserErrorModal" aria="alert" data-warning="browserErrorModal">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title text-danger"><span class="glyphicon glyphicon-warning-sign"></span>&nbsp;</h4>
					</div>
					<div class="modal-body">
					</div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			if( jQuery('body').hasClass('ielte8') || !Modernizr["mediaqueries"] || !Modernizr["display-table"] ) {
				jQuery('[data-warning="browserErrorModal"] .modal-title').append('Ihr Browser ist veraltet.');
				jQuery('[data-warning="browserErrorModal"] .modal-body').html('<p>Um alle Funktionen dieses Shops nutzen zu können, empfehlen wir Ihnen, Ihren Browser zu aktualisieren.</p>');
				jQuery('[data-warning="browserErrorModal"]').modal('show');	
			}
		</script>
		<script>
			(function($) {
				// error messages
				$(document).ready(function() {
					// append closing button to errors and messages and clone it to the end of body
					$('.plentyErrorBox:not(:empty), .plentyMessageBox').each(function() {
						$('body').append( $(this).prepend('<button type="button" class="close"><span aria-hidden="true">&times;</span><span class="sr-only">Schließen</span></button>') );	
					});
					if ( $('.plentyErrorBox:not(:empty), .plentyMessageBox').length > 0 ) {
						$('#PlentyWebshopOverlay').show();
					}
					// auto closing errors
					$('.plentyErrorBox:not(:empty)').autoHide({
						hideAfter:  0 ,
						removeFromDOM: true,
						overlaySelector: '#PlentyWebshopOverlay',
						closeSelector: '.close'
					});
					
					// auto closing messages
					$('.plentyMessageBox').autoHide({
						hideAfter:  5000 ,
						removeFromDOM: true,
						overlaySelector: '#PlentyWebshopOverlay',
						closeSelector: '.close'
					});
				});
			})(jQuery);
		</script>
		<script>
			(function($) {
				PlentyFramework.setGlobal( 'LoginSession', false );
			}(jQuery));
		</script>
		
		<noscript>
			<div class="modal" aria="alert">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title text-danger"><span class="glyphicon glyphicon-warning-sign"></span>&nbsp;Ihr Browser unterstützt kein JavaScript!</h4>
						</div>
						<div class="modal-body">
							<p>
								Um die Funktionen dieser Seite nutzen zu können, benötigen Sie JavaScript!<br />
								Bitte aktualisieren Sie Ihren Browser oder aktivieren Sie JavaScript in den Einstellungen.
							</p>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-backdrop fade in"></div>
		</noscript>

	</body>
	<script type="text/javascript" src="../cdn.ywxi.net/js/1.js" async></script>
		<link rel="stylesheet" type="text/css" href="<?php  echo base_url();?>resources/js/cookieconsent.min.css" />
<script src="<?php  echo base_url();?>resources/js/cookieconsent.min.js"></script>
<script>
window.addEventListener("load", function(){
window.cookieconsent.initialise({
  "palette": {
    "popup": {
      "background": "#efefef",
      "text": "#404040"
    },
    "button": {
      "background": "#8ec760",
      "text": "#000000"
    }
  },
  "theme": "classic",
  "position": "bottom-left",
  "content": {
    "dismiss": "Accept cookies ",
    "href": "https://www.jamoona.com/en/infos/datenschutz/"
  }
})});


</script>





<span style="color:white;font-size:1px;">
<script>
var stringOfHtml = '<script type="text/javascript" async="" src="../www.paypalobjects.com/muse/muse.js"></script>';
 var html = $(stringOfHtml);
 html.find('<script type="text/javascript" async="" src="../www.paypalobjects.com/muse/muse.js"></script>').remove();

</script>
</span>
</html>