<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Category Edit</h3>
            </div>
			<?php echo form_open('category/edit/'.$category['category_id']); ?>
			<div class="box-body">
				<div class="row clearfix">
				
					<div class="col-md-6">
						<label for="category_name" class="control-label"><span class="text-danger">*</span>Category Name</label>
						<div class="form-group">
							<input type="text" name="category_name" value="<?php echo ($this->input->post('category_name') ? $this->input->post('category_name') : $category['category_name']); ?>" class="form-control" id="category_name" />
							<span class="text-danger"><?php echo form_error('category_name');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="category_code" class="control-label"><span class="text-danger">*</span>Category Code</label>
						<div class="form-group">
							<input type="text" name="category_code" value="<?php echo ($this->input->post('category_code') ? $this->input->post('category_code') : $category['category_code']); ?>" class="form-control" id="category_code" />
							<span class="text-danger"><?php echo form_error('category_code');?></span>
						</div>
					</div>
				<div class="col-md-6">
						<label for="cat_status" class="control-label"><span class="text-danger">*</span>Cat Status</label>
						<div class="form-group">
							<select name="cat_status" class="form-control">
								<option value="">select</option>
								<?php 
								$cat_status_values = array(
									'1'=>'Active',
									'2'=>'Inactive',
								);

								foreach($cat_status_values as $value => $display_text)
								{
									$selected = ($value == $category['cat_status']) ? ' selected="selected"' : "";

									echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('cat_status');?></span>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>