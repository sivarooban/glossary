<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Category Add</h3>
            </div>
            <?php echo form_open('category/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					
					<div class="col-md-6">
						<label for="category_name" class="control-label"><span class="text-danger">*</span>Category Name</label>
						<div class="form-group">
							<input type="text" name="category_name" value="<?php echo $this->input->post('category_name'); ?>" class="form-control" id="category_name" />
							<span class="text-danger"><?php echo form_error('category_name');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="category_code" class="control-label"><span class="text-danger">*</span>Category Code</label>
						<div class="form-group">
							<input type="text" name="category_code" value="<?php echo $this->input->post('category_code'); ?>" class="form-control" id="category_code" />
							<span class="text-danger"><?php echo form_error('category_code');?></span>
						</div>
					</div>
                    <div class="col-md-6">
						<label for="cat_status" class="control-label"><span class="text-danger">*</span>Cat Status</label>
						<div class="form-group">
							<select name="cat_status" class="form-control">
								<option value="">select</option>
								<?php 
								$cat_status_values = array(
									'1'=>'Active',
									'2'=>'Inactive',
								);

								foreach($cat_status_values as $value => $display_text)
								{
									$selected = ($value == $this->input->post('cat_status')) ? ' selected="selected"' : "";

									echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('cat_status');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="product_img" class="control-label">Product Img</label>
						<div class="form-group">
							<input type="file" name="category_image"  class="form-control" id="product_img"  onchange="readURL(this);"  required/>
						</div>
                        
                            <div class="edit_div">
                        <img id="blah" src="#" alt="" />
                        </div>
                        
                        
					</div>
					<!--<div class="col-md-6">
						<label for="created" class="control-label">Created</label>
						<div class="form-group">
							<input type="text" name="created" value="<?php echo $this->input->post('created'); ?>" class="form-control" id="created" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="modified" class="control-label">Modified</label>
						<div class="form-group">
							<input type="text" name="modified" value="<?php echo $this->input->post('modified'); ?>" class="form-control" id="modified" />
						</div>
					</div>-->
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>