<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Cm Add</h3>
            </div>
            <?php echo form_open('cm/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="cms_model" class="control-label">Cms Model</label>
						<div class="form-group">
							<input type="text" name="cms_model" value="<?php echo $this->input->post('cms_model'); ?>" class="form-control" id="cms_model" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="cms_title" class="control-label"><span class="text-danger">*</span>Cms Title</label>
						<div class="form-group">
							<input type="text" name="cms_title" value="<?php echo $this->input->post('cms_title'); ?>" class="form-control" id="cms_title" />
							<span class="text-danger"><?php echo form_error('cms_title');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="cms_image" class="control-label">Cms Image</label>
						<div class="form-group">
							<input type="text" name="cms_image" value="<?php echo $this->input->post('cms_image'); ?>" class="form-control" id="cms_image" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="cms_seo_title" class="control-label">Cms Seo Title</label>
						<div class="form-group">
							<input type="text" name="cms_seo_title" value="<?php echo $this->input->post('cms_seo_title'); ?>" class="form-control" id="cms_seo_title" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="cms_seo_description" class="control-label">Cms Seo Description</label>
						<div class="form-group">
							<input type="text" name="cms_seo_description" value="<?php echo $this->input->post('cms_seo_description'); ?>" class="form-control" id="cms_seo_description" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="cms_seo_keyword" class="control-label">Cms Seo Keyword</label>
						<div class="form-group">
							<input type="text" name="cms_seo_keyword" value="<?php echo $this->input->post('cms_seo_keyword'); ?>" class="form-control" id="cms_seo_keyword" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="cms_description" class="control-label"><span class="text-danger">*</span>Cms Description</label>
						<div class="form-group">
							<textarea name="cms_description" class="form-control" id="cms_description"><?php echo $this->input->post('cms_description'); ?></textarea>
							<span class="text-danger"><?php echo form_error('cms_description');?></span>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>