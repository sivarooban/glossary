	<div style="clear:both"></div>
	<div class="banner-wrap">
		<div style="clear:both"></div>
		<div class="container" style="padding-top:134px;">
			<br><br><br>
			
			<div style="clear:both"></div>
			<br><br>
			<div class="row" style="text-align:center;" >
				<h1>Products</h1>      
			</div>
			<br><br>
			<div class="">
				<ul class="row categoryDetails isGridView ">
					<div class="col-12">	
						<div class="">
							<?php				
								$g = 0;
								forEach($products as $value){						
									
									$g = $g+1;
									if($g == 5){
										
										$g=1;
							?>
									<div style="clear:both"></div>
									<br><br>
								<?php
									}
								?>		
							<!-- item box -->
							<div class="col-md-3">							
								<div class="itemBoxInner">
									
									<div id="previewImages-990294" class="p_slider-img-wrap h-md-3 h-sm-2 h-xs-6">						
										<div class="imageBox p_slider-img-wrap h-md-3 h-sm-2 h-xs-6 adapt-line-height">
											<a href="#">		
												<img style="width:200px;height:200px" class="center img-responsive id-990294 js-link" src="<?php echo base_url()."admin/uploads/".$value->product_img?>" >
											</a>									
										</div>										
									</div>							
									<!-- item info -->	
									<a href="#">	
										<h4 class="name block" href="#" style="text-align:center">
											<?php echo $value->product_name?>
										</h4>
									</a>							
									<a href="#">
										<p class="p_sub-text" style="text-align:center">
											Size:  1 kg
										</p>
									</a>						
									<p class="price bold js-link margin-bottom-0" style="text-align:center">
										<br />
										<?php echo $value->price?>
									</p>
									<div class="visible-hover" >						
										<div class="basketButtonContainer clearfix" style="text-align: center;">												
											<div style="color: #d87e3e;font-weight: 700;border-radius: 0;border: 2px solid #d87e3e;" class="buttonBox shipping-tray isViewItem">
												<a class="btn" href="<?php echo base_url()."product_single?id=".$value->product_id?>">								
													View Product
												</a>															
											</div>												
										</div>
									</div>								
								</div>					
							</div>
							<!-- ./item box -->
						
							<?php } ?>				
						</div>				
					</div>
				</ul>
			</div>
					

		</div>		
	</div>